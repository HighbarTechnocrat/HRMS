﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Data.SqlClient;

public partial class WorkSchedule : System.Web.UI.Page
{
    string Location_Code;
    Admin_Methods adm = new Admin_Methods();
    protected void Page_Load(object sender, EventArgs e)
    {
        string flag;
        if (Request.QueryString["flag"] != "" && Request.QueryString["flag"] != null)
        {
            flag = Convert.ToString(commonclass.GetSafeFlagFromURL(Request.QueryString["flag"]));
            if (flag == "Y")
            {
                lblmsg.Visible = true;
                lblmsg.Text = "<font color='green'><b>Work Schedule Created successfully</b></font>";
            }
            else if (flag == "U")
            {
                lblmsg.Visible = true;
                lblmsg.Text = "<font color='green'><b>Work Schedule Created successfully</b></font>";
            }
            else
            {
                Response.Redirect(ConfigurationManager.AppSettings["sitepathadmin"] + "error.aspx");
            }
        }
        if (!Page.IsPostBack)
        {
            
            loadgrid();
            lblName.Text = highbarconfiguration.SiteName +
                       ": Admin: Work Schedule";
        }
        this.Title = highbarconfiguration.SiteName + ": Admin: Work Schedule";
    }

    public void loadgrid()
    {
       
        SqlParameter[] spars = new SqlParameter[2];
        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "list";
        gvproject.DataSource = adm.getDataList(spars, "SP_Admin_WorkSchedule");
        gvproject.DataBind();
    }

    protected void btnadd_Click(object sender, EventArgs e)
    {
        Response.Redirect(ConfigurationManager.AppSettings["sitepath"] + "WorkScheduleAdd.aspx");
    }

    protected void gvproject_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvproject.PageIndex = e.NewPageIndex;
        SqlParameter[] spars = new SqlParameter[1];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "list";
        gvproject.DataSource = adm.getDataList(spars, "SP_Admin_WorkSchedule");
        gvproject.DataBind();
    }

    //protected void btnsearch_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        lblmsg.Visible = false;
    //        string ntitle = "";
    //        if (ddl_Location.SelectedValue != "" && ddl_Location.SelectedValue != "0")
    //        {
    //            ntitle = ddl_Location.SelectedValue;
    //        }

    //        SqlParameter[] spars = new SqlParameter[2];

    //        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
    //        spars[0].Value = "list";

    //        spars[1] = new SqlParameter("@Location_name", SqlDbType.VarChar);
    //        if (ntitle.ToString() == "")
    //            spars[1].Value = DBNull.Value;
    //        else
    //            spars[1].Value = ntitle;

    //        DataTable dt = adm.getDataList(spars, "SP_Admin_Location");
    //        //DataTable dt = adm.getDataList("list",ntitle);

    //        if (dt.Rows.Count > 0)
    //        {
    //            gvproject.DataSource = dt;
    //            gvproject.DataBind();
    //            lblmainmsg1.Visible = true;
    //            if (ntitle != "" && ntitle != null)
    //            {
    //                lblmainmsg1.Visible = true;
    //                lblmessage1.Visible = true;
    //                lblmessage1.Text = ntitle;
    //            }
    //            else if (ntitle != "" && ntitle != null)
    //            {
    //                lblmainmsg1.Visible = true;
    //                lblmessage1.Visible = true;
    //                lblmessage1.Text = ntitle;
    //            }
    //            else
    //            {
    //                lblmainmsg1.Visible = false;
    //                lblmessage1.Visible = false;
    //            }

    //            lblmainmsg.Visible = false;
    //            lblerror.Visible = false;
    //            lblerror.Text = "";
    //        }
    //        else
    //        {
    //            if (ntitle != "" && ntitle != null)
    //            {
    //                lblmainmsg1.Visible = true;
    //                lblmessage1.Visible = true;
    //                lblmessage1.Text = ntitle;
    //            }
    //            else if (ntitle != "" && ntitle != null)
    //            {
    //                lblmainmsg1.Visible = true;
    //                lblmessage1.Visible = true;
    //                lblmessage1.Text = ntitle;
    //            }
    //            else
    //            {
    //                lblmainmsg1.Visible = false;
    //                lblmessage1.Visible = false;
    //            }
    //            lblmainmsg.Visible = false;
    //            lblerror.Text = "<br><font color='Red'>No record found!</font><br>";
    //            lblerror.Visible = true;
    //        }

    //        //txttitle.Text = "";

    //    }
    //    catch (Exception ex)
    //    {
    //        ErrorLog.WriteError(ex.ToString(), "btnsearch_Click");
    //    }
    //}

    //protected void BtnClear_Click(object sender, EventArgs e)
    //{
    //    lblmsg.Visible = false;
    //    lblmainmsg.Visible = false;
    //    lblerror.Visible = false;
    //    lblerror.Text = "";
    //    loadgrid();
    //    lblmainmsg1.Visible = false;
    //    lblmessage1.Visible = false;
    //    lblmessage1.Text = "";
    //    ddl_Location.SelectedValue = "0";

    //}
}