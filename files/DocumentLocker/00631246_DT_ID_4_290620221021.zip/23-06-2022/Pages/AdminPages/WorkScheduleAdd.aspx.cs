﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using ClosedXML.Excel;
using System.Web;
using System.IO;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

public partial class WorkScheduleAdd : System.Web.UI.Page
{
    public string projectid;
    public int projectcatid;
    int number;
    
    Admin_Methods adm = new Admin_Methods();

    protected void Page_Load(object sender, EventArgs e)
    {
        lblName.Text = highbarconfiguration.SiteName + ": Admin: Insert / Work Schedule";
        if (!Page.IsPostBack)
        {

        }
        this.Title = highbarconfiguration.SiteName + ": Admin: Insert Update Projects";
    }


    protected void btnadd_Click(object sender, EventArgs e)
    {
        
        string DaysWithoutTick="";
        string DaysTick ="";

        if (chk_Monday.Checked == true)
            DaysTick += chk_Monday.Text.Trim();
        if (chk_Tuesday.Checked == true)
            DaysTick += "" + " " + chk_Tuesday.Text.Trim();
        if (chk_Wednesday.Checked == true)
            DaysTick += "" + " " + chk_Wednesday.Text.Trim();
        if (chk_Thursday.Checked == true)
            DaysTick += "" + " " + chk_Thursday.Text.Trim();
        if (chk_Friday.Checked == true)
            DaysTick += "" + " " + chk_Friday.Text.Trim();
        if (chk_Saturday.Checked == true)
            DaysTick += "" + " " + chk_Saturday.Text.Trim();
        if (chk_Sunday.Checked == true)
            DaysTick += "" + " " + chk_Sunday.Text.Trim();

        string strDaysTick = DaysTick.Trim();
        string DaysTickOutPut = strDaysTick.Replace(' ', ',').Trim();

        if (chk_Monday.Checked == false)
            DaysWithoutTick += chk_Monday.Text.Trim();
        if (chk_Tuesday.Checked == false)
            DaysWithoutTick += "" + " " + chk_Tuesday.Text.Trim();
        if (chk_Wednesday.Checked == false)
            DaysWithoutTick += "" + " " + chk_Wednesday.Text.Trim();
        if (chk_Thursday.Checked == false)
            DaysWithoutTick += "" + " " + chk_Thursday.Text.Trim();
        if (chk_Friday.Checked == false)
            DaysWithoutTick += "" + " " + chk_Friday.Text.Trim();
        if (chk_Saturday.Checked == false)
            DaysWithoutTick += "" + " " + chk_Saturday.Text.Trim();
        if (chk_Sunday.Checked == false)
            DaysWithoutTick += "" + " " + chk_Sunday.Text.Trim();

        string strDaysWithoutTick = DaysWithoutTick.Trim();
        string DaysWithoutTickOutPut = strDaysWithoutTick.Replace(' ', ',').Trim();

        SqlParameter[] spars = new SqlParameter[2];
        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "Check_Duplicate_insert";

        spars[1] = new SqlParameter("@WORK_DAYS_NAME", SqlDbType.VarChar);
        spars[1].Value = DaysTickOutPut.ToString().Trim();

        DataTable dt = adm.getDuplicate_List(spars, "SP_Admin_WorkSchedule");
        if (dt.Rows.Count > 0)
        {
            msgsave.Text = "Work Schedule Already Exists!";
            msgsave.Visible = true;
            return;
        }
        else
        {
            string[] DaysTickList;
            string[] DaysWithoutTickList;
            int StrOFF_DAYS = 0;
            int StrWORKING_DAYS = 0;

            if (DaysTickOutPut != "")
            {
                DaysTickList = DaysTickOutPut.Split(',');
                StrWORKING_DAYS = DaysTickList.Length;
            }
            if (DaysWithoutTickOutPut != "")
            {
                DaysWithoutTickList = DaysWithoutTickOutPut.Split(',');
                StrOFF_DAYS = DaysWithoutTickList.Length;
            }
            msgsave.Visible = false;
            SqlParameter[] spars1 = new SqlParameter[6];

            spars1[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars1[0].Value = "Insert";
            spars1[1] = new SqlParameter("@WORK_DAYS_NAME", SqlDbType.VarChar);
            spars1[1].Value = DaysTickOutPut.ToString().Trim();
            spars1[2] = new SqlParameter("@OFF_DAYS_NAME", SqlDbType.VarChar);
            spars1[2].Value = DaysWithoutTickOutPut.ToString().Trim();
            spars1[3] = new SqlParameter("@SCHEDULE_DESCR", SqlDbType.VarChar);
            spars1[3].Value = StrWORKING_DAYS + " days " + DaysWithoutTickOutPut.ToString().Trim();
            spars1[4] = new SqlParameter("@WORKING_DAYS", SqlDbType.VarChar);
            spars1[4].Value = StrWORKING_DAYS;
            spars1[5] = new SqlParameter("@OFF_DAYS", SqlDbType.VarChar);
            spars1[5].Value = StrOFF_DAYS;
            adm.Insert_Data(spars1, "SP_Admin_WorkSchedule");
            Response.Redirect("WorkSchedule.aspx");
        }

    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect(ConfigurationManager.AppSettings["sitepathadmin"] + "WorkSchedule.aspx");
    }

}