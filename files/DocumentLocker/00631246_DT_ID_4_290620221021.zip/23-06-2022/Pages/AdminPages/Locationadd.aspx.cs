﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using ClosedXML.Excel;
using System.Web;
using System.IO;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

public partial class Locationadd : System.Web.UI.Page
{
    public string projectid;
    public int projectcatid;
    int number;
    public string projectcategory;
    public string projectcategorytext;
    public string projectcategorytexts;
    public string telephonenos;
    Admin_Methods adm = new Admin_Methods();

    protected void Page_Load(object sender, EventArgs e)
    {

        lblName.Text = highbarconfiguration.SiteName + ": Admin: Insert / Update Client / Location";
        if (Request.QueryString["Id"] != null && Request.QueryString["Id"] != "")
        {
            //if (Int32.TryParse(commonclass.GetSafeIDFromURL(Request.QueryString["Id"]), out number))
            //{
                projectid = Convert.ToString(Request.QueryString["Id"]);
            //}
            //else
            //{
            //    Response.Redirect(ConfigurationManager.AppSettings["sitepathadmin"] + "error.aspx");
            //}
        }
        //Response.Write(projectid);
        //Response.End();
        if (!Page.IsPostBack)
        {
            Fill_Project_Manager();
            Fill_Delivery_Manager();
            Fill_Program_Manager();
            Fill_Delivery_Head();
            Fill_Schedule();
            Fill_Shift();
            if (projectid != "" && projectid != null)
            {
                loaddata(projectid);
                ddlLoc_Type.Enabled = false;
            }
            else
            {
                ddlLoc_Type.Enabled = true;
            }
            if (ddlLoc_Typetexts.Text.ToString().ToLower() == "client")
            {
                PMHeader.Visible = true;
                //txt_PM.Visible = true;
                //btnSearchPM.Visible = true;
                ddl_Employee.Visible = true;

                PRMHeader.Visible = true;
                //txt_PRM.Visible = true;
                //btnSearchPRM.Visible = true;
                ddl_Employee_PRM.Visible = true;

                DMHeader.Visible = true;
                //txt_DM.Visible = true;
                //btnSearchDM.Visible = true;
                ddl_Employee_DM.Visible = true;

                DHHeader.Visible = true;
                //txt_DH.Visible = true;
                //btnSearchDH.Visible = true;
                ddl_Employee_DH.Visible = true;
            }
            else
            {
                PMHeader.Visible = false;
                //txt_PM.Visible = false;
                //btnSearchPM.Visible = false;
                ddl_Employee.Visible = false;

                PRMHeader.Visible = false;
                //txt_PRM.Visible = false;
                //btnSearchPRM.Visible = false;
                ddl_Employee_PRM.Visible = false;

                DMHeader.Visible = false;
                //txt_DM.Visible = false;
                //btnSearchDM.Visible = false;
                ddl_Employee_DM.Visible = false;

                DHHeader.Visible = false;
                //txt_DH.Visible = false;
                //btnSearchDH.Visible = false;
                ddl_Employee_DH.Visible = false;
            }
        }
        this.Title = highbarconfiguration.SiteName + ": Admin: Insert Update Projects";
    }
  

    protected void btnadd_Click(object sender, EventArgs e)
    {
        Int32 work_days = 0;
        string tStatus = "";
        string chk_L = "N";
        string chk_A = "N";
        string chk_M = "N";
        string chk_F = "N";
        string chk_T = "N";
        string chk_V = "N";
        //

        if (DDLWorkingDaysList.SelectedValue != "0")
        {
            if ((DDLWeekEnd1.SelectedValue == "0" || DDLWeekEnd1.SelectedValue == "") && DDLWeekEnd2.SelectedValue == "0")
            {
                msgsave.Text = "Please select Alternate Weekend";
                msgsave.Visible = true;
                return;
            }
        }

        if(ddlLoc_Typetexts.Text.ToString().Trim()== "CLIENT")
        {
            var getPM= ddl_EmployeeId.Text.ToString().Trim();
            var getDM= ddl_Employee_DMId.Text.ToString().Trim();
            var getPRM= ddl_Employee_PRMId.Text.ToString().Trim();
            var getDH= ddl_Employee_DHId.Text.ToString().Trim();
            if(getPM=="")
            {
                msgsave.Text = "Please select project manager.";
                msgsave.Visible = true;
                return;
            }
            if (getDM == "")
            {
                msgsave.Text = "Please select delivery manager.";
                msgsave.Visible = true;
                return;
            }
            if (getPRM == "")
            {
                msgsave.Text = "Please select program manager.";
                msgsave.Visible = true;
                return;
            }
            if (getDH == "")
            {
                msgsave.Text = "Please select delivery head.";
                msgsave.Visible = true;
                return;
            }

            if(getPM==getDH && (getPM!=getDM ||getPM!=getPRM))
            {
                msgsave.Text = "When DM & PRM are different then PM & DH cannot be same.";
                msgsave.Visible = true;
                return;
            }
            if (getPM == getPRM && (getPM != getDM))
            {
                msgsave.Text = "When DM is different, PM & PRM cannot be same.";
                msgsave.Visible = true;
                return;
            }
            if (getDM == getDH && (getDM != getPRM))
            {
                msgsave.Text = "When PRM is different, DM & DH cannot be same.";
                msgsave.Visible = true;
                return;
            }
        }
        
        if (chk_leave.Checked)
            chk_L = "Y";
        if (chk_att.Checked)
            chk_A = "Y";
        if (chk_Mob.Checked)
            chk_M = "Y";
        if (chk_Fuel.Checked)
            chk_F = "Y";
        if (chk_vou.Checked)
            chk_V = "Y";

        if (ddlScheduletexts.Text.ToString() != "")
        {
            SqlParameter[] spars = new SqlParameter[2];

            spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars[0].Value = "Schedule";

            spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
            if (ddlScheduletexts.Text.ToString() == "")
                spars[1].Value = DBNull.Value;
            else
                spars[1].Value = ddlScheduletexts.Text.ToString();

            DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");

            if (dt.Rows.Count > 0)
            {
                work_days = Convert.ToInt32(dt.Rows[0]["WORKING_DAYS"]);
            }
        }
        if (ddl_Statustexts.Text.ToString() == "Active")
            tStatus = "A";
        else
            tStatus = "D";
        //decimal projectid = Convert.ToDecimal(ddlLoc_Type.SelectedValue);
        string projectcategorytext = Convert.ToString(commonclass.GetSafeSearchString(ddlLoc_TypeId.Text.Trim()));
        string projectcategorytexts = Convert.ToString(commonclass.GetSafeSearchString(ddlLoc_Typetexts.Text.Trim()));

        string Value = Convert.ToString((txt_Address.Text.Trim()));
        string str = Page.User.Identity.Name;

        if (projectid == "0" || projectid == "" || projectid == null)
        {
            SqlParameter[] spars = new SqlParameter[3];

            spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars[0].Value = "Check_Duplicate_insert";

            spars[1] = new SqlParameter("@comp_code", SqlDbType.VarChar);
            if (Txt_LocCode.Text.ToString() == "")
                spars[1].Value = DBNull.Value;
            else
                spars[1].Value = Txt_LocCode.Text;

            spars[2] = new SqlParameter("@Id", SqlDbType.VarChar);
            spars[2].Value = DBNull.Value;

            DataTable dt = adm.getDuplicate_List(spars, "SP_Admin_Location");

            if (dt.Rows.Count > 0)
            {
                msgsave.Text = "Client / Location with Same Code Already Exists!";
                msgsave.Visible = true;
                return;
            }
            else
            {
                msgsave.Visible = false;
                SqlParameter[] spars1 = new SqlParameter[30];

                spars1[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
                spars1[0].Value = "Insert";

                spars1[1] = new SqlParameter("@comp_code", SqlDbType.VarChar);
                spars1[1].Value = Txt_LocCode.Text.ToString().Trim();
                
                spars1[2] = new SqlParameter("@company_name", SqlDbType.VarChar);
                spars1[2].Value = "Highbar Technocrat Ltd.";
                spars1[3] = new SqlParameter("@isactive", SqlDbType.VarChar);
                spars1[3].Value = tStatus;
                spars1[4] = new SqlParameter("@wrk_schedule", SqlDbType.VarChar);
                spars1[4].Value = work_days.ToString().Trim();
                spars1[5] = new SqlParameter("@view_attendance", SqlDbType.VarChar);
                spars1[5].Value = chk_A.ToString().Trim();
                spars1[6] = new SqlParameter("@view_travls", SqlDbType.VarChar);
                spars1[6].Value = chk_T.ToString().Trim();
                spars1[7] = new SqlParameter("@view_leave", SqlDbType.VarChar);
                spars1[7].Value = chk_L.ToString().Trim();
                spars1[8] = new SqlParameter("@view_fuel", SqlDbType.VarChar);
                spars1[8].Value = chk_F.ToString().Trim();
                spars1[9] = new SqlParameter("@view_mobile", SqlDbType.VarChar);
                spars1[9].Value = chk_M.ToString().Trim();
                spars1[10] = new SqlParameter("@view_paymentVoucher", SqlDbType.VarChar);
                spars1[10].Value = chk_V.ToString().Trim();
                spars1[11] = new SqlParameter("@org_Comp_code", SqlDbType.VarChar);
                spars1[11].Value = "1000";
                spars1[12] = new SqlParameter("@Location_name", SqlDbType.VarChar);
                spars1[12].Value = Txt_LocName.Text.ToString().Trim();
                spars1[13] = new SqlParameter("@ADDRESS", SqlDbType.VarChar);
                spars1[13].Value = txt_Address.Text.ToString().Trim();
                spars1[14] = new SqlParameter("@PIN", SqlDbType.VarChar);
                spars1[14].Value = txt_Pin.Text.ToString().Trim();
                spars1[15] = new SqlParameter("@CITY", SqlDbType.VarChar);
                spars1[15].Value = txt_City.Text.ToString().Trim();
                spars1[16] = new SqlParameter("@STATE", SqlDbType.VarChar);
                spars1[16].Value = txt_State.Text.ToString().Trim();
                spars1[17] = new SqlParameter("@COUNTRY", SqlDbType.VarChar);
                spars1[17].Value = txt_Country.Text.ToString().Trim();
                spars1[18] = new SqlParameter("@TYPE", SqlDbType.VarChar);
                spars1[18].Value = ddlLoc_Typetexts.Text.ToString().Trim();
                spars1[19] = new SqlParameter("@PM", SqlDbType.VarChar);
                spars1[19].Value = ddl_EmployeeId.Text.ToString().Trim();
                spars1[20] = new SqlParameter("@CREATEDBY", SqlDbType.VarChar);
                spars1[20].Value = str.ToString().Trim();
                spars1[21] = new SqlParameter("@SCHEDULE_ID", SqlDbType.Int);
                spars1[21].Value = Convert.ToInt32(ddlScheduleId.Text);

                spars1[22] = new SqlParameter("@Id", SqlDbType.VarChar);
                spars1[22].Value = DBNull.Value;
                spars1[23] = new SqlParameter("@PRM", SqlDbType.VarChar);
                spars1[23].Value = ddl_Employee_PRMId.Text.ToString().Trim();
                spars1[24] = new SqlParameter("@DM", SqlDbType.VarChar);
                spars1[24].Value = ddl_Employee_DMId.Text.ToString().Trim();
                spars1[25] = new SqlParameter("@DH", SqlDbType.VarChar);
                spars1[25].Value = ddl_Employee_DHId.Text.ToString().Trim();

                spars1[26] = new SqlParameter("@SHIFT_Id", SqlDbType.Int);
                spars1[26].Value = DDLShift.SelectedValue.ToString();

                spars1[27] = new SqlParameter("@WorkingDayName", SqlDbType.VarChar);
                spars1[27].Value = DDLWorkingDaysList.SelectedValue.ToString();
                spars1[28] = new SqlParameter("@WeekEnd1", SqlDbType.VarChar);
                spars1[28].Value = DDLWeekEnd1.SelectedValue.ToString();
                spars1[29] = new SqlParameter("@WeekEnd2", SqlDbType.VarChar);
                spars1[29].Value = DDLWeekEnd2.SelectedValue.ToString();

                adm.Insert_Data(spars1, "SP_Admin_Location");

                Response.Redirect(String.Format(ConfigurationManager.AppSettings["sitepathadmin"] + "Location.aspx?faqs={0}&flag=Y", Txt_LocCode.Text.ToString()));
            }
        }
        else
        {
            SqlParameter[] spars = new SqlParameter[3];

            spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars[0].Value = "Check_Duplicate_update";

            spars[1] = new SqlParameter("@comp_code", SqlDbType.VarChar);
            if (Txt_LocCode.Text.ToString() == "")
                spars[1].Value = DBNull.Value;
            else
                spars[1].Value = Txt_LocCode.Text;

            spars[2] = new SqlParameter("@Id", SqlDbType.VarChar);
            spars[2].Value = Convert.ToString(projectid);

            DataTable dt = adm.getDuplicate_List(spars, "SP_Admin_Location");

            if (dt.Rows.Count > 0)
            {
                msgsave.Text = "Client / Location with Same Code Already Exists!";
                msgsave.Visible = true;
                return;
            }
            else
            {
                msgsave.Visible = false;
                SqlParameter[] spars1 = new SqlParameter[30];

                spars1[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
                spars1[0].Value = "Update";

                spars1[1] = new SqlParameter("@comp_code", SqlDbType.VarChar);
                spars1[1].Value = Txt_LocCode.Text.ToString().Trim();

                spars1[2] = new SqlParameter("@company_name", SqlDbType.VarChar);
                spars1[2].Value = "Highbar Technocrat Ltd.";
                spars1[3] = new SqlParameter("@isactive", SqlDbType.VarChar);
                spars1[3].Value = tStatus;
                spars1[4] = new SqlParameter("@wrk_schedule", SqlDbType.VarChar);
                spars1[4].Value = work_days.ToString().Trim();
                spars1[5] = new SqlParameter("@view_attendance", SqlDbType.VarChar);
                spars1[5].Value = chk_A.ToString().Trim();
                spars1[6] = new SqlParameter("@view_travls", SqlDbType.VarChar);
                spars1[6].Value = chk_T.ToString().Trim();
                spars1[7] = new SqlParameter("@view_leave", SqlDbType.VarChar);
                spars1[7].Value = chk_L.ToString().Trim();
                spars1[8] = new SqlParameter("@view_fuel", SqlDbType.VarChar);
                spars1[8].Value = chk_F.ToString().Trim();
                spars1[9] = new SqlParameter("@view_mobile", SqlDbType.VarChar);
                spars1[9].Value = chk_M.ToString().Trim();
                spars1[10] = new SqlParameter("@view_paymentVoucher", SqlDbType.VarChar);
                spars1[10].Value = chk_V.ToString().Trim();
                spars1[11] = new SqlParameter("@org_Comp_code", SqlDbType.VarChar);
                spars1[11].Value = "1000";
                spars1[12] = new SqlParameter("@Location_name", SqlDbType.VarChar);
                spars1[12].Value = Txt_LocName.Text.ToString().Trim();
                spars1[13] = new SqlParameter("@ADDRESS", SqlDbType.VarChar);
                spars1[13].Value = txt_Address.Text.ToString().Trim();
                spars1[14] = new SqlParameter("@PIN", SqlDbType.VarChar);
                spars1[14].Value = txt_Pin.Text.ToString().Trim();
                spars1[15] = new SqlParameter("@CITY", SqlDbType.VarChar);
                spars1[15].Value = txt_City.Text.ToString().Trim();
                spars1[16] = new SqlParameter("@STATE", SqlDbType.VarChar);
                spars1[16].Value = txt_State.Text.ToString().Trim();
                spars1[17] = new SqlParameter("@COUNTRY", SqlDbType.VarChar);
                spars1[17].Value = txt_Country.Text.ToString().Trim();
                spars1[18] = new SqlParameter("@TYPE", SqlDbType.VarChar);
                spars1[18].Value = ddlLoc_Typetexts.Text.ToString().Trim();
                spars1[19] = new SqlParameter("@PM", SqlDbType.VarChar);
                spars1[19].Value = ddl_EmployeeId.Text.ToString().Trim();
                spars1[20] = new SqlParameter("@UPDATEDBY", SqlDbType.VarChar);
                spars1[20].Value = str.ToString().Trim();
                spars1[21] = new SqlParameter("@SCHEDULE_ID", SqlDbType.Int);
                spars1[21].Value = Convert.ToInt32(ddlScheduleId.Text);

                spars1[22] = new SqlParameter("@Id", SqlDbType.VarChar);
                spars1[22].Value = Convert.ToString(projectid);
                spars1[23] = new SqlParameter("@PRM", SqlDbType.VarChar);
                spars1[23].Value = ddl_Employee_PRMId.Text.ToString().Trim();
                spars1[24] = new SqlParameter("@DM", SqlDbType.VarChar);
                spars1[24].Value = ddl_Employee_DMId.Text.ToString().Trim();
                spars1[25] = new SqlParameter("@DH", SqlDbType.VarChar);
                spars1[25].Value = ddl_Employee_DHId.Text.ToString().Trim();

                spars1[26] = new SqlParameter("@SHIFT_Id", SqlDbType.Int);
                spars1[26].Value = DDLShift.SelectedValue.ToString();

                spars1[27] = new SqlParameter("@WorkingDayName", SqlDbType.VarChar);
                spars1[27].Value = DDLWorkingDaysList.SelectedValue.ToString();
                spars1[28] = new SqlParameter("@WeekEnd1", SqlDbType.VarChar);
                spars1[28].Value = DDLWeekEnd1.SelectedValue.ToString();
                spars1[29] = new SqlParameter("@WeekEnd2", SqlDbType.VarChar);
                spars1[29].Value = DDLWeekEnd2.SelectedValue.ToString();

                adm.Insert_Data(spars1, "SP_Admin_Location");

                Response.Redirect(String.Format(ConfigurationManager.AppSettings["sitepathadmin"] + "Location.aspx?faqs={0}&flag=U", projectid.ToString()));
            }
        }
    }

    //private void project()
    //{
    //    throw new NotImplementedException();
    //}
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect(ConfigurationManager.AppSettings["sitepathadmin"] + "Location.aspx");
    }

    //sagar added above dropdown code for project category 20nov2017 ends here

    private void filedelete(string path, string filename)
    {
        string[] st;
        st = Directory.GetFiles(path);
        path += "\\" + filename;
        int i;
        if (filename != "noimage2.gif")
        {
            for (i = 0; i < st.Length; i++)
            {
                try
                {
                    if (st.GetValue(i).ToString() == path)
                    {
                        File.Delete(st.GetValue(i).ToString());
                    }
                }
                catch { }
            }
        }
    }
   
   public void loaddata(string projectid)
    {
       if (projectid == "0")
       {
           return;
       }
       SqlParameter[] spars = new SqlParameter[2];

       spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
       spars[0].Value = "Record";

       spars[1] = new SqlParameter("@comp_code", SqlDbType.VarChar);
       spars[1].Value = Convert.ToString(projectid);

       DataTable tt = adm.getData_FromCode(spars, "SP_Admin_Location");
        //project myproject = classproject.getsingleprojects(projectid);
       if (tt.Rows.Count > 0)
       {
           Txt_LocCode.Text = Convert.ToString(tt.Rows[0]["comp_code"]);
           Txt_LocCode.Enabled = false;
           Btn_Excel.Visible = true;
           Txt_LocName.Text = Convert.ToString(tt.Rows[0]["Location_name"]);
           txt_Address.Text = Convert.ToString(tt.Rows[0]["Address"]);

           ddlScheduleId.Text = Convert.ToString(tt.Rows[0]["SCHEDULE_ID"]);
           ddlScheduletexts.Text = Convert.ToString(tt.Rows[0]["SCHEDULE_DESCR"]) + " - " + Convert.ToString(tt.Rows[0]["WORKING_DAYS"]);
           //ddlSchedule.SelectedItem.Text = ddlScheduletexts.Text;
           ddlSchedule.SelectedValue = ddlScheduleId.Text;
           ddlSchedule.SelectedItem.Value = ddlScheduleId.Text;

            ddl_StatusId.Text = Convert.ToString(tt.Rows[0]["Status"]);
            ddl_Statustexts.Text = Convert.ToString(tt.Rows[0]["Status"]);
            ddl_Status.SelectedValue = ddl_StatusId.Text;
            ddl_Status.SelectedItem.Value = ddl_StatusId.Text;

            WorkDaysList();
           
            DDLWorkingDaysList.Enabled = true;
            DDLWeekEnd1.Enabled = true;
            DDLWeekEnd2.Enabled = true;
            WeeKEnd2();
            

            DDLWorkingDaysListID.Text = Convert.ToString(tt.Rows[0]["WorkingDayName"]);
            DDLWorkingDaysListText.Text = Convert.ToString(tt.Rows[0]["WorkingDayName"]);
            DDLWorkingDaysList.SelectedValue = DDLWorkingDaysListID.Text;
            DDLWorkingDaysList.SelectedItem.Value = DDLWorkingDaysListID.Text;

            DDLWeekEnd1ID.Text = Convert.ToString(tt.Rows[0]["WeekEnd1"]);
            DDLWeekEnd1Text.Text = Convert.ToString(tt.Rows[0]["WeekEnd1"]);
            DDLWeekEnd1.SelectedValue = DDLWeekEnd1ID.Text;
            DDLWeekEnd1.SelectedItem.Value = DDLWeekEnd1ID.Text;

            DDLWeekEnd2ID.Text = Convert.ToString(tt.Rows[0]["WeekEnd2"]);
            DDLWeekEnd2IDText.Text = Convert.ToString(tt.Rows[0]["WeekEnd2"]);
            DDLWeekEnd2.SelectedValue = DDLWeekEnd2ID.Text;
            DDLWeekEnd2.SelectedItem.Value = DDLWeekEnd2ID.Text;

            if (DDLWeekEnd1.SelectedItem.Value == "")
            {
                DDLWeekEnd1.SelectedValue = "0";
            }
            if (DDLWeekEnd2.SelectedItem.Value == "")
            {
                DDLWeekEnd2.SelectedValue = "0";
            }

            

            DDLWeekEnd2.Items.Remove(DDLWeekEnd1.SelectedValue);

            ddlLoc_TypeId.Text = Convert.ToString(tt.Rows[0]["TYPE"]);
           ddlLoc_Typetexts.Text = Convert.ToString(tt.Rows[0]["TYPE"]);
           ddlLoc_Type.SelectedValue = ddlLoc_Typetexts.Text;
           ddlLoc_Type.SelectedItem.Value = ddlLoc_Typetexts.Text;

           ddl_EmployeeId.Text = Convert.ToString(tt.Rows[0]["PM"]);
           ddl_Employeetexts.Text = Convert.ToString(tt.Rows[0]["PM_Name"]);
           ddl_Employee.SelectedValue = ddl_EmployeeId.Text;
           ddl_Employee.SelectedItem.Value = ddl_EmployeeId.Text;

           ddl_Employee_PRMId.Text = Convert.ToString(tt.Rows[0]["PRM"]);
           ddl_Employee_PRMtexts.Text = Convert.ToString(tt.Rows[0]["PRM_Name"]);
           ddl_Employee_PRM.SelectedValue = ddl_Employee_PRMId.Text;
           ddl_Employee_PRM.SelectedItem.Value = ddl_Employee_PRMId.Text;

           ddl_Employee_DMId.Text = Convert.ToString(tt.Rows[0]["DM"]);
           ddl_Employee_DMtexts.Text = Convert.ToString(tt.Rows[0]["DM_Name"]);
           ddl_Employee_DM.SelectedValue = ddl_Employee_DMId.Text;
           ddl_Employee_DM.SelectedItem.Value = ddl_Employee_DMId.Text;

            ddl_Employee_DHId.Text = Convert.ToString(tt.Rows[0]["DH"]);
            ddl_Employee_DHtexts.Text = Convert.ToString(tt.Rows[0]["DH_Name"]);
               if (ddl_Employee_DHId.Text != "")
               {
                   ddl_Employee_DH.SelectedValue = ddl_Employee_DHId.Text;
                   ddl_Employee_DH.SelectedItem.Value = ddl_Employee_DHId.Text;
               }
           
           txt_Pin.Text = Convert.ToString(tt.Rows[0]["PIN"]);
           txt_City.Text = Convert.ToString(tt.Rows[0]["CITY"]);
           txt_State.Text = Convert.ToString(tt.Rows[0]["STATE"]);
           txt_Country.Text = Convert.ToString(tt.Rows[0]["COUNTRY"]);

            DDLShiftID.Text = Convert.ToString(tt.Rows[0]["SHIFT_Id"]);
            DDLShiftTxt.Text = Convert.ToString(tt.Rows[0]["SHIFT_Id"]);
            DDLShift.SelectedValue = Convert.ToString(tt.Rows[0]["SHIFT_Id"]);

            if (Convert.ToString(tt.Rows[0]["view_leave"]) == "Y")
               chk_leave.Checked = true;
           if (Convert.ToString(tt.Rows[0]["view_attendance"]) == "Y")
               chk_att.Checked = true;
           if (Convert.ToString(tt.Rows[0]["view_fuel"]) == "Y")
               chk_Fuel.Checked = true;
           if (Convert.ToString(tt.Rows[0]["view_mobile"]) == "Y")
               chk_Mob.Checked = true;
           if (Convert.ToString(tt.Rows[0]["view_paymentVoucher"]) == "Y")
               chk_vou.Checked = true;
       }
    }

    public void project()
    {
        DataTable dt = classxml.gettopprojectslist();
        if (dt.Rows.Count > 0)
        {
            DataSet ds = new DataSet();
            ds.Tables.Add(dt);
            saveXml(ds, "projectadd.xml");
        }
    }

    public void Fill_Project_Manager()
    {
        string search_str="";
        //if (txt_PM.Text.ToString() == "")
        //    search_str = "";
        //else
        //    search_str = txt_PM.Text.ToString();

        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "Employee";

        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        if (search_str.ToString() == "")
            spars[1].Value = DBNull.Value;
        else
            spars[1].Value = search_str.ToString();

        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");
        ddl_Employee.DataSource = dt;

        ddl_Employee.DataTextField = "empname";
        ddl_Employee.DataValueField = "Emp_Code";
        ddl_Employee.DataBind();
        ListItem item = new ListItem("Select Project Manager", "0");
        ddl_Employee.Items.Insert(0, item);
    }
    public void Fill_Delivery_Manager()
    {
        string search_str = "";
        //if (txt_DM.Text.ToString() == "")
        //    search_str = "";
        //else
        //    search_str = txt_DM.Text.ToString();

        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "Employee";

        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        if (search_str.ToString() == "")
            spars[1].Value = DBNull.Value;
        else
            spars[1].Value = search_str.ToString();

        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");
        ddl_Employee_DM.DataSource = dt;

        ddl_Employee_DM.DataTextField = "empname";
        ddl_Employee_DM.DataValueField = "Emp_Code";
        ddl_Employee_DM.DataBind();
        ListItem item = new ListItem("Select Delivery Manager", "0");
        ddl_Employee_DM.Items.Insert(0, item);
    }
    public void Fill_Delivery_Head()
    {
        string search_str = "";
        //if (txt_DH.Text.ToString() == "")
        //    search_str = "";
        //else
        //    search_str = txt_DH.Text.ToString();

        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "Employee";

        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        if (search_str.ToString() == "")
            spars[1].Value = DBNull.Value;
        else
            spars[1].Value = search_str.ToString();

        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");
        ddl_Employee_DH.DataSource = dt;

        ddl_Employee_DH.DataTextField = "empname";
        ddl_Employee_DH.DataValueField = "Emp_Code";
        ddl_Employee_DH.DataBind();
        ListItem item = new ListItem("Select Delivery Head", "0");
        ddl_Employee_DH.Items.Insert(0, item);
    }
    public void Fill_Program_Manager()
    {
        string search_str = "";
        //if (txt_PRM.Text.ToString() == "")
        //    search_str = "";
        //else
        //    search_str = txt_PRM.Text.ToString();

        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "Employee";

        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        if (search_str.ToString() == "")
            spars[1].Value = DBNull.Value;
        else
            spars[1].Value = search_str.ToString();

        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");
        ddl_Employee_PRM.DataSource = dt;

        ddl_Employee_PRM.DataTextField = "empname";
        ddl_Employee_PRM.DataValueField = "Emp_Code";
        ddl_Employee_PRM.DataBind();
        ListItem item = new ListItem("Select Project Manager", "0");
        ddl_Employee_PRM.Items.Insert(0, item);
    }
    public void Fill_Schedule()
    {
        string search_str = "";
        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "Schedule";
        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        if (search_str.ToString() == "")
            spars[1].Value = DBNull.Value;
        else
            spars[1].Value = search_str.ToString();
        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");
        ddlSchedule.DataSource = dt;
        ddlSchedule.DataTextField = "t_Name";
        ddlSchedule.DataValueField = "t_ID";
        ddlSchedule.DataBind();
        ListItem item = new ListItem("Select Work Schedule", "0");
        ddlSchedule.Items.Insert(0, item);
    }

    public void Fill_Shift()
    {
        string search_str = "";
        SqlParameter[] spars = new SqlParameter[2];
        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "ddl_Shift";
        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        if (search_str.ToString() == "")
            spars[1].Value = DBNull.Value;
        else
            spars[1].Value = search_str.ToString();
        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");
        DDLShift.DataSource = dt;
        DDLShift.DataTextField = "Shift_Name";
        DDLShift.DataValueField = "Shift_Id";
        DDLShift.DataBind();
        ListItem item = new ListItem("Select Shift", "0");
        DDLShift.Items.Insert(0, item);
    }

    public void saveXml(DataSet ds, string filename)
    {
        string fpath = Server.MapPath("xml") + "\\" + filename;
        StreamWriter myStreamWriter = new StreamWriter(@"" + fpath);
        ds.WriteXml(myStreamWriter);
        myStreamWriter.Close();
    }


    //protected void btnSearchPM_Click(object sender, ImageClickEventArgs e)
    //{
    //    Fill_Project_Manager();
    //}

    protected void ddlLoc_Type_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlLoc_Typetexts.Text.ToString().ToLower() == "client")
        {
            PMHeader.Visible = true;
            //txt_PM.Visible = true;
            //btnSearchPM.Visible = true;
            ddl_Employee.Visible = true;
            PRMHeader.Visible = true;
            //txt_PRM.Visible = true;
            //btnSearchPRM.Visible = true;
            ddl_Employee_PRM.Visible = true;
            DMHeader.Visible = true;
            //txt_DM.Visible = true;
            //btnSearchDM.Visible = true;
            ddl_Employee_DM.Visible = true;

            DHHeader.Visible = true;
            //txt_DH.Visible = true;
            //btnSearchDH.Visible = true;
            ddl_Employee_DH.Visible = true;
        }
        else
        {
            PMHeader.Visible = false;
            //txt_PM.Visible = false;
            //btnSearchPM.Visible = false;
            ddl_Employee.Visible = false;
            PRMHeader.Visible = false;
            //txt_PRM.Visible = false;
            //btnSearchPRM.Visible = false;
            ddl_Employee_PRM.Visible = false;
            DMHeader.Visible = false;
            //txt_DM.Visible = false;
            //btnSearchDM.Visible = false;
            ddl_Employee_DM.Visible = false;

            DHHeader.Visible = false;
            //txt_DH.Visible = false;
            //btnSearchDH.Visible = false;
            ddl_Employee_DH.Visible = false;
        }
    }
    //protected void btnSearchPRM_Click(object sender, ImageClickEventArgs e)
    //{
    //    Fill_Program_Manager();
    //}
    //protected void btnSearchDM_Click(object sender, ImageClickEventArgs e)
    //{
    //    Fill_Delivery_Manager();
    //}
    //protected void btnSearchDH_Click(object sender, ImageClickEventArgs e)
    //{
    //    Fill_Delivery_Head();
    //}


    protected void Btn_Excel_Click(object sender, EventArgs e)
    {
        if (Txt_LocCode.Text.ToString().Trim() != "")
        {
            DataTable dtLeaves = new DataTable();
            DataTable dtAttendance = new DataTable();
            DataTable dtTimesheet = new DataTable();
            DataTable dtMobile = new DataTable();
            DataTable dtOtherVoucher = new DataTable();
            DataTable dtFuel = new DataTable();
            DataTable dtTravel = new DataTable();
            SqlParameter[] spars = new SqlParameter[2];

            spars[0] = new SqlParameter("@stype", SqlDbType.VarChar);
            spars[0].Value = "Leaves";

            spars[1] = new SqlParameter("@location_code", SqlDbType.VarChar);
            spars[1].Value = Txt_LocCode.Text.ToString().Trim();

            dtLeaves = getDropdownList(spars, "SP_Admin_PendingApprovals");

            spars = new SqlParameter[2];

            spars[0] = new SqlParameter("@stype", SqlDbType.VarChar);
            spars[0].Value = "Attendance";

            spars[1] = new SqlParameter("@location_code", SqlDbType.VarChar);
            spars[1].Value = Txt_LocCode.Text.ToString().Trim();

            dtAttendance = getDropdownList(spars, "SP_Admin_PendingApprovals");

            spars = new SqlParameter[2];

            spars[0] = new SqlParameter("@stype", SqlDbType.VarChar);
            spars[0].Value = "Timesheet";

            spars[1] = new SqlParameter("@location_code", SqlDbType.VarChar);
            spars[1].Value = Txt_LocCode.Text.ToString().Trim();

            dtTimesheet = getDropdownList(spars, "SP_Admin_PendingApprovals");

            spars = new SqlParameter[2];

            spars[0] = new SqlParameter("@stype", SqlDbType.VarChar);
            spars[0].Value = "Mobile";

            spars[1] = new SqlParameter("@location_code", SqlDbType.VarChar);
            spars[1].Value = Txt_LocCode.Text.ToString().Trim();

            dtMobile = getDropdownList(spars, "SP_Admin_PendingApprovals");

            spars = new SqlParameter[2];

            spars[0] = new SqlParameter("@stype", SqlDbType.VarChar);
            spars[0].Value = "OtherVoucher";

            spars[1] = new SqlParameter("@location_code", SqlDbType.VarChar);
            spars[1].Value = Txt_LocCode.Text.ToString().Trim();

            dtOtherVoucher = getDropdownList(spars, "SP_Admin_PendingApprovals");

            spars = new SqlParameter[2];

            spars[0] = new SqlParameter("@stype", SqlDbType.VarChar);
            spars[0].Value = "Fuel";

            spars[1] = new SqlParameter("@location_code", SqlDbType.VarChar);
            spars[1].Value = Txt_LocCode.Text.ToString().Trim();

            dtFuel = getDropdownList(spars, "SP_Admin_PendingApprovals");

            spars = new SqlParameter[2];

            spars[0] = new SqlParameter("@stype", SqlDbType.VarChar);
            spars[0].Value = "Travel";

            spars[1] = new SqlParameter("@location_code", SqlDbType.VarChar);
            spars[1].Value = Txt_LocCode.Text.ToString().Trim();

            dtTravel = getDropdownList(spars, "SP_Admin_PendingApprovals");


            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dtLeaves, "Leaves");
                wb.Worksheets.Add(dtAttendance, "Attendance");
                wb.Worksheets.Add(dtTimesheet, "Timesheet");
                wb.Worksheets.Add(dtMobile, "Mobile");
                wb.Worksheets.Add(dtFuel, "Fuel");
                wb.Worksheets.Add(dtOtherVoucher, "Other Vouchers");
                wb.Worksheets.Add(dtTravel, "Travel Expenses");

                Response.Clear();
                Response.Buffer = true;
                Response.Charset = "";
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.AddHeader("content-disposition", "attachment;filename=PendingApprovals.xlsx");
                using (MemoryStream MyMemoryStream = new MemoryStream())
                {
                    wb.SaveAs(MyMemoryStream);
                    MyMemoryStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                    Response.End();
                }
            }
        }
    }


    public static DataTable getDropdownList(SqlParameter[] parameters, string strspname)
    {
        DataTable dtUserLogin = new DataTable();
        SqlConnection scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
        if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
            scon.Open();
        SqlCommand sCommand = new SqlCommand();
        sCommand = new SqlCommand();
        sCommand.Connection = scon;
        sCommand.CommandText = strspname;
        sCommand.CommandType = CommandType.StoredProcedure;
        foreach (SqlParameter p in parameters)
        {
            if (p != null)
            {
                sCommand.Parameters.Add(p);
            }
        }
        SqlDataAdapter sadp = new SqlDataAdapter();
        sadp.SelectCommand = sCommand;
        sadp.Fill(dtUserLogin);
        return dtUserLogin;
    }

    protected void ddlSchedule_SelectedIndexChanged(object sender, EventArgs e)
    {
        DDLWeekEnd1.SelectedValue = "0";
        DDLWeekEnd2.SelectedValue = "0";
        DDLWorkingDaysList.Enabled = true;
        DDLWeekEnd1.Enabled = false;
        DDLWeekEnd2.Enabled = false;
        WorkDaysList();
    }

    protected void DDLWeekEnd1_SelectedIndexChanged(object sender, EventArgs e)
    {
        WeeKEnd2();
        DDLWeekEnd2.Items.Remove(DDLWeekEnd1.SelectedValue);
    }

    private void WeeKEnd2()
    {
        DataTable CDT = new DataTable();
        CDT.Clear();
        CDT.Columns.Add("ID");
        CDT.Columns.Add("Week");
        for (int i = 1; i <= 5; i++)
        {
            DataRow DTR = CDT.NewRow();
            DTR[0] = i;
            DTR[1] = i;
            CDT.Rows.Add(DTR);
        }
        DDLWeekEnd2.DataSource = CDT;
        DDLWeekEnd2.DataTextField = "Week";
        DDLWeekEnd2.DataValueField = "ID";
        DDLWeekEnd2.DataBind();
        ListItem item = new ListItem("--Select--", "0");
        DDLWeekEnd2.Items.Insert(0, item);
    }

    private void WorkDaysList()
    {
        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "Schedule";
        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        spars[1].Value = ddlSchedule.SelectedItem.Text;
        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");
        string[] DaysWorkingList;
        if (Convert.ToString(dt.Rows[0]["WORK_DAYS_NAME"]) != "")
        {
            DaysWorkingList = Convert.ToString(dt.Rows[0]["WORK_DAYS_NAME"]).Split(',');
            DataTable CDT = new DataTable();
            CDT.Clear();
            CDT.Columns.Add("ID");
            CDT.Columns.Add("DaysW");

            foreach (string DaysW in DaysWorkingList)
            {
                DataRow DTR = CDT.NewRow();
                if (DaysW.Trim() != "")
                {
                    DTR["ID"] = DaysW.Trim();
                    DTR["DaysW"] = DaysW.Trim();
                    CDT.Rows.Add(DTR);
                }
            }
            DDLWorkingDaysList.DataSource = CDT;
            DDLWorkingDaysList.DataTextField = "DaysW";
            DDLWorkingDaysList.DataValueField = "ID";
            DDLWorkingDaysList.DataBind();
            ListItem item = new ListItem("Working Days List", "0");
            DDLWorkingDaysList.Items.Insert(0, item);
        }
    }

    protected void DDLWorkingDaysList_SelectedIndexChanged(object sender, EventArgs e)
    {
        WeeKEnd2();
       // DDLWeekEnd1.SelectedValue = "0";
        DDLWeekEnd2.SelectedValue = "0";
        DDLWeekEnd1.Enabled = true;
        DDLWeekEnd2.Enabled = true;
       
    }
}
