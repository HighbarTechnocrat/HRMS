

--- SP Name -- SP_Admin_HolidayList

--- Update Below Method

  ELSE IF (@qtype='Insert')   
   BEGIN   

	 if	NOT EXISTS(select * from tblHolidayMst where  Location=@LocationCode  AND Holiday_Date=@holidayDate)--  AND IsActive=1)
	  begin

          Insert Into tblHolidayMst(Holiday_Date,Holiday_Name,Weekday,IsActive,Location,CREATEDBY,CREATEDON,IsWeekend)
	      Values      (@holidayDate,@HolidayName,@Dayname,@ISActive,@LocationCode,@Emp_Code,GETDATE(),'H')
       
	  END
	   
		SELECT @Emp_Code as Emp_Code, 'Data Saved Successfully' as 'Message'  
   
   END 


 ELSE IF (@qtype='Update')   
   BEGIN   
       
	   Update tblHolidayMst Set
	   Location=@LocationCode,
	   Holiday_Name =@HolidayName, Holiday_Date=@holidayDate ,Weekday=@Dayname, IsActive=@ISActive ,IsWeekend='H',
	   UPDATEDBY=@Emp_Code,UPDATEDON=GETDATE() where Holiday_Id=@Id

	   
		SELECT @Emp_Code as Emp_Code, 'Data Saved Successfully' as 'Message'  
   
   END 

 ELSE if (@qtype='list')  
  Begin  
   
   select l.Location as Location_Code,c.Location_name,l.Holiday_Name,
   Case when L.IsActive='1' THEN 'Active' else 'Deactive' end  as IsActive,
   l.Holiday_Id,l.Weekday, CONVERT(varchar(10),l.Holiday_Date,103) as Holidaydate
   from [dbo].[tblHolidayMst] l  
   inner join tbl_hmst_company_Location c on c.comp_code = l.Location and c.isactive='A'
   where  l.Holiday_Name like '%'+IsNull(@Searchtext, l.Holiday_Name)+'%'
          AND (@LocationCode IS NULL OR l.Location=@LocationCode) AND l.IsActive=1 AND L.IsWeekend='H'
   order by L.Holiday_Date DESC
  
  End  

  ELSE IF (@qtype='DuplicateCheck')   
   BEGIN   

	 select l.*,  loc.Location_name, CONVERT(varchar(10),l.Holiday_Date,103) as HolidayDate 
   from tblHolidayMst l   
   inner join tbl_hmst_company_Location loc on loc.comp_code = l.Location 
   where  FORMAT(l.Holiday_Date,'yyyy-MM-dd') =@holidayDate AND  L.Location=@LocationCode AND L.IsWeekend='H' --AND L.IsActive=1 
	   
   END  
