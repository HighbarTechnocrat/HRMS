
-- SP Name -- SP_Admin_GetDropdown

--- Below Method Update

 if @qtype='Schedule'  
  Begin  
   Select t.t_Name, t.t_ID, t.WORKING_DAYS,t.WORK_DAYS_NAME  from    
   (select c.SCHEDULE_ID as t_ID, c.SCHEDULE_DESCR + ' - '  + c.WORKING_DAYS as t_Name, c.WORKING_DAYS,C.WORK_DAYS_NAME From   
   TBL_HRMS_WORKSCHEDULE c ) t where t.t_Name like '%' + IsNull(@SearchString, t.t_Name) + '%'   Order by t.t_Name  
  end 

