

-- Table Name  --- module

Insert Into module(module_name,parententid,pgurl) Values('Work Schedule Add','2','WorkScheduleAdd.aspx')
Insert Into module(module_name,parententid,pgurl) Values('Work Schedule','2','WorkSchedule.aspx')

Select * from module

-- Table Name  --- modulepage

Insert Into modulepage(module_id,pagename)Values('','WorkScheduleAdd.aspx')
Insert Into modulepage(module_id,pagename)Values('','WorkSchedule.aspx')

Select * from module
-- Table Name  --- modulepage

Insert Into rolemodule(module_id,role_id,condition)Values('','Administrator','1')
Insert Into rolemodule(module_id,role_id,condition)Values('','Super Administrator','1')
Insert Into rolemodule(module_id,role_id,condition)Values('','Super Admin','1')

Insert Into rolemodule(module_id,role_id,condition)Values('','Administrator','1')
Insert Into rolemodule(module_id,role_id,condition)Values('','Super Administrator','1')
Insert Into rolemodule(module_id,role_id,condition)Values('','Super Admin','1')