
---- SP name -- Usp_getLeaveDays_ML , Usp_getLeaveDays_ML_6

--- below Method Update

--Check for Holidays while applying leavs
		  declare	@holidaydate date;
		 declare    @ISWeekEnd nvarchar(10)
		  (SELECT @holidaydate =[Holiday_Date] ,@ISWeekEnd=IsWeekend  FROM [tblHolidayMst] 
		 WHERE IsActive=1 and [Holiday_Date] = @FromDate and Location = @Elocation );

		 if (@holidaydate is not null)
		 Begin
			 if(@ISWeekEnd ='H')
				 Begin
                  SELECT 0 as 'TotalDays','Cannot apply leave on the Public holiday' as 'Message', 0 as 'TotalWeekends',0 as 'NoofPublicHoliday'
                  return;
				  END
				 if(@ISWeekEnd ='W')
				 Begin
                  SELECT 0 as 'TotalDays','Cannot apply leave on Weekends' as 'Message', 0 as 'TotalWeekends',0 as 'NoofPublicHoliday'
                  return;
				  END
		 End
		 set @holidaydate=null;
		 set @ISWeekEnd=null;
		   (SELECT @holidaydate=[Holiday_Date],@ISWeekEnd=IsWeekend  FROM [tblHolidayMst] 
		 WHERE IsActive=1 and [Holiday_Date] = @ToDate and Location = @Elocation );

		 if (@holidaydate is not null)
		 Begin
			 if(@ISWeekEnd ='H')
				 Begin
                  SELECT 0 as 'TotalDays','Cannot apply leave on the Public holiday' as 'Message', 0 as 'TotalWeekends',0 as 'NoofPublicHoliday'
                  return;
				  END
				 if(@ISWeekEnd ='W')
				 Begin
                  SELECT 0 as 'TotalDays','Cannot apply leave on Weekends' as 'Message', 0 as 'TotalWeekends',0 as 'NoofPublicHoliday'
                  return;
				  END
		 End