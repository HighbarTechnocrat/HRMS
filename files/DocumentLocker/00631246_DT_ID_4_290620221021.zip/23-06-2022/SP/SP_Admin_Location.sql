

---- SP Name --- SP_Admin_Location

--- New three parameter Add

     ,@WorkingDayName varchar(50) = null,
	 @WeekEnd1 varchar(10) = null,
	 @WeekEnd2 varchar(10) = null

---- Below Method Update

 IF @qtype='Insert' 
	  BEGIN 
		INSERT INTO tbl_hmst_company_Location 
		(comp_code,company_name,isactive,wrk_schedule,view_attendance,view_travls,view_leave,view_fuel
		,view_mobile,view_paymentVoucher,org_Comp_code,Location_name,ADDRESS,PIN,CITY,STATE,COUNTRY,TYPE,PM,PRM
		,CREATEDON,CREATEDBY,SCHEDULE_ID,DM,DH,SHIFT_Id,WorkingDayName,WeekEnd1,WeekEnd2)
		values (@comp_code,@company_name,@isactive,@wrk_schedule,@view_attendance,@view_travls,@view_leave,@view_fuel
		,@view_mobile,@view_paymentVoucher,@org_Comp_code,@Location_name,@ADDRESS,@PIN,@CITY,@STATE,@COUNTRY,@TYPE,@PM
		,@PRM,GETDATE(),@CREATEDBY,@SCHEDULE_ID,@DM,@DH,@SHIFT_Id,@WorkingDayName,@WeekEnd1,@WeekEnd2);

		insert into tbl_hmst_company (comp_code ,company_name ,isactive ,wrk_schedule ,view_attendance ,view_travls ,view_leave ,view_fuel
		,view_mobile ,view_paymentVoucher)
		values (@comp_code, @company_name, @isactive, @wrk_schedule, @view_attendance, @view_travls, @view_leave, @view_fuel, @view_mobile, @view_paymentVoucher);

		insert into tbl_Leave_Approval_Matrix
		select GRADE,CONDITIONTYPE,APPR_ID,APPR_CODE,IS_SELECTED,ISACTIVE, @comp_code from tbl_Leave_Approval_Matrix where LOCATION = 'P-HCC';
		
		insert into tbl_ExitProc_Approval_Matrix
		select APPR_ID,APPR_CODE,IS_SELECTED,@comp_code from tbl_ExitProc_Approval_Matrix where LOCATION = 'P-T-HCC'

		insert into tbl_htravel_leave_extra_approver(approver_emp_code,approver_emp_mail,approver_type,app_remarks,app_id,is_active,location)
		values ('00002726',	'Mangesh.Wadaje@highbartech.com','TD','Travel Desk',100,'A',@comp_code);
		insert into tbl_htravel_leave_extra_approver(approver_emp_code,approver_emp_mail,approver_type,app_remarks,app_id,is_active,location)
		values ('00002726',	'Mangesh.Wadaje@highbartech.com','COS','COS',101,'A',@comp_code);
		insert into tbl_htravel_leave_extra_approver(approver_emp_code,approver_emp_mail,approver_type,app_remarks,app_id,is_active,location)
		values ('99999999',	'accounts@highbartech.com','ACC','Account',102,'A',@comp_code);
		insert into tbl_htravel_leave_extra_approver(approver_emp_code,approver_emp_mail,approver_type,app_remarks,app_id,is_active,location)
		values ('00631019',	'arun.singh@highbartech.com','HRLWP','HR',103,'A',@comp_code);
		insert into tbl_htravel_leave_extra_approver(approver_emp_code,approver_emp_mail,approver_type,app_remarks,app_id,is_active,location)
		values ('00002726',	'Mangesh.Wadaje@highbartech.com','HRML','HR',104,'A',@comp_code);
		insert into tbl_htravel_leave_extra_approver(approver_emp_code,approver_emp_mail,approver_type,app_remarks,app_id,is_active,location)
		values ('00002726',	'Mangesh.Wadaje@highbartech.com','RCOS','COS',105,'A',@comp_code);
		insert into tbl_htravel_leave_extra_approver(approver_emp_code,approver_emp_mail,approver_type,app_remarks,app_id,is_active,location)
		values ('99999999',	'accounts@highbartech.com','RACC','Account',107,'A',@comp_code);
		insert into tbl_htravel_leave_extra_approver(approver_emp_code,approver_emp_mail,approver_type,app_remarks,app_id,is_active,location)
		values ('00002726',	'Mangesh.Wadaje@highbartech.com',	'RCFO',	'COS',106,'A',@comp_code);

		-- Start Code Holiday master Insert
		Declare @StrDates varchar(50) Declare @StrDaysNames varchar(10) Declare @StrWeekNo varchar(10)
		--DECLARE @StartDate DATE = DATEADD(yy, DATEDIFF(yy, 0, GETDATE()), 0),@EndDate DATE = DATEADD(yy, DATEDIFF(yy, 0, GETDATE()) + 1, -1);
		DECLARE @StartDate DATE = GETDATE(),@EndDate DATE = DATEADD(yy, DATEDIFF(yy, 0, GETDATE()) + 1, -1);

		WHILE (@StartDate <= @EndDate)
	    BEGIN 
		      
	          Select @StrDates=DATEADD(DAY, 0, @StartDate) ,@StrDaysNames=DATENAME(weekday, @StartDate), 
	                 @StrWeekNo = datediff(ww,datediff(d,0,dateadd(m,datediff(m,7,@StartDate),0))/7*7,dateadd(d,-1,@StartDate))+1 
	          Insert Into tblHolidayMst(Holiday_Date,Holiday_Name,Weekday,IsActive,Location,WeekNo,IsWeekend,CREATEDBY,CREATEDON)
			  Select                    @StrDates,@StrDaysNames,@StrDaysNames,'1', @comp_code,@StrWeekNo,'W',@CREATEDBY,GETDATE()
			  where                     @StrDaysNames=@WorkingDayName AND (@StrWeekNo =@WeekEnd1 OR @StrWeekNo =@WeekEnd2)

	          SET @StartDate = DATEADD(DAY, 1, @StartDate); /*increment current date*/
        END

		 Update tblHolidayMst set Holiday_Name= 'First ' + Weekday where IsWeekend='W' AND WeekNo=1 and Location=@comp_code
		 Update tblHolidayMst set Holiday_Name= 'Second ' + Weekday where IsWeekend='W' AND WeekNo=2 and Location=@comp_code
		 Update tblHolidayMst set Holiday_Name= 'Third ' + Weekday where IsWeekend='W' AND WeekNo=3 and Location=@comp_code
		 Update tblHolidayMst set Holiday_Name= 'Fourth ' + Weekday where IsWeekend='W' AND WeekNo=4 and Location=@comp_code
		 Update tblHolidayMst set Holiday_Name= 'Fifth ' + Weekday where IsWeekend='W' AND WeekNo=5 and Location=@comp_code
		 
		 -- END Code Holiday master Insert

		SELECT @comp_code as comp_code, 'Location Created Successfully' as 'Message'
	
	  END

	 IF @qtype='Update' 
	  BEGIN 
		Update tbl_hmst_company_Location set 
			--comp_code = @comp_code,
			Location_name = @Location_name,
			isactive=@isactive,
			wrk_schedule=@wrk_schedule,
			view_attendance=@view_attendance,
			view_travls=@view_travls,
			view_leave=@view_leave,
			view_fuel=@view_fuel,
			view_mobile=@view_mobile,
			view_paymentVoucher=@view_paymentVoucher,
			ADDRESS=@ADDRESS,
			PIN=@PIN,
			CITY=@CITY,
			STATE=@STATE,
			COUNTRY=@COUNTRY,
			TYPE=@TYPE,
			PM=@PM,
			PRM=@PRM,
			DM=@DM,
			DH=@DH,
			SHIFT_Id=@SHIFT_Id,
			UPDATEDON=GETDATE(),
			UPDATEDBY=@UPDATEDBY,
			SCHEDULE_ID=@SCHEDULE_ID,
			WorkingDayName =@WorkingDayName,
			WeekEnd1=@WeekEnd1,
			WeekEnd2 =@WeekEnd2
			where comp_code = @Id;

		update tbl_hmst_company set 
		--comp_code =@comp_code,
		  company_name=@company_name
		  ,isactive=@isactive
		  ,wrk_schedule=@wrk_schedule
		  ,view_attendance=@view_attendance
		  ,view_travls=@view_travls
		  ,view_leave=@view_leave
		  ,view_fuel=@view_fuel
		  ,view_mobile=@view_mobile
		  ,view_paymentVoucher=@view_paymentVoucher
		  where comp_code = @Id;

		  -- Start Code Holiday master Update
		Declare @UpStrDates varchar(50) Declare @UpStrDaysNames varchar(10) Declare @UpStrWeekNo varchar(10)
		DECLARE @UpStartDate DATE = GETDATE(),@UpEndDate DATE = DATEADD(yy, DATEDIFF(yy, 0, GETDATE()) + 1, -1);

		WHILE (@UpStartDate <= @UpEndDate)
	    BEGIN 
		      Delete from tblHolidayMst where IsWeekend='W' and Location =@comp_code AND @UpStartDate <  Holiday_Date

	          Select @UpStrDates=DATEADD(DAY, 0, @UpStartDate) ,@UpStrDaysNames=DATENAME(weekday, @UpStartDate), 
	                 @UpStrWeekNo = datediff(ww,datediff(d,0,dateadd(m,datediff(m,7,@UpStartDate),0))/7*7,dateadd(d,-1,@UpStartDate))+1 

              Insert Into tblHolidayMst(Holiday_Date,Holiday_Name,Weekday,IsActive,Location,WeekNo,IsWeekend,UPDATEDBY,UPDATEDON)
			  Select                    @UpStrDates,@UpStrDaysNames,@UpStrDaysNames,'1', @comp_code,@UpStrWeekNo,'W',@CREATEDBY,GETDATE()
			  where                     @UpStrDaysNames=@WorkingDayName AND (@UpStrWeekNo =@WeekEnd1 OR @UpStrWeekNo =@WeekEnd2)
           
	          SET @UpStartDate = DATEADD(DAY, 1, @UpStartDate); /*increment current date*/
        END

		DECLARE @UpdateStartDate DATE = GETDATE()

		 Update tblHolidayMst set Holiday_Name= 'First ' + Weekday where IsWeekend='W' AND WeekNo=1 AND Location =@comp_code  AND Holiday_Date > @UpdateStartDate
		 Update tblHolidayMst set Holiday_Name= 'Second ' + Weekday where IsWeekend='W' AND WeekNo=2 AND Location =@comp_code AND Holiday_Date > @UpdateStartDate
		 Update tblHolidayMst set Holiday_Name= 'Third ' + Weekday where IsWeekend='W' AND WeekNo=3 AND Location =@comp_code  AND Holiday_Date > @UpdateStartDate
		 Update tblHolidayMst set Holiday_Name= 'Fourth ' + Weekday where IsWeekend='W' AND WeekNo=4 AND Location =@comp_code AND Holiday_Date > @UpdateStartDate
		 Update tblHolidayMst set Holiday_Name= 'Fifth ' + Weekday where IsWeekend='W' AND WeekNo=5 AND Location =@comp_code  AND Holiday_Date > @UpdateStartDate
		 
		 -- END Code Holiday Master Update

	  	if @TYPE = 'CLIENT'
		begin
			set @RM = @PM;
			set @HOD = (select A_EMP_CODE from tbl_Employee_OMStructure where EMP_CODE=@PRM and APPR_ID=1);
			set @RMDHOD = (select A_EMP_CODE from tbl_Employee_OMStructure where APPR_CODE = 'RM' and EMP_CODE=@HOD);
			SET @HOD = @DH;

			update tbl_Approval_Status set 
				approver_emp_code = @RM
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (1) and Action='Pending';

			update tbl_Approval_Status set 
				approver_emp_code = @DM
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (3) and Action='Pending';

			update tbl_Approval_Status set 
				approver_emp_code = @PRM
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (5) and Action='Pending';

			update tbl_Approval_Status set 
				approver_emp_code = @HOD
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (7) and Action='Pending';

			update tbl_Approval_Status_cancellation set 
				approver_emp_code = @RM
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (1) and Action='Pending';

			update tbl_Approval_Status_cancellation set 
				approver_emp_code = @DM
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (3) and Action='Pending';

			update tbl_Approval_Status_cancellation set 
				approver_emp_code = @PRM
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (5) and Action='Pending';

			update tbl_Approval_Status_cancellation set 
				approver_emp_code = @HOD
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (7) and Action='Pending';

			update tbl_Mobile_Approval_Status set 
				approver_emp_code = @RM
				where Rem_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (1) and Action='Pending';

			update tbl_Mobile_Approval_Status set 
				approver_emp_code = @DM
				where Rem_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (3) and Action='Pending';

			update tbl_Mobile_Approval_Status set 
				approver_emp_code = @PRM
				where Rem_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (5) and Action='Pending';

			update tbl_Mobile_Approval_Status set 
				approver_emp_code = @HOD
				where Rem_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (7) and Action='Pending';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @RM
				where Proc_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (1) and Action='Pending' and Proc_desc='MOB';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @DM
				where Proc_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (3) and Action='Pending' and Proc_desc='MOB';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @PRM
				where Proc_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (5) and Action='Pending' and Proc_desc='MOB';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @HOD
				where Proc_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (7) and Action='Pending' and Proc_desc='MOB';

			update tbl_Payment_Approval_Status set 
				approver_emp_code = @RM
				where Rem_id in (select Rem_id from tbl_Payment_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (1) and Action='Pending';

			update tbl_Payment_Approval_Status set 
				approver_emp_code = @DM
				where Rem_id in (select Rem_id from tbl_Payment_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (3) and Action='Pending';

			update tbl_Payment_Approval_Status set 
				approver_emp_code = @PRM
				where Rem_id in (select Rem_id from tbl_Payment_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (5) and Action='Pending';

			update tbl_Payment_Approval_Status set 
				approver_emp_code = @HOD
				where Rem_id in (select Rem_id from tbl_Payment_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (7) and Action='Pending';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @RM
				where Proc_id  in (select Rem_id from tbl_Payment_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (1) and Action='Pending' and Proc_desc='VOU';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @DM
				where Proc_id  in (select Rem_id from tbl_Payment_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (3) and Action='Pending' and Proc_desc='VOU';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @PRM
				where Proc_id  in (select Rem_id from tbl_Payment_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (5) and Action='Pending' and Proc_desc='VOU';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @HOD
				where Proc_id  in (select Rem_id from tbl_Payment_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (7) and Action='Pending' and Proc_desc='VOU';

			update tbl_Fuel_Approval_Status set 
				approver_emp_code = @RM
				where Rem_id in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (1) and Action='Pending';

			update tbl_Fuel_Approval_Status set 
				approver_emp_code = @DM
				where Rem_id in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (3) and Action='Pending';

			update tbl_Fuel_Approval_Status set 
				approver_emp_code = @PRM
				where Rem_id in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (5) and Action='Pending';

			update tbl_Fuel_Approval_Status set 
				approver_emp_code = @HOD
				where Rem_id in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (7) and Action='Pending';

			update tbl_Audit_Trail_All  set 
				approver_emp_code = @RM
				where Proc_id  in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (1) and Action='Pending' and Proc_desc='FUL';

			update tbl_Audit_Trail_All  set 
				approver_emp_code = @DM
				where Proc_id  in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (3) and Action='Pending' and Proc_desc='FUL';

			update tbl_Audit_Trail_All  set 
				approver_emp_code = @PRM
				where Proc_id  in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (5) and Action='Pending' and Proc_desc='FUL';

			update tbl_Audit_Trail_All  set 
				approver_emp_code = @HOD
				where Proc_id  in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (7) and Action='Pending' and Proc_desc='FUL';

			update tbl_Expense_Approval_Status set 
				approver_emp_code = @RM
				where exp_id in (select exp_id from tbl_Exptravel_request_main where emp_code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (1) and Action='Pending';

			update tbl_Expense_Approval_Status set 
				approver_emp_code = @DM
				where exp_id in (select exp_id from tbl_Exptravel_request_main where emp_code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (3) and Action='Pending';

			update tbl_Expense_Approval_Status set 
				approver_emp_code = @PRM
				where exp_id in (select exp_id from tbl_Exptravel_request_main where emp_code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (5) and Action='Pending';

			update tbl_Expense_Approval_Status set 
				approver_emp_code = @HOD
				where exp_id in (select exp_id from tbl_Exptravel_request_main where emp_code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (7) and Action='Pending';

			update tbl_Audit_Trail_All  set 
				approver_emp_code = @RM
				where Proc_id  in (select exp_id from tbl_Exptravel_request_main where emp_code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (1) and Action='Pending' and Proc_desc='TRV';

			update tbl_Audit_Trail_All  set 
				approver_emp_code = @DM
				where Proc_id  in (select exp_id from tbl_Exptravel_request_main where emp_code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (3) and Action='Pending' and Proc_desc='TRV';

			update tbl_Audit_Trail_All  set 
				approver_emp_code = @PRM
				where Proc_id  in (select exp_id from tbl_Exptravel_request_main where emp_code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (5) and Action='Pending' and Proc_desc='TRV';

			update tbl_Audit_Trail_All  set 
				approver_emp_code = @HOD
				where Proc_id  in (select exp_id from tbl_Exptravel_request_main where emp_code in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM)) 
				and Appr_id in (7) and Action='Pending' and Proc_desc='TRV';

			update tbl_Employee_OMStructure set
			A_EMP_CODE = @RM,
			A_GRADE = (select grade from tbl_Employee_Mst where Emp_Code = @RM),
			A_ROLE = (select grade from tbl_Employee_Mst where Emp_Code = @RM),
			a_emails = (select Emp_Emailaddress from tbl_Employee_Mst where Emp_Code = @RM)
			where EMP_CODE in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM) 
			and APPR_ID in (1);

			update tbl_Employee_OMStructure set
			A_EMP_CODE = @DM,
			A_GRADE = (select grade from tbl_Employee_Mst where Emp_Code = @DM),
			A_ROLE = (select grade from tbl_Employee_Mst where Emp_Code = @DM),
			a_emails = (select Emp_Emailaddress from tbl_Employee_Mst where Emp_Code = @DM)
			where EMP_CODE in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM) 
			and APPR_ID in (3);
			--@HOD
			update tbl_Employee_OMStructure set
			A_EMP_CODE = @PRM,
			A_GRADE = (select grade from tbl_Employee_Mst where Emp_Code = @PRM),
			A_ROLE = (select grade from tbl_Employee_Mst where Emp_Code = @PRM),
			a_emails = (select Emp_Emailaddress from tbl_Employee_Mst where Emp_Code = @PRM)
			where EMP_CODE in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM) 
			and APPR_ID in (5);
			--@RMDHOD
			update tbl_Employee_OMStructure set
			A_EMP_CODE = @HOD,
			A_GRADE = (select grade from tbl_Employee_Mst where Emp_Code = @HOD),
			A_ROLE = (select grade from tbl_Employee_Mst where Emp_Code = @HOD),
			a_emails = (select Emp_Emailaddress from tbl_Employee_Mst where Emp_Code = @HOD)
			where EMP_CODE in (select Emp_Code from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM) 
			and APPR_ID in (7);

						
			declare @count bigint;
			declare @tempcode varchar(10) = NULL;
			select @count = (select count(*) from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM);
			declare ShiftCursor cursor for select Emp_Code as tempcode from tbl_Employee_Mst where emp_location = @Id and emp_status='OnBoard' AND EMP_CODE != @PM;
			open ShiftCursor 
			--select @count as msg;
			while @count > 0
				begin
					fetch ShiftCursor into @tempcode
					declare @empId int;
					set @empId = (select emp_id from tbl_Employee_Mst where Emp_Code = @tempcode);
					declare @RM_old varchar(10) = null;
					set @RM_old = (select RM from TBL_HRMS_EMPLOYEE_RM where EMP_ID= @empId and END_DATE is null);
					update TBL_HRMS_EMPLOYEE_RM set 
					END_DATE = FORMAT(DATEADD(day,-1,GETDATE()), 'yyyy-MM-dd'),
					UPDATEDBY = @CREATEDBY, UPDATEDON=GETDATE()
					where EMP_ID= @empId and END_DATE is null;

					insert into TBL_HRMS_EMPLOYEE_RM (EMP_ID,EMP_CODE,RM,RM_OLD,START_DATE,END_DATE,CREATEDON,CREATEDBY)
					values (@empId,@tempcode,@RM,@RM_old,FORMAT(GETDATE(), 'yyyy-MM-dd'),NULL,GETDATE(),@CREATEDBY);

					set @count = @count - 1;
				end
			close ShiftCursor; 
			deallocate ShiftCursor;


			if (@PM = @DM)
				begin
					set @DM = @PRM;
				end
			if (@PM = @PRM)
				begin
					set @DM = @HOD;
					set @PRM = @HOD;
				end
			update tbl_Approval_Status set 
				approver_emp_code = @DM
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code = @PM) 
				and Appr_id in (1) and Action='Pending';

			update tbl_Approval_Status set 
				approver_emp_code = @PRM
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code = @PM) 
				and Appr_id in (3) and Action='Pending';

			update tbl_Approval_Status set 
				approver_emp_code = @PRM
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code = @PM) 
				and Appr_id in (5) and Action='Pending';

			update tbl_Approval_Status set 
				approver_emp_code = @HOD
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code = @PM)
				and Appr_id in (7) and Action='Pending';

			update tbl_Approval_Status_cancellation set 
				approver_emp_code = @DM
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code = @PM) 
				and Appr_id in (1) and Action='Pending';

			update tbl_Approval_Status_cancellation set 
				approver_emp_code = @PRM
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code = @PM) 
				and Appr_id in (3) and Action='Pending';

			update tbl_Approval_Status_cancellation set 
				approver_emp_code = @PRM
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code = @PM) 
				and Appr_id in (5) and Action='Pending';

			update tbl_Approval_Status_cancellation set 
				approver_emp_code = @HOD
				where Req_id in (select Req_id from tblLeaveDetails where Emp_Code = @PM) 
				and Appr_id in (7) and Action='Pending';

			update tbl_Mobile_Approval_Status set 
				approver_emp_code = @DM
				where Rem_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode = @PM) 
				and Appr_id in (1) and Action='Pending';

			update tbl_Mobile_Approval_Status set 
				approver_emp_code = @PRM
				where Rem_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode = @PM) 
				and Appr_id in (3) and Action='Pending';

			update tbl_Mobile_Approval_Status set 
				approver_emp_code = @PRM
				where Rem_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode = @PM) 
				and Appr_id in (5) and Action='Pending';

			update tbl_Mobile_Approval_Status set 
				approver_emp_code = @HOD
				where Rem_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode = @PM) 
				and Appr_id in (7) and Action='Pending';

			update tbl_Payment_Approval_Status set 
				approver_emp_code = @DM
				where Rem_id in (select Rem_id from tbl_Payment_Remb_Main where EmpCode = @PM) 
				and Appr_id in (1) and Action='Pending';

			update tbl_Payment_Approval_Status set 
				approver_emp_code = @PRM
				where Rem_id in (select Rem_id from tbl_Payment_Remb_Main where EmpCode = @PM) 
				and Appr_id in (3) and Action='Pending';

			update tbl_Payment_Approval_Status set 
				approver_emp_code = @PRM
				where Rem_id in (select Rem_id from tbl_Payment_Remb_Main where EmpCode = @PM) 
				and Appr_id in (5) and Action='Pending';

			update tbl_Payment_Approval_Status set 
				approver_emp_code = @HOD
				where Rem_id in (select Rem_id from tbl_Payment_Remb_Main where EmpCode = @PM) 
				and Appr_id in (7) and Action='Pending';

			update tbl_Fuel_Approval_Status set 
				approver_emp_code = @DM
				where Rem_id in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode = @PM) 
				and Appr_id in (1) and Action='Pending';

			update tbl_Fuel_Approval_Status set 
				approver_emp_code = @PRM
				where Rem_id in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode = @PM) 
				and Appr_id in (3) and Action='Pending';

			update tbl_Fuel_Approval_Status set 
				approver_emp_code = @PRM
				where Rem_id in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode = @PM) 
				and Appr_id in (5) and Action='Pending';

			update tbl_Fuel_Approval_Status set 
				approver_emp_code = @HOD
				where Rem_id in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode = @PM) 
				and Appr_id in (7) and Action='Pending';

			update tbl_Expense_Approval_Status set 
				approver_emp_code = @DM
				where exp_id in (select exp_id from tbl_Exptravel_request_main where emp_code = @PM) 
				and Appr_id in (1) and Action='Pending';

			update tbl_Expense_Approval_Status set 
				approver_emp_code = @PRM
				where exp_id in (select exp_id from tbl_Exptravel_request_main where emp_code = @PM) 
				and Appr_id in (3) and Action='Pending';

			update tbl_Expense_Approval_Status set 
				approver_emp_code = @PRM
				where exp_id in (select exp_id from tbl_Exptravel_request_main where emp_code = @PM) 
				and Appr_id in (5) and Action='Pending';

			update tbl_Expense_Approval_Status set 
				approver_emp_code = @HOD
				where exp_id in (select exp_id from tbl_Exptravel_request_main where emp_code = @PM) 
				and Appr_id in (7) and Action='Pending';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @DM
				where Proc_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode = @PM) 
				and Appr_id in (1) and Action='Pending' and Proc_desc='MOB';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @PRM
				where Proc_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode = @PM) 
				and Appr_id in (3) and Action='Pending' and Proc_desc='MOB';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @PRM
				where Proc_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode = @PM) 
				and Appr_id in (5) and Action='Pending' and Proc_desc='MOB';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @HOD
				where Proc_id in (select Rem_id from tbl_Mobile_Remb_Main where EmpCode = @PM) 
				and Appr_id in (7) and Action='Pending' and Proc_desc='MOB';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @DM
				where Proc_id in (select Rem_id from tbl_Payment_Remb_Main where EmpCode = @PM) 
				and Appr_id in (1) and Action='Pending' and Proc_desc='VOU';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @PRM
				where Proc_id in (select Rem_id from tbl_Payment_Remb_Main where EmpCode = @PM) 
				and Appr_id in (3) and Action='Pending' and Proc_desc='VOU';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @PRM
				where Proc_id in (select Rem_id from tbl_Payment_Remb_Main where EmpCode = @PM) 
				and Appr_id in (5) and Action='Pending' and Proc_desc='VOU';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @HOD
				where Proc_id in (select Rem_id from tbl_Payment_Remb_Main where EmpCode = @PM) 
				and Appr_id in (7) and Action='Pending' and Proc_desc='VOU';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @DM
				where Proc_id in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode = @PM) 
				and Appr_id in (1) and Action='Pending' and Proc_desc='FUL';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @PRM
				where Proc_id in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode = @PM) 
				and Appr_id in (3) and Action='Pending' and Proc_desc='FUL';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @PRM
				where Proc_id in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode = @PM) 
				and Appr_id in (5) and Action='Pending' and Proc_desc='FUL';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @HOD
				where Proc_id in (select Rem_id from tbl_Fuel_Remb_Main where EmpCode = @PM) 
				and Appr_id in (7) and Action='Pending' and Proc_desc='FUL';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @DM
				where Proc_id in (select exp_id from tbl_Exptravel_request_main where emp_code = @PM) 
				and Appr_id in (1) and Action='Pending' and Proc_desc='TRV';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @PRM
				where Proc_id in (select exp_id from tbl_Exptravel_request_main where emp_code = @PM) 
				and Appr_id in (3) and Action='Pending' and Proc_desc='TRV';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @PRM
				where Proc_id in (select exp_id from tbl_Exptravel_request_main where emp_code = @PM) 
				and Appr_id in (5) and Action='Pending' and Proc_desc='TRV';

			update tbl_Audit_Trail_All set 
				approver_emp_code = @HOD
				where Proc_id in (select exp_id from tbl_Exptravel_request_main where emp_code = @PM) 
				and Appr_id in (7) and Action='Pending' and Proc_desc='TRV';


			update tbl_Employee_OMStructure set
			A_EMP_CODE = @DM,
			A_GRADE = (select grade from tbl_Employee_Mst where Emp_Code = @DM),
			A_ROLE = (select grade from tbl_Employee_Mst where Emp_Code = @DM),
			a_emails = (select Emp_Emailaddress from tbl_Employee_Mst where Emp_Code = @DM)
			where EMP_CODE = @PM
			and APPR_ID in (1);

			update tbl_Employee_OMStructure set
			A_EMP_CODE = @PRM,
			A_GRADE = (select grade from tbl_Employee_Mst where Emp_Code = @PRM),
			A_ROLE = (select grade from tbl_Employee_Mst where Emp_Code = @PRM),
			a_emails = (select Emp_Emailaddress from tbl_Employee_Mst where Emp_Code = @PRM)
			where EMP_CODE = @PM 
			and APPR_ID in (3);
			--@HOD
			update tbl_Employee_OMStructure set
			A_EMP_CODE = @PRM,
			A_GRADE = (select grade from tbl_Employee_Mst where Emp_Code = @PRM),
			A_ROLE = (select grade from tbl_Employee_Mst where Emp_Code = @PRM),
			a_emails = (select Emp_Emailaddress from tbl_Employee_Mst where Emp_Code = @PRM)
			where EMP_CODE = @PM  
			and APPR_ID in (5);
			--@RMDHOD
			update tbl_Employee_OMStructure set
			A_EMP_CODE = @HOD,
			A_GRADE = (select grade from tbl_Employee_Mst where Emp_Code = @HOD),
			A_ROLE = (select grade from tbl_Employee_Mst where Emp_Code = @HOD),
			a_emails = (select Emp_Emailaddress from tbl_Employee_Mst where Emp_Code = @HOD)
			where EMP_CODE = @PM  
			and APPR_ID in (7);
		end

		SELECT @comp_code as comp_code, 'Location Updated Successfully' as 'Message'
	
	  END