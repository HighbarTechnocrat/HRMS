

--- Add New Fields in this Table (tbl_hmst_company_Location)

ALTER TABLE tbl_hmst_company_Location
ADD WorkingDayName varchar(50),
 WeekEnd1 varchar(10),
 WeekEnd2 varchar(10);



---- Add New Fields in this Table (tblHolidayMst)

 Alter Table tblHolidayMst
 Add WeekNo varchar(10),
 IsWeekend  varchar(10)
