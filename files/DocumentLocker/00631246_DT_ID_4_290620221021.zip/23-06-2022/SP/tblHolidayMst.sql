
---- Table Name -- tblHolidayMst

--- Update Record's

Update tblHolidayMst set IsWeekend='H' where Holiday_Name Not IN ('Second Saturday','Fourth Saturday','4th Saturday','2nd Saturday','Third Saturday')
Update tblHolidayMst set IsWeekend='W' where  Holiday_Name  IN ('Second Saturday','Fourth Saturday','4th Saturday','2nd Saturday','Third Saturday')

--Select * from tblHolidayMst where Holiday_Name  IN ('Second Saturday','Fourth Saturday','4th Saturday','2nd Saturday','Third Saturday')