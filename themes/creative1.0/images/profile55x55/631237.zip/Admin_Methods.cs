﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Configuration;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Text;
using System.Data.Common;


using System.Security.Cryptography;
using System.IO;

/// <summary>
/// Summary description for Admin_Methods
/// </summary>
public class Admin_Methods
{
    #region Global_variables
    public string connection = ConfigurationManager.ConnectionStrings["sqlconnection"].ConnectionString;
    SqlConnect sql = new SqlConnect();

    public int MaxRequestId;
    string loginUserid = "1";

    String strexp = "";
    //Leave_Request_Parameters lpm = new Leave_Request_Parameters ();

    public DataTable dtEmployee, dtLeavebalance, dtLeaveType, dtApproverEmailId, dtRequestId, dtApproverName, dtIntermediateName, dtLeaveCalculate, dtHolidaydate, dtLeaveRequest, dtLeaveDetails;
    public DataSet dsLeaveRqust;
    SqlConnection scon = null;
    SqlCommand sCommand = null;
    SqlDataReader sReader = null;
    SqlDataAdapter sadp = null;
    #endregion
	public Admin_Methods()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public DataTable getDuplicate_List(SqlParameter[] parameters, string strspname)
    {
        DataTable dtUserLogin = new DataTable();
        try
        {
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
            {
                scon.Open();
            }

            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandText = strspname;
            sCommand.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter p in parameters)
            {
                if (p != null)
                {
                    sCommand.Parameters.Add(p);
                }
            }

            sadp = new SqlDataAdapter();
            sadp.SelectCommand = sCommand;
            sadp.Fill(dtUserLogin);
            return dtUserLogin;
        }
        catch (Exception)
        {
        }
        finally
        {
            scon.Close();
        }
        return dtUserLogin;

    }
    public DataTable getDataList(SqlParameter[] parameters, string strspname)
    {
        DataTable dtUserLogin = new DataTable();
        try
        {
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
            {
                scon.Open();
            }

            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandText = strspname;
            sCommand.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter p in parameters)
            {
                if (p != null)
                {
                    sCommand.Parameters.Add(p);
                }
            }
            sadp = new SqlDataAdapter();
            sadp.SelectCommand = sCommand;
            sadp.Fill(dtUserLogin);
            return dtUserLogin;
        }
        catch (Exception)
        {
        }
        finally
        {
            scon.Close();
        }
        return dtUserLogin;

    }
    public DataTable getData_FromCode(SqlParameter[] parameters, string strspname)
    {
        DataTable dtUserLogin = new DataTable();
        try
        {
            
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
            {
                scon.Open();
            }

            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandText = strspname;
            sCommand.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter p in parameters)
            {
                if (p != null)
                {
                    sCommand.Parameters.Add(p);
                }
            }
            sadp = new SqlDataAdapter();
            sadp.SelectCommand = sCommand;
            sadp.Fill(dtUserLogin);
            return dtUserLogin;
        }
        catch (Exception)
        {
        }
        finally
        {
            scon.Close();
        }
        return dtUserLogin;

    }
    public void Insert_Data(SqlParameter[] parameters, string strspname)
    {

        try
        {
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
            {
                scon.Open();
            } 

            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandText = strspname;
            sCommand.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter p in parameters)
            {
                if (p != null)
                {
                    sCommand.Parameters.Add(p);
                }
            }

            sCommand.ExecuteNonQuery();
        }
        catch (Exception)
        {
        }
        finally
        {
            scon.Close();
        }

    }
    public DataTable getDropdownList(SqlParameter[] parameters, string strspname)
    {
        DataTable dtUserLogin = new DataTable();
        try
        {
            
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
            {
                scon.Close();
                scon.Open();
            }
            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandText = strspname;
            sCommand.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter p in parameters)
            {
                if (p != null)
                {
                    sCommand.Parameters.Add(p);
                }
            }
            sadp = new SqlDataAdapter();
            sadp.SelectCommand = sCommand;
            sadp.Fill(dtUserLogin);
            return dtUserLogin;
        }
        catch (Exception)
        {
        }
        finally
        {
            scon.Close();
        }
        return dtUserLogin;
    }

    public void send_mailto_RM_Approver(string Emp_Name, string ReqMailID, string toMailIDs, string strsubject, string tType, string tDays, string tRemarks, string tFrom, string tFrom_For, string tTo, string tTo_For, string ccmailid, string strLeaveReqstURL, string applist, string strinertmediaterList)
    {
        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient();
        StringBuilder strbuild = new StringBuilder();
        DataTable dt_emp = new DataTable();
        //Emp_Name = "";
        //dt_emp = GetEmployeeData_Email(ReqMailID.ToString());
        //Emp_Name = dt_emp.Rows[0]["Emp_Name"].ToString();

        strsubject = strsubject + " of " + Emp_Name;
        try
        {
            strbuild = new StringBuilder();
            if (loginUserid == "1")
            {
                strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Arial;font-style:Regular;width:100%'><tr><td>   ");
                strbuild.Append("</td></tr>");
                strbuild.Append("<tr><td style='height:20px'></td></tr>");
                strbuild.Append("<tr><td> " + Emp_Name + " has applied for leave as per the details below. Request your approval please.</td></tr>");
                strbuild.Append("<tr><td style='height:20px'></td></tr>");
                strbuild.Append("<tr><td>");
                strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Arial;font-style:Regular;width:95%'>");
                strbuild.Append("<tr><td>Leave Type :</td><td colspan=2> " + tType + "</td></tr>");
                strbuild.Append("<tr><td>From :</td><td> " + tFrom + " - " + tFrom_For + "</td><td></td></tr>");
                strbuild.Append("<tr><td>To :</td><td> " + tTo + " - " + tTo_For + "</td><td></td></tr>");
                strbuild.Append("<tr><td>Leave Days :</td><td> " + tDays + "</td></tr>");
                strbuild.Append("<tr><td>Remarks :</td><td colspan=2> " + tRemarks + "</td></tr>");
                strbuild.Append("<tr><td>Status :</td><td colspan=2>" + applist + "</td></tr>");
                if (Convert.ToString(strinertmediaterList).Trim() != "")
                    strbuild.Append("<tr><td>For Information To :</td><td colspan=2>" + strinertmediaterList + "</td></tr>");
                strbuild.Append("</table>");
                strbuild.Append("</td></tr>");
                strbuild.Append("<tr><td style='height:20px'></td></tr>");
                //strbuild.Append("<tr><td style='height:20px'><a herf='InboxLeave_Req.aspx' title='Please click here to review / approve'> Please click here to review / approve</a></td></tr>");
                strbuild.Append("<tr><td style='height:20px'><a href='" + strLeaveReqstURL + "'> Please click here to review / approve </a></td></tr>");
                strbuild.Append("</table>");
            }

            sendMail(toMailIDs, strsubject, Convert.ToString(strbuild).Trim(), "", ccmailid);


        }
        catch (Exception ex)
        {

        }
    }

    public void send_mail_NewEmployee_onBoarded(string Emp_Name, string toMailIDs, string strsubject, string strmailmsg, String strlocation, string cc_email)
    {
        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient();
        StringBuilder strbuild = new StringBuilder();
        DataTable dt_emp = new DataTable();
        try
        {
            strbuild = new StringBuilder();

            strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Arial;font-style:Regular;width:100%;border: 2px solid #000000'><tr>  ");
            strbuild.Append("<td colspan=2></td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan=2> Dear All, </td></tr>");
            strbuild.Append("<tr><td colspan=2> This is to inform you, that the new employee is onboard. Following are the Employee details for your reference. Kindly proceed with the further processes to Finish onboarding.</td></tr>");
            //strbuild.Append("<tr><td colspan=2> Also note that, due to Change of Project location your below listed future dated leaves (i.e. leaves beyond " + strdate + ") would be cancelled. You can re-apply for these leaves.</td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan=2>");
            strbuild.Append(strmailmsg);
            strbuild.Append("</td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("</table>");
            sendMail(toMailIDs, strsubject, Convert.ToString(strbuild).Trim(), "", cc_email);

        }
        catch (Exception ex)
        {
		sendMail("sada2703@gmail.com", "Onboarded mail Not sent", ex.Message.ToString(), "", "");
        }
    }

public void send_mail_Employee_Separated(string Emp_Name, string toMailIDs, string strsubject, string strmailmsg, String strlocation, string strdate)
    {
        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient();
        StringBuilder strbuild = new StringBuilder();
        DataTable dt_emp = new DataTable();
        try
        {
            strbuild = new StringBuilder();

            strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Arial;font-style:Regular;width:100%'><tr>  ");
            strbuild.Append("<td colspan=2></td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan=2> Dear All, </td></tr>");
            strbuild.Append("<tr><td colspan=2> This is to inform you, that " + Emp_Name + " is separated. Following are the details for your reference. Kindly proceed with the further processes to Finish separation.</td></tr>");
            strbuild.Append("<tr><td colspan=2> @ IT-Team, </td></tr>");
            strbuild.Append("<tr><td colspan=2> Please deactivate User Id / Login Id of " + Emp_Name + " with immediate effect. </td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan=2>");
            strbuild.Append(strmailmsg);
            strbuild.Append("</td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("</table>");
            strbuild.Append("</td></tr>");
             strbuild.Append("</table>");
            sendMail(toMailIDs, strsubject, Convert.ToString(strbuild).Trim(), "", strdate);

        }
        catch (Exception ex)
        {

        }
    }

        public void send_mail_Employee_resigned(string Emp_Name, string toMailIDs, string strsubject, string strmailmsg, String strlocation, string strdate)
    {
        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient();
        StringBuilder strbuild = new StringBuilder();
        DataTable dt_emp = new DataTable();
        try
        {
            strbuild = new StringBuilder();

            strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Arial;font-style:Regular;width:100%'><tr>  ");
            strbuild.Append("<td colspan=2></td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan=2> Dear All, </td></tr>");
            strbuild.Append("<tr><td colspan=2> This is to inform you, that " + Emp_Name + " has resigned. Following are the details for your reference.</td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan=2>");
            strbuild.Append(strmailmsg);
            strbuild.Append("</td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("</table>");
            strbuild.Append("</td></tr>");
            strbuild.Append("</table>");

            sendMail(toMailIDs, strsubject, Convert.ToString(strbuild).Trim(), "", strdate);

        }
        catch (Exception ex)
        {

        }
    }

    public void send_mail_Employee_TakenBack(string Emp_Name, string toMailIDs, string strsubject, string strmailmsg, String strlocation, string strdate)
    {
        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient();
        StringBuilder strbuild = new StringBuilder();
        DataTable dt_emp = new DataTable();
        try
        {
            strbuild = new StringBuilder();

            strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Arial;font-style:Regular;width:100%'><tr>  ");
            strbuild.Append("<td colspan=2></td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan=2> Dear All, </td></tr>");
            strbuild.Append("<tr><td colspan=2> This is to inform you that " + Emp_Name + " is retained. Following are the details for your reference.</td></tr>");
            strbuild.Append("<tr><td colspan=2> @ IT-Team, </td></tr>");
            strbuild.Append("<tr><td colspan=2> Please reinstate User Id / Login Id of " + Emp_Name + " with immediate effect. </td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan=2>");
            strbuild.Append(strmailmsg);
            strbuild.Append("</td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("</table>");
            strbuild.Append("</td></tr>");
            sendMail(toMailIDs, strsubject, Convert.ToString(strbuild).Trim(), "", strdate);

        }
        catch (Exception ex)
        {

        }
    }

public void send_mail_EmployeeOnly_resigned(string Emp_Name, string toMailIDs, string strsubject, string strmailmsg, String strlocation, string strdate, string StrExitSurveyLinkURL, string StrExitFromLinkURL, string StrOneHRLinkURL, string fileatteched,string imagedisplay)
    {
        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient();
        StringBuilder strbuild = new StringBuilder();
        DataTable dt_emp = new DataTable();
        try
        {
            strbuild = new StringBuilder();

            strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Arial;font-style:Regular;width:100%'>");
            //strbuild.Append("<td colspan=2></td></tr>");
            //strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan=2 style='padding-bottom:30px'> Dear " + Emp_Name + ", </td></tr></br></br>");
            strbuild.Append("<tr><td colspan=2 style='padding-bottom:10px'> Since you have Resigned please refer below actions to be completed in order to complete resignation process.</td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append(strmailmsg);
            //strbuild.Append("</td></tr>");
           // strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
           // strbuild.Append("</table>");
          //  strbuild.Append("</td></tr>");
         //   strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Arial;font-style:Regular'>");
            strbuild.Append("<tr><td></td></tr></br></br></br>");
            strbuild.Append("<tr><td><b> <span style='font-size:11pt;font-family:Arial'> Next Actions for you:- </span></b></td></tr></br>");
            strbuild.Append("<tr style='height:20px'><td style='height:20px'></td></tr>");
            strbuild.Append("<tr style='height:20px'><td style='height:20px'></td></tr>");
            strbuild.Append("<tr style='height:20px;'><td colspan=2 style='padding-bottom:20px'><span style='font-size:11pt;font-family:Arial'> <b>Step 1-</b> Please fill the Exit survey form by clicking on this link -   <a href='" + StrExitSurveyLinkURL + "'><b>Exit Survey </b> </a>  Post that, you need to print/get pdf of your filled survey. You can do so by clicking on <b> Print or get PDF of answers </b> button after submitting your response.</span></td></tr><br>");
            strbuild.Append("<tr ><td colspan=2 style='height:20px;padding-bottom:20px'></td></tr></br>");
            strbuild.Append("<tr style='height:20px'><td colspan=2 style='padding-bottom:20px'><span style='font-size:11pt;font-family:Arial'> <b>Step 2-</b> On LWD, ensure that your reporting manager fills Exit form A - <a href='" + StrExitFromLinkURL + "'><b>Exit Form </b></a> Please take a print/get pdf of the filled form from your manager. He/She can do so by clicking on <b>Print or get PDF of answers </b> button after submitting your response. </span></td></tr><br>");
            strbuild.Append("<tr><td colspan=2 width='250px'> <img src='" + imagedisplay.ToString() + "' width='250' /></td></tr><br>");
            strbuild.Append("<tr><td colspan=2><span style='font-size:11pt;font-family:Arial'> <b>Step 3-</b> All departments'  clearance has to be done on LWD and submit so that we can process your relieving on time </span></td></tr><br>");
            strbuild.Append("<tr><td colspan=2>&nbsp;&nbsp;<span style='font-size:11pt;font-family:Arial'> <b> Please download the pdf clearance checklist form attached in this mail </b></span></td></tr><br>");
            strbuild.Append("<tr style='height:20px'><td colspan=2 style='padding-bottom:20px'>&nbsp;&nbsp;&nbsp;<b><span style='font-size:11pt;font-family:Arial'>and complete the below exit formalities.</span></b></td></tr><br><br><br>");
            strbuild.Append("<tr><td colspan=2><span style='font-size:11pt;font-family:Arial'> Clearance has to be taken by Resignee from IT, HR, Admin, Accounts & own function(Reporting Manager) as per applicability -</span></td></tr><br>");
            strbuild.Append("<tr><td colspan=2><span style='font-size:11pt;font-family:Arial'><b>3.1.</b> KT/Handover to your replacement or SPOC identified by your manager</span></td></tr><br>");
            strbuild.Append("<tr><td colspan=2><span style='font-size:11pt;font-family:Arial'><b>3.2.</b> Laptop and other accessories to be couriered /physically delivered in office</span></td></tr><br>");
            strbuild.Append("<tr><td colspan=2><span style='font-size:11pt;font-family:Arial'><b>3.3.</b> Outstanding clearance confirmation from Accounts Team & payment to the bank account shared by Accounts Team incase of early release or any outstanding amount</span></td></tr><br>");
            strbuild.Append("<tr><td colspan=2><span style='font-size:11pt;font-family:Arial'><b>3.4.</b> ID Card/Visiting Card/Meal Card/Lift Access card etc. to be couriered/physically delivered in office</span></td></tr><br>");
            strbuild.Append("<tr><td colspan=2><span style='font-size:11pt;font-family:Arial'><b>3.5.</b> Exit interview to be completed with HR Operations SPOC</span></td></tr><br>");
            strbuild.Append("<tr><td colspan=2><span style='font-size:11pt;font-family:Arial'><b>3.6.</b> Exit Survey to be completed by the resignee using the url provided above in Step 1</span></td></tr><br>");
            strbuild.Append("<tr><td colspan=2 style='padding-bottom:20px'><span style='font-size:11pt;font-family:Arial'><b>3.7.</b> Exit form A to be completed by the Reporting Manager using the url provided above in Step 2</span></td></tr><br><br>");
            strbuild.Append("<tr><td colspan=2><span style='font-size:11pt;font-family:Arial'> <b> Post completion of these formalities, take physical/digital signature from concerned departments on/before LWD and upload using below provided URL </span></b></td></tr><br>");
            strbuild.Append("<tr><td colspan=2 style='padding-bottom:20px'><span style='font-size:11pt;font-family:Arial'> Link to upload the Clearance form, Exit Survey & Exit Form A <a href='" + StrOneHRLinkURL + "'><b> OneHR </b></a> </span></td></tr><br>");
            strbuild.Append("<tr ><td colspan=2 style='height:20px;padding-bottom:20px'></td></tr></br></br>");
            strbuild.Append("<tr><td colspan=2 style='padding-bottom:20px'><span style='font-size:11pt;font-family:Arial'><b>Important Note:</b> We will be sharing the relieving letter cum experience letter on submission of clearance form. Your FNF is subject to proper clearance from all relevant departments</span></td></tr><br><br>");
            strbuild.Append("<tr><td colspan=2><span style='font-size:11pt;font-family:Arial'><b> Exit Survey Form URL - <a href='" + StrExitSurveyLinkURL + "'>Exit Survey </a></b></span></td></tr><br>");
            strbuild.Append("<tr><td colspan=2><span style='font-size:11pt;font-family:Arial'><b> Clearance Form URL - <a href='" + StrOneHRLinkURL + "'>OneHR </a></b></span></td></tr><br>");
            strbuild.Append("<tr><td colspan=2><span style='font-size:11pt;font-family:Arial'><b> Exit Form A URL - <a href='" + StrExitFromLinkURL + "'>Exit Form </a></b></span></td></tr><br>");
            strbuild.Append("</table>");
            // strbuild.Append("</table>");

            sendMail(toMailIDs, strsubject, Convert.ToString(strbuild).Trim(), fileatteched, strdate);

        }
        catch (Exception ex)
        {

        }
    }
    


    public void send_mailto_Employee_LocationChange(string Emp_Name, string toMailIDs, string strsubject, string strmailmsg, String strlocation, string strdate)
    {
        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient();
        StringBuilder strbuild = new StringBuilder();
        DataTable dt_emp = new DataTable();
        try
        {
            strbuild = new StringBuilder();

            strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Arial;font-style:Regular;width:100%'><tr>  ");
            strbuild.Append("<td colspan=2></td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan=2> Dear " + Emp_Name + ", </td></tr>");
            strbuild.Append("<tr><td colspan=2> This is to inform you, that you have been allocated to the Project Location - " + strlocation + ", with effect from " + strdate + ".</td></tr>");
            //strbuild.Append("<tr><td colspan=2> Also note that, due to Change of Project location your below listed future dated leaves (i.e. leaves beyond " + strdate + ") would be cancelled. You can re-apply for these leaves.</td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            //strbuild.Append("<tr><td colspan=2>");
            //strbuild.Append(strmailmsg);
            //strbuild.Append("</td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("</table>");
            sendMail(toMailIDs, strsubject, Convert.ToString(strbuild).Trim(), "", "");

        }
        catch (Exception ex)
        {

        }
    }

    public void send_mailto_Employee_LocationChange_withFutureLeaves(string Emp_Name, string toMailIDs, string strsubject, string strmailmsg, String strlocation, string strdate)
    {
        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient();
        StringBuilder strbuild = new StringBuilder();
        DataTable dt_emp = new DataTable();
        try
        {
            strbuild = new StringBuilder();

            strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Arial;font-style:Regular;width:100%'><tr>  ");
            strbuild.Append("<td colspan=2></td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan=2> Dear " + Emp_Name + ", </td></tr>");
            strbuild.Append("<tr><td colspan=2> This is to inform you, that you have been allocated to the Project Location - " + strlocation + ", with effect from " + strdate + ".</td></tr>");
            strbuild.Append("<tr><td colspan=2> Also note that, due to Change of Project location your below listed future dated leaves (i.e. leaves beyond " + strdate + ") would be cancelled. You can re-apply for these leaves.</td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan=2>");
            strbuild.Append(strmailmsg);
            strbuild.Append("</td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("</table>");
            sendMail(toMailIDs, strsubject, Convert.ToString(strbuild).Trim(), "", "");

        }
        catch (Exception ex)
        {

        }
    }

    public void send_mailto_Employee_DepartmentChange(string Emp_Name, string toMailIDs, string strsubject, string strmailmsg, String strDepartment, string strdate)
    {
        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient();
        StringBuilder strbuild = new StringBuilder();
        DataTable dt_emp = new DataTable();
        try
        {
            strbuild = new StringBuilder();

            strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Arial;font-style:Regular;width:100%'><tr>  ");
            strbuild.Append("<td colspan=2></td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan=2> Dear " + Emp_Name + ", </td></tr>");
            strbuild.Append("<tr><td colspan=2> This is to inform you, that your department is changed to - " + strDepartment + ", with effect from " + strdate + ".</td></tr>");
            //strbuild.Append("<tr><td colspan=2> Also note that, due to Change of Project location your below listed future dated leaves (i.e. leaves beyond " + strdate + ") would be cancelled. You can re-apply for these leaves.</td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("</table>");
            sendMail(toMailIDs, strsubject, Convert.ToString(strbuild).Trim(), "", "");

        }
        catch (Exception ex)
        {

        }
    }

    public void send_mailto_Employee_RMChange(string Emp_Name, string toMailIDs, string strsubject, string strmailmsg, String strRM, string strdate)
    {
        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient();
        StringBuilder strbuild = new StringBuilder();
        DataTable dt_emp = new DataTable();
        try
        {
            strbuild = new StringBuilder();

            strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Arial;font-style:Regular;width:100%'><tr>  ");
            strbuild.Append("<td colspan=2></td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan=2> Dear " + Emp_Name + ", </td></tr>");
            strbuild.Append("<tr><td colspan=2> This is to inform you, that your reporting manager is changed to - " + strRM + ", with effect from " + strdate + ".</td></tr>");
            //strbuild.Append("<tr><td colspan=2> Also note that, due to Change of Project location your below listed future dated leaves (i.e. leaves beyond " + strdate + ") would be cancelled. You can re-apply for these leaves.</td></tr>");
            strbuild.Append("<tr><td colspan=2 style='height:20px'></td></tr>");
            strbuild.Append("</table>");
            sendMail(toMailIDs, strsubject, Convert.ToString(strbuild).Trim(), "", "");

        }
        catch (Exception ex)
        {

        }
    }

    public void sendMail(string toMailIDs, string strsubject, string strbody, String strattchfilepath, string ccMailIDs)
    {
        try
        {
            MailMessage mail = new MailMessage();
            string[] strtoEmail = Convert.ToString(toMailIDs).Trim().Split(';');

            string[] strCCEmail = Convert.ToString(ccMailIDs).Trim().Split(';');
            //string[] strBCCEmail = Convert.ToString(bccMailIDs).Trim().Split(';');
            for (int i = 0; i < strtoEmail.Length; i++)
            {
                if (Convert.ToString(strtoEmail[i]).Trim() != "")
                    mail.To.Add(strtoEmail[i]);
            }

            for (int i = 0; i < strCCEmail.Length; i++)
            {
                if (Convert.ToString(strCCEmail[i]).Trim() != "")
                    mail.CC.Add(strCCEmail[i]);
            }

            //mail.To.Add("ashok.wani@highbartech.com");
            //mail.Bcc.Add("ashok.wani@highbartech.com");

            StringBuilder strsignature = new StringBuilder();

            mail.From = new MailAddress("noreply@highbartech.com");

            mail.Subject = strsubject;
            mail.Body = Convert.ToString(strbody) + Convert.ToString(strsignature);
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.Low;


            if (Convert.ToString(strattchfilepath).Trim() != "")
            {
                Attachment attch = new Attachment(strattchfilepath);
                mail.Attachments.Add(attch);
            }

            ////SmtpClient smtp = new SmtpClient();

            //////smtp.Host = "smtp.office365.com"; //Highbar SMTP
            //////smtp.Port = 587;
            ////smtp.Host = "smtp-mail.outlook.com"; //Highbar SMTP
            ////smtp.Port = 25;
            ////smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            //////System.Net.NetworkCredential SMTPUserInfo = new System.Net.NetworkCredential("ashok.wani", "$Sanjay123");
            ////System.Net.NetworkCredential SMTPUserInfo = new System.Net.NetworkCredential("noreply@highbartech.com", "HBT@2019");
            ////smtp.UseDefaultCredentials = false;
            ////smtp.Credentials = SMTPUserInfo;
            ////smtp.EnableSsl = true;
            ////smtp.Send(mail);
            ////mail.Dispose();

            using (SmtpClient smtp = new SmtpClient())
            {
                smtp.Host = "smtp.office365.com"; //Highbar SMTP

                smtp.Port = 587;
                smtp.TargetName = "STARTTLS/smtp.office365.com";
                //smtp.Host = "smtp-mail.outlook.com"; //Highbar SMTP
                //smtp.Port = 25;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                System.Net.NetworkCredential SMTPUserInfo = new System.Net.NetworkCredential("noreply@highbartech.com", "HBT@2019");
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = SMTPUserInfo;
                smtp.EnableSsl = true;
                //var securityProtocol = (int)System.Net.ServicePointManager.SecurityProtocol;

                //// 0 = SystemDefault in .NET 4.7+
                //if (securityProtocol != 0)
                //{
                //    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;
                //}
                System.Net.ServicePointManager.SecurityProtocol |= System.Net.SecurityProtocolType.Tls | System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                smtp.Send(mail);
            }
            mail.Dispose();
        }
        catch (Exception)
        {

            throw;
        }


    }

//Added by Manisha for Asset allocation request
    #region Generate Asset allocation request
    public object Insert_DataGetOutputId(SqlParameter[] parameters, string strspname)
    {
        DataTable dtTravelDetails = new DataTable();
        try
        {
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
            {
                scon.Open();
            }

            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandText = strspname;
            sCommand.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter p in parameters)
            {
                if (p != null)
                {
                    sCommand.Parameters.Add(p);
                }
            }
            var status = sCommand.ExecuteScalar();
            return status;
        }
        catch (Exception ex)
        {
            //throw (ex);
        }
        finally
        {
            scon.Close();
        }
        return 0;
    }
    public void SendMailToAllCustodian_NewEmployee_onBoard(string EmpName, string AssetAlloReqNo, string EmpCode, string Doj, string Location, string Dept, string Designation, string RMgr, string HOD, string toMailIDs, int AARNoId)
    {

        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient();
        StringBuilder strbuild = new StringBuilder();
        int Id = Convert.ToInt32(AARNoId);
        //string ITAssetService_Req = "http://localhost/hrms/login.aspx?ReturnUrl=procs/ITAssetService_Req.aspx";
        string ITAssetService_Req = "https://ess.highbartech.com/hrms/login.aspx?ReturnUrl=procs/ITAssetService_Req.aspx";
        string redirectURL = Convert.ToString(ITAssetService_Req).Trim() + "?id=" + Id + "&type=emp";


         var strsubject = "New Joinee Asset Allocation Request- " + EmpName;

        try
        {
            strbuild = new StringBuilder();

            strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Trebuchet MS !important;font-style:Regular;width:100%;table-layout:fixed;'><tr><td>   ");
            strbuild.Append("</td></tr>");
            strbuild.Append("<tr><td style='height:20px'></td></tr>");
            strbuild.Append("<tr><td>Dear Sir/Madam,</td></tr>");
            strbuild.Append("</td></tr>");
            strbuild.Append("</td></tr>");
            strbuild.Append("<tr><td width = '30%'> Following Employee has been onboarded in OneHR, Please assign Laptop/Desktop.</td ></ tr>");
            strbuild.Append("<tr><td style='height:20px'></td></tr>");
            strbuild.Append("<tr><td>");
            strbuild.Append("<table style='width:80%;color:#000000;font-size:11pt;font-family:Trebuchet MS !important;font-style:Regular;table-layout:fixed;'>");
            strbuild.Append("<tr><td width='30%'>Asset Allocation Request : </td><td >" + AssetAlloReqNo + "</td></tr>");
            strbuild.Append("<tr><td width='30%'>Employee Code : </td><td >" + EmpCode + "</td></tr>");
            strbuild.Append("<tr><td width='30%'>Employee Name : </td><td >" + EmpName + "</td></tr>");
            strbuild.Append("<tr><td width='30%'>Onboarding Date : </td><td width='75%'>" + Doj + "</td></tr>");
            strbuild.Append("<tr><td width='30%'>Location : </td><td width='75%'> " + Location + "</td></tr>");
            strbuild.Append("<tr><td width='30%'>Department :</td><td width='75%'>" + Dept + "</td></tr>");
            strbuild.Append("<tr><td width='30%'>Designation :</td><td width='75%'>" + Designation + "</td></tr>");
            strbuild.Append("<tr><td width='30%'>Reporting Manager :</td><td width='75%'>" + RMgr + "</td></tr>");
            strbuild.Append("<tr><td width='30%'>HOD :</td><td width='75%'>" + HOD + "</td></tr>");
            strbuild.Append("</table>");
            strbuild.Append("</td></tr>");
            strbuild.Append("</td></tr>");
            strbuild.Append("<tr><td style='height:20px'></td></tr>");
            strbuild.Append("<tr><td style='height:20px'><a href='" + redirectURL + "' target='_blank'> Click here to take action</td></tr>");
            strbuild.Append("<tr><td style='height:20px'></td></tr>");
            strbuild.Append("<tr><td style='height:20px'>This is a system generated email, please do not reply.</td></tr>");
            strbuild.Append("</table>");
            sendMail(toMailIDs, strsubject, Convert.ToString(strbuild).Trim(), "", "");
        }
        catch (Exception)
        {
            throw;
        }
    }
    #endregion

#region Welcome Email
    public void send_mail_NewEmployee_onBoarded_Welcome(string Emp_Name, string toMailIDs, string strsubject, string strmailmsg, String strlocation, string cc_email, string DesginationName, string Department_Name)
    {
        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient();
        StringBuilder strbuild = new StringBuilder();
        DataTable dt_emp = new DataTable();
        try
        {
            strbuild = new StringBuilder();

            strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Arial;font-style:Regular;width:100%;border: 2px solid #000000'><tr>  ");
            strbuild.Append("<td colspan='2'></td></tr>");
            strbuild.Append("<tr><td colspan='2' style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan='2'> Dear Colleagues, </td></tr>");
            strbuild.Append("<tr><td colspan='2'> </td></tr>");
            strbuild.Append("<tr><td colspan='2'> We are pleased to inform you that <b>" + Emp_Name + "</b> has joined us as <b>" + DesginationName + "</b> in <b>" + Department_Name + "</b>.</td></tr>");
            //strbuild.Append("<tr><td colspan=2> Also note that, due to Change of Project location your below listed future dated leaves (i.e. leaves beyond " + strdate + ") would be cancelled. You can re-apply for these leaves.</td></tr>");
            strbuild.Append("<tr><td colspan='2' style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan='2'>");
            strbuild.Append(strmailmsg);
            strbuild.Append("</td></tr>");
            strbuild.Append("<tr><td colspan='2' style='height:20px'></td></tr>");
            strbuild.Append("<tr><td colspan='2'><b>Please join me in welcoming " + Emp_Name + " to the Highbar family !</b></td></tr>");
            strbuild.Append("<tr><td colspan='2' style='height:20px'></td></tr>");
            strbuild.Append("</table>");
            sendMail(toMailIDs, strsubject, Convert.ToString(strbuild).Trim(), "", cc_email);

        }
        catch (Exception ex)
        {
		sendMail("sada2703@gmail.com", "Welcome mail Not sent", ex.Message.ToString(), "", "");
        }
    }
    #endregion

public void send_mailto_closerequisition_Mail(string ReqMailID, string toMailIDs, string strsubject, string mailContainoneline, string empname, string empcode, string department, string Location, string Designation, string Band, string Req_Name, string RequisitionNo, string RequisitionDate, string RequiredByDate, string Locations, string Module,
     string PositionTitle, string DepartmentName, string Bands, string NoOfPosition, string Recruitername)
    {
        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient();
        StringBuilder strbuild = new StringBuilder();
        DataTable dt_emp = new DataTable();
        strsubject = strsubject + "  ";
        try
        {
            strbuild = new StringBuilder();
            string contain = "";
            if (loginUserid == "1")
            {
                strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Arial;font-style:Regular;width:100%'><tr><td>   ");
                strbuild.Append("</td></tr>");
                strbuild.Append("<tr><td style='height:20px'></td></tr>");
                strbuild.Append("<tr><td>" + mailContainoneline + "</ td></tr>");
                strbuild.Append("<tr><td style='height:20px'></td></tr>");
                strbuild.Append("<tr><td>");
                strbuild.Append("<table style='width:95%';'color:#000000;font-size:11pt;font-family:Arial;font-style:Regular>");

                strbuild.Append("<tr><td>Requisition No :</td><td> " + RequisitionNo + "</td><td></td></tr>");
                strbuild.Append("<tr><td>Requisitioner Name :</td><td> " + Req_Name + "</td><td></td></tr>");
                strbuild.Append("<tr><td>Requisition Date :</td><td> " + RequisitionDate + "</td><td></td></tr>");
                strbuild.Append("<tr><td>Required By Date :</td><td> " + RequiredByDate + "</td><td></td></tr>");
                strbuild.Append("<tr><td>Department :</td><td colspan=2> " + DepartmentName + "</td></tr>");
                strbuild.Append("<tr><td>Location :</td><td colspan=2> " + Locations + "</td></tr>");
                strbuild.Append("<tr><td>Skill set :</td><td > " + Module + "</td><td></td></tr>");
                strbuild.Append("<tr><td>Position Title :</td><td colspan=2> " + PositionTitle + "</td></tr>");
                strbuild.Append("<tr><td>Band :</td><td> " + Bands + "</td><td></td></tr>");
                //strbuild.Append("<tr><td>NoOfPosition :</td><td> " + NoOfPosition + "</td><td></td></tr>");
                strbuild.Append("<tr><td>--------------------------------</td><td>--------------------------------</td><td></td></tr>");

                strbuild.Append("<tr><td>Name of the Employee :</td><td> " + empname + "</td><td></td></tr>");
                strbuild.Append("<tr><td>Employee code :</td><td colspan=2> " + empcode + "</td></tr>");
                strbuild.Append("<tr><td>Recruiter name :</td><td> " + Recruitername + "</td><td></td></tr>");
                strbuild.Append("<tr><td>Department :</td><td> " + department + "</td><td></td></tr>");
                strbuild.Append("<tr><td>Location :</td><td> " + Location + "</td></tr>");
                strbuild.Append("<tr><td>Designation :</td><td> " + Designation + "</td><td></td></tr>");
                strbuild.Append("<tr><td>Band :</td><td> " + Band + "</td><td></td></tr>");

                if (Convert.ToString(empname).Trim() != "")
                    //  strbuild.Append("<tr><td>For Information To :</td><td colspan=2>" + MultipleCandidateName + "</td></tr>");
                    strbuild.Append("</table>");
                strbuild.Append("</td></tr>");
                strbuild.Append("<tr><td style='height:20px'></td></tr>");
                //  strbuild.Append("<tr><td style='height:20px'><a href='" + LINKURL + "'> Please click here to submit Hiring Progress. </a></td></tr>");
                strbuild.Append("</table>");

            }
            sendMail(toMailIDs, strsubject, Convert.ToString(strbuild).Trim(), "", "");

        }
        catch (Exception ex)
        {

        }
    }

 public void send_mailto_CandidateAttachdoc_Mail(string ReqMailID, string toMailIDs, string strsubject, string mailContainoneline,string mailContainCanlinetwo, string ccMailIDs, string CandidateName, string attachfile, string SkillSet , string strdateissue)
    {
        MailMessage mail = new MailMessage();
        SmtpClient SmtpServer = new SmtpClient();
        StringBuilder strbuild = new StringBuilder();
        DataTable dt_emp = new DataTable();
        strsubject = strsubject + "  ";
        try
        {
            strbuild = new StringBuilder();
            string contain = "";
            if (loginUserid == "1")
            {
                strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Arial;font-style:Regular;width:100%'><tr><td>   ");
                strbuild.Append("</td></tr>");
                strbuild.Append("<tr><td style='padding-bottom:40px'>" + mailContainoneline + "</ td></tr>");
                strbuild.Append("<tr><td style='padding-bottom:40px'>" + mailContainCanlinetwo + " </td></tr>");
                strbuild.Append("<tr><td>");
                strbuild.Append("<table style='width:100%';'color:#000000;font-size:11pt;font-family:Arial;font-style:Regular>");

                strbuild.Append("<tr><td>This is in reference to your job application for the profile of  " + SkillSet + " </td></tr>");
                strbuild.Append("<tr><td style='padding-bottom:20px'>and the subsequent offer acceptance which was released on "+ strdateissue + "<td></td></tr>");
                
                strbuild.Append("<tr><td>We welcome you on broad on behalf of our organization.</td></tr>");
                strbuild.Append("<tr><td>Please find enclosed the Appointment Letter with this email for the same.</td></tr>");
                strbuild.Append("<tr><td> You are requested to kindly sign (Digital/e-signature) the copy of this enclosed</td></tr>");
                strbuild.Append("<tr><td>Appointment Letter and send it back as a confirmation of acceptance of</td></tr>");
                strbuild.Append("<tr><td style='padding-bottom:20px'>appointment from your side.</td></tr>");
               
                strbuild.Append("<tr><td>We shall keep you posted of the further formalities once we have received the </td></tr>");
                strbuild.Append("<tr><td style='padding-bottom:30px'>signed copy of Appointment Letter from you.</td></tr>");
                
                strbuild.Append("<tr><td style='padding-bottom:70px'>In case of any clarity, please feel free to write us back.</td></tr>");
                
                strbuild.Append("<tr><td>Wishing you all the best.</td><td></td></tr>");
            

                if (Convert.ToString("").Trim() != "")
                    //  strbuild.Append("<tr><td>For Information To :</td><td colspan=2>" + MultipleCandidateName + "</td></tr>");
                    strbuild.Append("</table>");
                strbuild.Append("</td></tr>");
                strbuild.Append("<tr><td style='height:20px'></td></tr>");
                //  strbuild.Append("<tr><td style='height:20px'><a href='" + LINKURL + "'> Please click here to submit Hiring Progress. </a></td></tr>");
                strbuild.Append("</table>");

            }
            sendMail(toMailIDs, strsubject, Convert.ToString(strbuild).Trim(), attachfile, "");

        }
        catch (Exception ex)
        {

        }
    }



public DataTable SearchCandidatedForReferral(string Candidate_ID, string EmpCode, int StatusID,string EmpFlag,string Emailaddress)
	{
		DataTable dtRecCreateCandidate = new DataTable();
		try
		{
			sql.con.ConnectionString = connection;
			sql.con.Open();
			sql.cmd4.Connection = sql.con;
			sql.cmd4.CommandType = CommandType.StoredProcedure;
			sql.cmd4.Parameters.Clear();
			sql.cmd4.CommandText = "sp_Ref_SearchCandidateReferral";
			sql.cmd4.Parameters.AddWithValue("@QueueType", "INSERT");
			sql.cmd4.Parameters.AddWithValue("@Candidate_ID", Candidate_ID);
			sql.cmd4.Parameters.AddWithValue("@EmpCode", EmpCode);
			sql.cmd4.Parameters.AddWithValue("@StatusID", StatusID);
			sql.cmd4.Parameters.AddWithValue("@EmpFlag", EmpFlag);
			sql.cmd4.Parameters.AddWithValue("@Emailaddress", Emailaddress);
			sql.adp3.SelectCommand = sql.cmd4;
			sql.adp3.Fill(dtRecCreateCandidate);
		}
		catch (Exception)
		{
			throw;
		}

		finally
		{
			sql.con.Close();
		}
		return dtRecCreateCandidate;

	}

	public void Ref_Candidated_send_mailto_recruitmentModule(string CandidatedName, string Subject, string tbody, string toMailIDs, string employeeName, string createdDate, string CandidatedEMail, string ccmailid, string CandidatedMobile, string Gender, string Maritalstatus, string SkillSet, string TotalExperience, string RelevantExperience, string AdditionalSkillset, string Comments)
	{
		MailMessage mail = new MailMessage();
		SmtpClient SmtpServer = new SmtpClient();
		StringBuilder strbuild = new StringBuilder();
		DataTable dt_emp = new DataTable();
		var strsubject = Subject;
		try
		{
			strbuild = new StringBuilder();
			strbuild.Append("<table style='color:#000000;font-size:11pt;font-family:Trebuchet MS !important;font-style:Regular;width:100%;table-layout:fixed;'><tr><td>   ");
			strbuild.Append("</td></tr>");
			strbuild.Append("<tr><td style='height:20px;'></td></tr>");
			strbuild.Append("<tr><td>Dear " + employeeName + ",</td></tr>");
			strbuild.Append("<tr><td> " + tbody + "</td></tr>");
			strbuild.Append("<tr><td style='height:20px;'></td></tr>");
			strbuild.Append("<tr><td>");
			strbuild.Append("<table style='width:80% !important;color:#000000;font-size:11pt;font-family:Trebuchet MS !important;font-style:Regular;table-layout:fixed;'>");
			//strbuild.Append("<tr><td width='25%'>Customer First Incident No : </td><td width='75%'>" + serviceRequestno + "</td></tr>");
			strbuild.Append("<tr><td width='25%'>Created By : </td><td width='75%'>" + employeeName + "</td></tr>");
			strbuild.Append("<tr><td width='25%'>Creation Date : </td><td width='75%'> " + createdDate + "</td></tr>");
			strbuild.Append("<tr><td width='25%'>Candidate Name :</td><td width='75%'>" + CandidatedName + "</td></tr>");
			strbuild.Append("<tr><td width='25%'>Candidate EMailID  :</td><td width='75%'>" + CandidatedEMail + "</td></tr>");
			strbuild.Append("<tr><td width='25%'>Candidate Mobile No  :</td><td width='75%'>" + CandidatedMobile + "</td></tr>");
			strbuild.Append("<tr><td width='25%'>Gender  :</td><td width='75%'>" + Gender + "</td></tr>");
			strbuild.Append("<tr><td width='25%'>Marital Status :</td><td width='75%'>" + Maritalstatus + "</td></tr>");
			strbuild.Append("<tr><td width='25%'>SkillSet  :</td><td width='75%'>" + SkillSet + "</td></tr>");
			strbuild.Append("<tr><td width='25%'>Total Experience In(Year)  :</td><td width='75%'>" + TotalExperience + "</td></tr>");
			strbuild.Append("<tr><td width='25%'>Relevant Experience In(Year)  :</td><td width='75%'>" + RelevantExperience + "</td></tr>");
			strbuild.Append("<tr><td width='25%'>Additional Skillset  :</td><td width='75%'>" + AdditionalSkillset + "</td></tr>");
			strbuild.Append("<tr><td width='25%'>Comments  :</td><td width='75%'>" + Comments + "</td></tr>");
			strbuild.Append("<tr><td style='height:30px'> </td></tr>");
			strbuild.Append("</table>");
			strbuild.Append("<tr><td style='height:20px'>This is system generated mail, please do not reply.</td></tr>");
			strbuild.Append("</table>");
			sendMail(toMailIDs, strsubject, Convert.ToString(strbuild).Trim(), "", ccmailid);

		}
		catch (Exception ex)
		{
		}
	}

    #region Exit Process
    #region GetUserDetailsForExitProcess
    public DataTable getUserDetailsForExitProcess(int EMPEXIT_ID, string Type)
    {
        DataTable dtgetUserDetails = new DataTable();
        try
        {
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
                scon.Open();
            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandTimeout = 0;
            sCommand.CommandType = CommandType.StoredProcedure;
            sCommand.CommandText = "sp_GetUserDataForExitProcess";
            sCommand.Parameters.AddWithValue("@Type", Type);
            sCommand.Parameters.AddWithValue("@EMPEXIT_ID", EMPEXIT_ID);
            sadp = new SqlDataAdapter();
            sadp.SelectCommand = sCommand;
            sadp.Fill(dtgetUserDetails);
        }
        catch (Exception)
        {
            throw;
        }

        finally
        {
            sql.con.Close();
        }
        return dtgetUserDetails;

    }
    #endregion
    #region GetExitFormDataByResignationID
    public DataTable GetExitFormDataByResignationID(int EMPEXIT_ID)
    {
        DataTable dtexit = new DataTable();
        try
        {
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
                scon.Open();
            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandTimeout = 0;
            sCommand.CommandType = CommandType.StoredProcedure;
            sCommand.CommandText = "spExitSurveyForm";
            sCommand.Parameters.AddWithValue("@Type", "GetExitSurveyFormByResignationID");
            sCommand.Parameters.AddWithValue("@EMPEXIT_ID", EMPEXIT_ID);
            sadp = new SqlDataAdapter();
            sadp.SelectCommand = sCommand;
            sadp.Fill(dtexit);
        }
        catch (Exception ex)
        {
            throw;
        }

        finally
        {
            sql.con.Close();
        }
        return dtexit;
    }
    #endregion
    #region GetUserDetailsForExitInterview
    public DataTable getUserDetailsForExitInterview(int EMPEXIT_ID, string Type)
    {
        DataTable dtgetUserDetails = new DataTable();
        try
        {
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
                scon.Open();
            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandTimeout = 0;
            sCommand.CommandType = CommandType.StoredProcedure;
            sCommand.CommandText = "sp_GetUserDataForExitProcess";
            sCommand.Parameters.AddWithValue("@Type", Type);
            sCommand.Parameters.AddWithValue("@EMPEXIT_ID", EMPEXIT_ID);
            sadp = new SqlDataAdapter();
            sadp.SelectCommand = sCommand;
            sadp.Fill(dtgetUserDetails);
        }
        catch (Exception)
        {
            throw;
        }

        finally
        {
            sql.con.Close();
        }
        return dtgetUserDetails;

    }
    public DataTable GetResignationID(string empcode, string Type)
    {
        DataTable dtgetUserDetails = new DataTable();
        try
        {
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
                scon.Open();
            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandTimeout = 0;
            sCommand.CommandType = CommandType.StoredProcedure;
            sCommand.CommandText = "sp_GetUserDataForExitProcess";
            sCommand.Parameters.AddWithValue("@Type", Type);
            sCommand.Parameters.AddWithValue("@EmpCode", empcode);
            sadp = new SqlDataAdapter();
            sadp.SelectCommand = sCommand;
            sadp.Fill(dtgetUserDetails);
        }
        catch (Exception)
        {
            throw;
        }

        finally
        {
            sql.con.Close();
        }
        return dtgetUserDetails;

    }
    #endregion
    #region GetExitInterviewDataByResignationID
    public DataTable GetExitInterviewDataByResignationID(int EMPEXIT_ID)
    {
        DataTable dtexit = new DataTable();
        try
        {
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
                scon.Open();
            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandTimeout = 0;
            sCommand.CommandType = CommandType.StoredProcedure;
            sCommand.CommandText = "spExitInterviewForm";
            sCommand.Parameters.AddWithValue("@Type", "ViewGetExitInterviewFormByResignationID");
            sCommand.Parameters.AddWithValue("@EMPEXIT_ID", EMPEXIT_ID);
            sadp = new SqlDataAdapter();
            sadp.SelectCommand = sCommand;
            sadp.Fill(dtexit);
        }
        catch (Exception ex)
        {
            throw;
        }

        finally
        {
            sql.con.Close();
        }
        return dtexit;
    }
    #endregion
    #region GetClearanceViewDataByResignationID
    public DataTable GetClearanceViewDataByResignationID(int EMPEXIT_ID)
    {
        DataTable dtexit = new DataTable();
        try
        {
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
                scon.Open();
            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandTimeout = 0;
            sCommand.CommandType = CommandType.StoredProcedure;
            sCommand.CommandText = "spExitProc_ClearanceForm";
            sCommand.Parameters.AddWithValue("@Type", "ViewGetClearanceViewFormByResignationID");
            sCommand.Parameters.AddWithValue("@EMPEXIT_ID", EMPEXIT_ID);
            sadp = new SqlDataAdapter();
            sadp.SelectCommand = sCommand;
            sadp.Fill(dtexit);
        }
        catch (Exception ex)
        {
            throw;
        }

        finally
        {
            sql.con.Close();
        }
        return dtexit;
    }
    #endregion
    #region GetExitClearanceFormDataByResignationID
    public DataSet GetExitClearanceDataByResignationID(int EMPEXIT_ID)
    {
        DataSet dsexit = new DataSet();
        try
        {
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
                scon.Open();
            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandTimeout = 0;
            sCommand.CommandType = CommandType.StoredProcedure;
            sCommand.CommandText = "spExitProc_ClearanceForm";
            sCommand.Parameters.AddWithValue("@Type", "ViewGetUserClearanceData");
            sCommand.Parameters.AddWithValue("@EMPEXIT_ID", EMPEXIT_ID);
            sadp = new SqlDataAdapter();
            sadp.SelectCommand = sCommand;
            sadp.Fill(dsexit);
        }
        catch (Exception ex)
        {
            throw;
        }

        finally
        {
            sql.con.Close();
        }
        return dsexit;
    }
    #endregion
    public DataTable GetResignationHistory(string empcode)
    {
        DataTable dstapp = new DataTable();
        try
        {
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
                scon.Open();
            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandText = "[SP_ExitProcess]";
            sCommand.CommandType = CommandType.StoredProcedure;
            sCommand.Parameters.AddWithValue("@qtype", "ResignationHistory");
            sCommand.Parameters.AddWithValue("@empcode", empcode);
            sadp = new SqlDataAdapter();
            sadp.SelectCommand = sCommand;
            sadp.Fill(dstapp);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            scon.Close();
        }
        return dstapp;
    }
    #endregion

#region EarlyRelease HrReleaseDate
    public DataSet LWDExitSurveyEmployeeData(string empcode)
    {
        DataSet dstapp = new DataSet();
        try
        {
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
                scon.Open();
            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandText = "SP_Admin_Employee_Exit";
            sCommand.CommandType = CommandType.StoredProcedure;
            sCommand.Parameters.AddWithValue("@qtype", "HrReleaseExitSurveyMail_EmployeeDetails");
            sCommand.Parameters.AddWithValue("@Emp_Code", empcode);
            sadp = new SqlDataAdapter();
            sadp.SelectCommand = sCommand;
            sadp.Fill(dstapp);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            scon.Close();
        }
        return dstapp;
    }
    public DataSet LWDExitSurveyEmployeeDataCCTO(string empcode)
    {
        DataSet dstapp = new DataSet();
        try
        {
            scon = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconnection"].ToString());
            if (scon.State == ConnectionState.Closed || scon.State == ConnectionState.Broken)
                scon.Open();
            sCommand = new SqlCommand();
            sCommand.Connection = scon;
            sCommand.CommandText = "SP_Admin_Employee_Exit";
            sCommand.CommandType = CommandType.StoredProcedure;
            sCommand.Parameters.AddWithValue("@qtype", "GetReminBefore7daysLWDCCTOForHrReleaseDate");
            sCommand.Parameters.AddWithValue("@Emp_Code", empcode);
            sadp = new SqlDataAdapter();
            sadp.SelectCommand = sCommand;
            sadp.Fill(dstapp);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            scon.Close();
        }
        return dstapp;
    }
 #endregion
}