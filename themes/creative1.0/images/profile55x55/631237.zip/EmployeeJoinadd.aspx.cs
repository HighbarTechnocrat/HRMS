﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.IO;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

public partial class EmployeeJoinadd : System.Web.UI.Page
{

    public int projectid;
    public int projectcatid;
    int number;
    public string projectcategory;
    public string projectcategorytext;
    public string projectcategorytexts;
    public string telephonenos;
    Admin_Methods adm = new Admin_Methods();

    protected void Page_Load(object sender, EventArgs e)
    {
        lblName.Text = highbarconfiguration.SiteName + ": Admin: Insert / Update Employee";
        if (Request.QueryString["Id"] != null && Request.QueryString["Id"] != "")
        {
            if (Int32.TryParse(commonclass.GetSafeIDFromURL(Request.QueryString["Id"]), out number))
            {
                projectid = Convert.ToInt32(Request.QueryString["Id"]);
            }
            else
            {
                Response.Redirect(ConfigurationManager.AppSettings["sitepathadmin"] + "error.aspx");
            }
        }
        //Response.Write(projectid);
        //Response.End();

        if (!Page.IsPostBack)
        {
            Fill_Project_Manager();
            Fill_Employment();
            Fill_Location();
            Fill_Department();
            Fill_Designation();
            Fill_Band();
            Fill_Module();
            Fill_CandidateName();
            GetOldEmpCodeReference();

            // Add 
            Fill_Shift();
            Txt_kids.Attributes.Add("onkeypress", "return onCharOnlyNumber(event);");
			txtAgreedBG.Attributes.Add("onkeypress", "return onCharOnlyNumber(event);");
			Txt_kids.Text = "0";
            //Get_Emp_Code();
            if (projectid != 0)
            {
                showContractDiv.Visible = false;
                Fill_CandidateNameClosed();
                loaddata(projectid);
                CHK_SendWelcomeEmail.Enabled = false;
               
            }
        }
        this.Title = highbarconfiguration.SiteName + ": Admin: Insert Update Projects";
    }

    protected void btnadd_Click(object sender, EventArgs e)
    {
        decimal Car_AVG = 0;
        string tStatus = "";
        string chk_L = "";
        string chk_S = "N";
        string chk_C = "";
        string chk_ecr = "";
        string[] strdate;
        string Birthdate = "";
        string Anniversarydate = "";
        string JoiningDate = "";
        string ContractEndDate = "";
        string withEffectivDate = "";
        string RetirementDate = "";
        string PassIssueDate = "";
        string PassExpiryDate = "";
        string AppletterissueDate = "";


        
        if (Convert.ToString(Txt_Birthdate.Text).Trim() != "")
        {
            strdate = Convert.ToString(Txt_Birthdate.Text).Trim().Split('/');
            Birthdate = Convert.ToString(strdate[2]) + "-" + Convert.ToString(strdate[1]) + "-" + Convert.ToString(strdate[0]);
        }

        if (Convert.ToString(Txt_Anniversary.Text).Trim() != "")
        {
            strdate = Convert.ToString(Txt_Anniversary.Text).Trim().Split('/');
            Anniversarydate = Convert.ToString(strdate[2]) + "-" + Convert.ToString(strdate[1]) + "-" + Convert.ToString(strdate[0]);
        }

        if (Convert.ToString(Txt_DOJ.Text).Trim() != "")
        {
            strdate = Convert.ToString(Txt_DOJ.Text).Trim().Split('/');
            JoiningDate = Convert.ToString(strdate[2]) + "-" + Convert.ToString(strdate[1]) + "-" + Convert.ToString(strdate[0]);
        }
        //Add New With Effective Date 03-05-2021
        if (Convert.ToString(Txt_Resignation.Text).Trim() != "")
        {
            strdate = Convert.ToString(Txt_Resignation.Text).Trim().Split('/');
            withEffectivDate = Convert.ToString(strdate[2]) + "-" + Convert.ToString(strdate[1]) + "-" + Convert.ToString(strdate[0]);
        }
        
        if (Convert.ToString(Txt_Retirement.Text).Trim() != "")
        {
            
            if (Txt_Retirement.Text.Contains("/"))
            {
                strdate = Convert.ToString(Txt_Retirement.Text).Trim().Split('/');
                RetirementDate = Convert.ToString(strdate[2]) + "-" + Convert.ToString(strdate[1]) + "-" + Convert.ToString(strdate[0]);
            }
            else
            {
                RetirementDate = Convert.ToString(Txt_Retirement.Text);
            }
        }

        if (Convert.ToString(Txt_DateofIssue.Text).Trim() != "")
        {
            strdate = Convert.ToString(Txt_DateofIssue.Text).Trim().Split('/');
            PassIssueDate = Convert.ToString(strdate[2]) + "-" + Convert.ToString(strdate[1]) + "-" + Convert.ToString(strdate[0]);
        }

        if (Convert.ToString(Txt_DateofExpiry.Text).Trim() != "")
        {
            strdate = Convert.ToString(Txt_DateofExpiry.Text).Trim().Split('/');
            PassExpiryDate = Convert.ToString(strdate[2]) + "-" + Convert.ToString(strdate[1]) + "-" + Convert.ToString(strdate[0]);
        }

        if (Convert.ToString(Txt_AppletterissueDate.Text).Trim() != "")
        {
            strdate = Convert.ToString(Txt_AppletterissueDate.Text).Trim().Split('/');
            AppletterissueDate = Convert.ToString(strdate[2]) + "-" + Convert.ToString(strdate[1]) + "-" + Convert.ToString(strdate[0]);
        }

        if (chk_leave.Checked)
            chk_L = "Y";
        if (chk_Self.Checked)
            chk_S = "Y";
        if (chk_Contact.Checked)
            chk_C = "Y";
        if (Chk_ECR.Checked)
            chk_ecr = "Y";
        if (ddl_Bandtexts.Text.ToString() != "")
        {
            SqlParameter[] spars = new SqlParameter[2];

            spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars[0].Value = "Band";

            spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
            if (ddl_Bandtexts.Text.ToString() == "")
                spars[1].Value = DBNull.Value;
            else
                spars[1].Value = ddl_Bandtexts.Text.ToString();

            DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");

            if (dt.Rows.Count > 0)
            {
                Car_AVG = Convert.ToDecimal(dt.Rows[0]["CAR_AVERAGE"]);
            }
        }
        //if (ddl_Locationtexts.Text.ToString() == "Active")
        //    tStatus = "A";
        //else
        //    tStatus = "D";
        //decimal projectid = Convert.ToDecimal(ddlLoc_Type.SelectedValue);

        string Value = Convert.ToString((txt_Address.Text.Trim()));
        string str = Page.User.Identity.Name;
        if (Txt_kids.Text == "")
            Txt_kids.Text = "0";
        string to_email = "";
        string emp_name = "";
        StringBuilder strbuild = new StringBuilder();

        if (projectid == 0)
        {
            if (DDLApplettreissuedstatus.SelectedValue == "0")
            {
                msgsave.Text = "Please select Appointment Letter Issued Status.";
                msgsave.Visible = true;
                return;
            }

            if (Txt_Resignation.Text.ToString() != "")
            {
                var todayDate = DateTime.Now;
                var selectedDate = DateTime.ParseExact(Txt_Resignation.Text, @"dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                if (todayDate >= selectedDate)
                {
                    Txt_Resignation.Text = "";
                    msgsave.Text = "Please select date greater than today's date.";
                    msgsave.Visible = true;
                    return;
                }
            }
            if (Convert.ToString(ddlEmployment.Text) == "2" || Convert.ToString(ddlEmployment.Text) == "4")
            { 
                if(txt_Contract_End_date.Text.ToString() == "")
                {
                    txt_Contract_End_date.Text = "";
                    msgsave.Text = "Please select contract end date.";
                    msgsave.Visible = true;
                    return;
                }
            }
                SqlParameter[] spars = new SqlParameter[3];

            spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars[0].Value = "Check_Duplicate_insert";

            spars[1] = new SqlParameter("@Emp_Code", SqlDbType.VarChar);
            if (Txt_Code.Text.ToString() == "")
                spars[1].Value = DBNull.Value;
            else
                spars[1].Value = Txt_Code.Text;

            spars[2] = new SqlParameter("@Id", SqlDbType.Int);
            spars[2].Value = DBNull.Value;

            DataTable dt = adm.getDuplicate_List(spars, "SP_Admin_Employee_Join");

            if (dt.Rows.Count > 0)
            {
                msgsave.Text = "Employee with Same Code Already Exists!";
                msgsave.Visible = true;
                return;
            }

            if (dt.Rows.Count > 0)
            {
                msgsave.Text = "Employee with Same Code Already Exists!";
                msgsave.Visible = true;
                return;
            }

	       if (uploadfile.HasFile)
            {
                string extension = System.IO.Path.GetExtension(uploadfile.FileName);
                if (extension == ".jpg")
                {

                }
                else
                {
                    msgsave.Text = "Please upload Employee Photo (.jpg format & Dimensions W X H : 190x250)!";
                    msgsave.Visible = true;
                    return;
                }
            }
            else
            {
                if (projectid == 0)
                {
                    msgsave.Text = "Please upload Employee Photo (.jpg format & Dimensions W X H : 190x250)!";
                    msgsave.Visible = true;
                    return;
                }
            }

            //if (FileUploadCandidate.HasFile)
            //{

            //}
            //else
            //{
            //    if (projectid == 0)
            //    {
            //        msgsave.Text = "Please upload Candidate Letter (.pdf format)!";
            //        msgsave.Visible = true;
            //        return;
            //    }
            //}

            spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars[0].Value = "Check_Duplicate_insertEmail";

            spars[1] = new SqlParameter("@Emp_Emailaddress", SqlDbType.VarChar);
            if (Txt_Email.Text.ToString() == "")
                spars[1].Value = DBNull.Value;
            else
                spars[1].Value = Txt_Email.Text;

            spars[2] = new SqlParameter("@Id", SqlDbType.Int);
            spars[2].Value = DBNull.Value;

            DataTable dt1 = adm.getDuplicate_List(spars, "SP_Admin_Employee_Join");

            if (dt1.Rows.Count > 0)
            {
                msgsave.Text = "Employee with Same E-mail ID Already Exists!";
                msgsave.Visible = true;
                return;
            }

            msgsave.Visible = false;
            //SqlParameter[] spars1 = new SqlParameter[84];
           // SqlParameter[] spars1 = new SqlParameter[85];
          //  SqlParameter[] spars1 = new SqlParameter[89];
            SqlParameter[] spars1 = new SqlParameter[99];// Add 

            spars1[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars1[1] = new SqlParameter("@Id", SqlDbType.Int);
            spars1[2] = new SqlParameter("@Emp_Code", SqlDbType.VarChar);
            spars1[3] = new SqlParameter("@Emp_Name", SqlDbType.VarChar);
            spars1[4] = new SqlParameter("@Desig_iD", SqlDbType.Int);
            spars1[5] = new SqlParameter("@dept_id", SqlDbType.Int);
            spars1[6] = new SqlParameter("@grade", SqlDbType.VarChar);
            spars1[7] = new SqlParameter("@Emp_Emailaddress", SqlDbType.VarChar);
            spars1[8] = new SqlParameter("@emp_status", SqlDbType.VarChar);
            spars1[9] = new SqlParameter("@Resig_Date", SqlDbType.VarChar);
            spars1[10] = new SqlParameter("@Gender", SqlDbType.VarChar);
            spars1[11] = new SqlParameter("@salutation", SqlDbType.VarChar);
            spars1[12] = new SqlParameter("@first_name", SqlDbType.VarChar);
            spars1[13] = new SqlParameter("@last_name", SqlDbType.VarChar);
            spars1[14] = new SqlParameter("@emp_dob", SqlDbType.VarChar);
            spars1[15] = new SqlParameter("@emp_doj", SqlDbType.VarChar);
            spars1[16] = new SqlParameter("@emp_location", SqlDbType.VarChar);
            spars1[17] = new SqlParameter("@emp_projectName", SqlDbType.VarChar);
            spars1[18] = new SqlParameter("@emp_office_contact_no", SqlDbType.VarChar);
            spars1[19] = new SqlParameter("@emp_photo", SqlDbType.VarChar);
            spars1[20] = new SqlParameter("@POST", SqlDbType.VarChar);
            spars1[21] = new SqlParameter("@CONTACT_DIS", SqlDbType.VarChar);
            spars1[22] = new SqlParameter("@LEAVE_ELE", SqlDbType.VarChar);
            spars1[23] = new SqlParameter("@PROJ_NAME_LONG", SqlDbType.VarChar);
            spars1[24] = new SqlParameter("@Department", SqlDbType.VarChar);
            spars1[25] = new SqlParameter("@Designation", SqlDbType.VarChar);
            spars1[26] = new SqlParameter("@emp_km_range", SqlDbType.Int);
            spars1[27] = new SqlParameter("@emp_A_Grade", SqlDbType.VarChar);
            spars1[28] = new SqlParameter("@middel_name", SqlDbType.VarChar);
            spars1[29] = new SqlParameter("@ABKRS", SqlDbType.VarChar);
            spars1[30] = new SqlParameter("@ATEXT", SqlDbType.VarChar);
            spars1[31] = new SqlParameter("@grde_KM_Avg", SqlDbType.Decimal);
            spars1[32] = new SqlParameter("@mobile", SqlDbType.VarChar);
            spars1[33] = new SqlParameter("@mobile_qty", SqlDbType.Decimal);
            spars1[34] = new SqlParameter("@fuel_qty", SqlDbType.Decimal);
            spars1[35] = new SqlParameter("@FuelType", SqlDbType.VarChar);
            spars1[36] = new SqlParameter("@MOTHER_NAME", SqlDbType.VarChar);
            spars1[37] = new SqlParameter("@ISMARRIED", SqlDbType.VarChar);
            spars1[38] = new SqlParameter("@ANNIVERSARY_DATE", SqlDbType.VarChar);
            spars1[39] = new SqlParameter("@NO_OF_KIDS", SqlDbType.Int);
            spars1[40] = new SqlParameter("@C_ADD", SqlDbType.VarChar);
            spars1[41] = new SqlParameter("@C_PIN", SqlDbType.VarChar);
            spars1[42] = new SqlParameter("@C_CITY", SqlDbType.VarChar);
            spars1[43] = new SqlParameter("@C_STATE", SqlDbType.VarChar);
            spars1[44] = new SqlParameter("@C_COUNTRY", SqlDbType.VarChar);
            spars1[45] = new SqlParameter("@P_ADD", SqlDbType.VarChar);
            spars1[46] = new SqlParameter("@P_PIN", SqlDbType.VarChar);
            spars1[47] = new SqlParameter("@P_CITY", SqlDbType.VarChar);
            spars1[48] = new SqlParameter("@P_STATE", SqlDbType.VarChar);
            spars1[49] = new SqlParameter("@P_COUNTRY", SqlDbType.VarChar);
            spars1[50] = new SqlParameter("@EMPLOYMENT_TYPE", SqlDbType.Int);
            spars1[51] = new SqlParameter("@RETIREMENT_DATE", SqlDbType.VarChar);
            spars1[52] = new SqlParameter("@RM", SqlDbType.VarChar);
            spars1[53] = new SqlParameter("@IS_SELF_APPROVER", SqlDbType.VarChar);
            spars1[54] = new SqlParameter("@BANK_NAME", SqlDbType.VarChar);
            spars1[55] = new SqlParameter("@BANK_AC", SqlDbType.VarChar);
            spars1[56] = new SqlParameter("@IFSC_CODE", SqlDbType.VarChar);
            spars1[57] = new SqlParameter("@AADHAR", SqlDbType.VarChar);
            spars1[58] = new SqlParameter("@PAN", SqlDbType.VarChar);
            spars1[59] = new SqlParameter("@PASSPORT", SqlDbType.VarChar);
            spars1[60] = new SqlParameter("@EPFO_NO", SqlDbType.VarChar);
            spars1[61] = new SqlParameter("@PENSION_AC", SqlDbType.VarChar);
            spars1[62] = new SqlParameter("@SUPER_ANNUATION", SqlDbType.VarChar);
            spars1[63] = new SqlParameter("@CREATEDBY", SqlDbType.VarChar);
            spars1[64] = new SqlParameter("@UPDATEDBY", SqlDbType.VarChar);
            spars1[65] = new SqlParameter("@CONTACT_PER_1_NAME", SqlDbType.VarChar);
	        spars1[66] = new SqlParameter("@CONTACT_PER_1_NO", SqlDbType.VarChar);
	        spars1[67] = new SqlParameter("@CONTACT_PER_2_NAME", SqlDbType.VarChar);
	        spars1[68] = new SqlParameter("@CONTACT_PER_2_NO", SqlDbType.VarChar);
	        spars1[69] = new SqlParameter("@PERSONAL_EMAIL", SqlDbType.VarChar);
	        spars1[70] = new SqlParameter("@PASS_DATEOFISSUE", SqlDbType.VarChar);
	        spars1[71] = new SqlParameter("@PASS_PLACEOFISSUE", SqlDbType.VarChar);
	        spars1[72] = new SqlParameter("@PASS_EXPIRYDATE", SqlDbType.VarChar);
	        spars1[73] = new SqlParameter("@ECR_STAMP", SqlDbType.VarChar);
	        spars1[74] = new SqlParameter("@UANNO", SqlDbType.VarChar);
	        spars1[75] = new SqlParameter("@BANK_AC_NAME", SqlDbType.VarChar);
	        spars1[76] = new SqlParameter("@BANK_ADDRESS", SqlDbType.VarChar);
	        spars1[77] = new SqlParameter("@BANK_BRANCH_NO", SqlDbType.VarChar);
	        spars1[78] = new SqlParameter("@BANK_MICR", SqlDbType.VarChar);
	        spars1[79] = new SqlParameter("@BLOOD_GRP", SqlDbType.VarChar);
            spars1[80] = new SqlParameter("@QUALIFICATION", SqlDbType.NVarChar);

            spars1[81] = new SqlParameter("@COMPLETE_FLAG", SqlDbType.VarChar);
            spars1[82] = new SqlParameter("@EMP_MODULE", SqlDbType.Int);
            spars1[83] = new SqlParameter("@OTHER_MODULES", SqlDbType.NVarChar);
            //Add New 18_02_2021
            spars1[84] = new SqlParameter("@SHIFT_ID", SqlDbType.Int);
            spars1[85] = new SqlParameter("@emp_WEDate", SqlDbType.VarChar);
            
            spars1[86] = new SqlParameter("@EMP_MODULE_S", SqlDbType.Int);
            spars1[87] = new SqlParameter("@EMP_MODULE_T", SqlDbType.Int);
            spars1[88] = new SqlParameter("@ContractEndDate", SqlDbType.VarChar);

            spars1[89] = new SqlParameter("@Candidate_ID", SqlDbType.Int);
            spars1[90] = new SqlParameter("@Recruitment_ReqID", SqlDbType.Int);
            spars1[91] = new SqlParameter("@Appointmentletterissuedstatus", SqlDbType.VarChar);
            spars1[92] = new SqlParameter("@PayRollChange", SqlDbType.Int);
            spars1[93] = new SqlParameter("@OldRefEmpCode", SqlDbType.VarChar);
			spars1[94] = new SqlParameter("@AgreedBG", SqlDbType.VarChar);
			spars1[95] = new SqlParameter("@BGAmount", SqlDbType.Decimal);
			spars1[96] = new SqlParameter("@AgreedPDC", SqlDbType.VarChar);
			spars1[97] = new SqlParameter("@PDCDetails", SqlDbType.VarChar);
            spars1[98] = new SqlParameter("@ChkedWelcomeMail", SqlDbType.VarChar);
            //spars1[92] = new SqlParameter("@AppointmentletterIssueddate", SqlDbType.VarChar);
            //spars1[93] = new SqlParameter("@Candidate_letter", SqlDbType.VarChar);


            spars1[0].Value = "Insert";
            spars1[1].Value = DBNull.Value;
            spars1[2].Value = Txt_Code.Text.ToString(); //;
            spars1[3].Value = DDl_Salutationtexts.Text.ToString() + " " + Txt_NameF.Text.ToString() + " " + Txt_NameM.Text.ToString() + " " + Txt_NameL.Text.ToString();
            spars1[4].Value = Convert.ToInt32(ddl_DesignationId.Text.ToString());
            spars1[5].Value = Convert.ToInt32(ddl_DepartmentId.Text.ToString());
            spars1[6].Value = ddl_Bandtexts.Text.ToString();
            spars1[7].Value = Txt_Email.Text.ToString();
            spars1[8].Value = "Onboard";
            spars1[9].Value = DBNull.Value;
            spars1[10].Value = ddlGendertexts.Text.ToString();
            spars1[11].Value = DDl_Salutationtexts.Text.ToString();
            spars1[12].Value = Txt_NameF.Text.ToString();
            spars1[13].Value = Txt_NameL.Text.ToString();
            spars1[14].Value = Birthdate.ToString();
            spars1[15].Value = JoiningDate.ToString();
            spars1[16].Value = ddl_LocationId.Text.ToString();
            spars1[17].Value = ddl_Locationtexts.Text.ToString();
            spars1[18].Value = Txt_Telephone.Text.ToString();
            spars1[19].Value = ".jpg";
            spars1[20].Value = ddl_Bandtexts.Text.ToString();
            spars1[21].Value = chk_C.ToString();
            spars1[22].Value = chk_L.ToString();
            spars1[23].Value = ddl_Locationtexts.Text.ToString();
            spars1[24].Value = ddl_Departmenttexts.Text.ToString();
            spars1[25].Value = ddl_Designationtexts.Text.ToString();
            spars1[26].Value = DBNull.Value;
            spars1[27].Value = ddl_Bandtexts.Text.ToString();
            spars1[28].Value = Txt_NameM.Text.ToString();
            spars1[29].Value = DBNull.Value;
            spars1[30].Value = DBNull.Value;
            spars1[31].Value = Convert.ToDecimal(Car_AVG.ToString());
            spars1[32].Value = Txt_Mobile.Text.ToString();
            spars1[33].Value = DBNull.Value;
            spars1[34].Value = DBNull.Value;
            spars1[35].Value = DBNull.Value;
            spars1[36].Value = Txt_Mother.Text.ToString();
            spars1[37].Value = DDl_Mar_Stattexts.Text.ToString();
            spars1[38].Value = Anniversarydate.ToString();
            spars1[39].Value = Convert.ToInt32(Txt_kids.Text);
            spars1[40].Value = txt_Address.Text.ToString();
            spars1[41].Value = txt_Pin.Text.ToString();
            spars1[42].Value = txt_City.Text.ToString();
            spars1[43].Value = txt_State.Text.ToString();
            spars1[44].Value = txt_Country.Text.ToString();
            spars1[45].Value = txt_Address_P.Text.ToString();
            spars1[46].Value = txt_Pin_P.Text.ToString();
            spars1[47].Value = txt_City_P.Text.ToString();
            spars1[48].Value = txt_State_P.Text.ToString();
            spars1[49].Value = txt_Country_P.Text.ToString();
            spars1[50].Value = Convert.ToInt32(ddlEmploymentId.Text.ToString());
            spars1[51].Value = RetirementDate.ToString();
            spars1[52].Value = ddl_EmployeeId.Text.ToString();
            spars1[53].Value = chk_S.ToString();
            spars1[54].Value = Txt_BankName.Text.ToString();
            spars1[55].Value = Txt_BankAC.Text.ToString();
            spars1[56].Value = Txt_IFSC.Text.ToString();
            spars1[57].Value = Txt_Aadhar.Text.ToString();
            spars1[58].Value = Txt_PAN.Text.ToString();
            spars1[59].Value = Txt_Passport.Text.ToString();
            spars1[60].Value = Txt_EPF.Text.ToString();
            spars1[61].Value = Txt_Pension.Text.ToString();
            spars1[62].Value = Txt_Super.Text.ToString();
            spars1[63].Value = str;
            spars1[64].Value = str;
            spars1[65].Value = txt_Emg_contact_pers_1.Text.ToString();
            spars1[66].Value = txt_Emg_contact_1.Text.ToString();
            spars1[67].Value = txt_Emg_contact_pers_2.Text.ToString();
            spars1[68].Value = txt_Emg_contact_2.Text.ToString();
            spars1[69].Value = txt_PersonalEmail.Text.ToString();
            if (PassIssueDate.ToString() == "")
                spars1[70].Value = DBNull.Value;
            else
                spars1[70].Value = PassIssueDate.ToString();
            spars1[71].Value = Txt_PassIssue.Text.ToString();
            if (PassExpiryDate.ToString() == "")
                spars1[72].Value = DBNull.Value;
            else
                spars1[72].Value = PassExpiryDate.ToString();
            spars1[73].Value = chk_ecr.ToString();
            spars1[74].Value = Txt_UAN.Text.ToString();
            spars1[75].Value = Txt_BankAC_Name.Text.ToString();
            spars1[76].Value = Txt_BankAddress.Text.ToString();
            spars1[77].Value = Txt_BankbranchNo.Text.ToString();
            spars1[78].Value = Txt_MICR.Text.ToString();
            spars1[79].Value = txt_Bloodgroup.Text.ToString();
            spars1[80].Value = "";

            spars1[81].Value = ddl_completetexts.Text.ToString();
            spars1[82].Value = Convert.ToInt32(ddl_ModuleId.Text);
            
            spars1[83].Value = Txt_OthModules.Text.ToString();
            spars1[84].Value = Convert.ToInt32(ddl_ShiftId.Text);
            spars1[85].Value = withEffectivDate.ToString();

            if (Convert.ToString(ddl_Module1Id.Text) != "")
                spars1[86].Value = Convert.ToInt32(ddl_Module1Id.Text);
            else
                spars1[86].Value = DBNull.Value;

            if (Convert.ToString(ddl_Module2Id.Text) != "")
                spars1[87].Value = Convert.ToInt32(ddl_Module2Id.Text);
            else
                spars1[87].Value = DBNull.Value;

            
            if (Convert.ToString(ddlEmployment.Text) == "2"|| Convert.ToString(ddlEmployment.Text)=="4")
            {
                strdate = Convert.ToString(txt_Contract_End_date.Text).Trim().Split('/');
                ContractEndDate = Convert.ToString(strdate[2]) + "-" + Convert.ToString(strdate[1]) + "-" + Convert.ToString(strdate[0]);
                spars1[88].Value = ContractEndDate.ToString();
            }               
            else
            {
                spars1[88].Value = DBNull.Value;
            }

            if (CHKPayRollChange.Checked == true)
            {
                spars1[89].Value = HFCandidateIDOld.Value;
                spars1[90].Value = hdRecruitment_ReqID.Value;
                spars1[91].Value = "No";
                spars1[92].Value = "1";
                spars1[93].Value = DDLOldEmpCodeRefID.SelectedValue;
            }
            else
            {
                spars1[89].Value = Convert.ToInt32(DDLCandidateName.SelectedValue);
                spars1[90].Value = Convert.ToInt32(hdRecruitment_ReqID.Value);
                spars1[91].Value = "No";
                spars1[92].Value = DBNull.Value;
                spars1[93].Value = DBNull.Value;
            }
			if (Convert.ToInt32(ddl_DepartmentId.Text.ToString()) == 14)
			{
				if (chkAgreedBG.Checked == true)
				{
					spars1[94].Value = 1;
					spars1[95].Value = Convert.ToDecimal(txtAgreedBG.Text.Trim());
				}
				else
				{
					spars1[94].Value = 0;
					spars1[95].Value = DBNull.Value;
				}					
				
				if (chkAgreedPDC.Checked == true)
				{
					spars1[96].Value = 1;
					spars1[97].Value = txtAgreedPDC.Text.Trim();
				}
				else
				{
					spars1[96].Value = 0;
					spars1[97].Value = DBNull.Value;
				}
				
			}
			else
			{
				spars1[94].Value = DBNull.Value;
				spars1[95].Value = DBNull.Value;
				spars1[96].Value = DBNull.Value;
				spars1[97].Value = DBNull.Value;
			}

            spars1[98].Value = CHK_SendWelcomeEmail.Checked;

            //spars1[89].Value = Convert.ToInt32(DDLCandidateName.SelectedValue);
            //spars1[90].Value = Convert.ToInt32(hdRecruitment_ReqID.Value);
            //spars1[91].Value = "No";
            //spars1[92].Value = AppletterissueDate.ToString();
            //spars1[93].Value = ".pdf";



            adm.Insert_Data(spars1, "SP_Admin_Employee_Join");

            AddUser("hrms@2020",0,Txt_Code.Text.ToString(),DDl_Salutationtexts.Text.ToString() + " " + Txt_NameF.Text.ToString() + " " + Txt_NameM.Text.ToString() + " " + Txt_NameL.Text.ToString(),Txt_Email.Text.ToString());

            #region Send Onboarding mail
            spars = new SqlParameter[2];

            spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars[0].Value = "onBoardingMail_EmployeeDetails";

            spars[1] = new SqlParameter("@Emp_Emailaddress", SqlDbType.VarChar);
            spars[1].Value = Txt_Email.Text.ToString();

            DataTable tt = adm.getData_FromCode(spars, "SP_Admin_Employee_Join");
            //project myproject = classproject.getsingleprojects(projectid);

            if (tt.Rows.Count > 0)
            {
                if (CHKPayRollChange.Checked == true)
                {

                }
                else
                {
                    HDEmpcodenew.Value = Convert.ToString(tt.Rows[0]["Emp_Code"].ToString());
                   ClosedRequisition(str); 
		          CheckReferral_Candidated(str);
                }

                 //HDEmpcodenew.Value = Convert.ToString(tt.Rows[0]["Emp_Code"].ToString());
		        //ClosedRequisition(str);

                strbuild.Length = 0;
                strbuild.Clear();
                strbuild.Append("<table role='presentation' width='800' style='width: 800px;' cellpadding='1' cellspacing='1' border='0'>");

                foreach (DataRow row in tt.Rows)
                {
                    string photoURL = "";
                    if (ddlEmploymentId.Text.ToString() == "1")
                        photoURL = "https://ess.highbartech.com/hrmsadmin/images/profilephoto/" + Convert.ToDouble(row["Emp_Code"].ToString().Trim()) + ".jpg";
                    else
                        photoURL = "https://ess.highbartech.com/hrmsadmin/images/profilephoto/" + row["Emp_Code"].ToString().Trim() + ".jpg";
                    if (Convert.ToString(row["emp_location"].ToString()) == "HO-NaviMum")
                    {
                        strbuild.Append("<tr><td width='250px' rowspan='14'><img src='" + photoURL.ToString() + "' width='250' /></td><td width='150px'>Employee Code: </td><td width='400px'>" + Convert.ToString(row["Emp_Code"].ToString())
                            + "</td></tr><tr><td width='150px'>Employee Name: </td><td width='400px'>" + Convert.ToString(row["Emp_Name"].ToString())
                            + "</td></tr><tr><td width='150px'>Employment Type: </td><td width='400px'>" + Convert.ToString(row["Particulars"].ToString())
                            + "</td></tr><tr><td width='150px'>Date of Joining: </td><td width='400px'>" + Convert.ToString(row["emp_doj"].ToString())
                            + "</td></tr><tr><td width='150px'>Email Id: </td><td width='400px'>" + Convert.ToString(row["Emp_Emailaddress"].ToString())
                            + "</td></tr><tr><td width='150px'>Mobile no.: </td><td width='400px'>" + Convert.ToString(row["mobile"].ToString())
                            + "</td></tr><tr><td width='150px'>Location: </td><td width='400px'>" + Convert.ToString(row["emp_location"].ToString())
                            + "</td></tr><tr><td width='150px'>Department: </td><td width='400px'>" + Convert.ToString(row["Department_Name"].ToString())
                            + "</td></tr><tr><td width='150px'>Designation: </td><td width='400px'>" + Convert.ToString(row["DesginationName"].ToString())
                            + "</td></tr><tr><td width='150px'>Main Module: </td><td width='400px'>" + Convert.ToString(row["ModuleDesc"].ToString())
                            + "</td></tr><tr><td width='150px'>Other Modules: </td><td width='400px'>" + Convert.ToString(row["OTHER_MODULES"].ToString())
                            + "</td></tr><tr><td width='150px'>Reporting Manager: </td><td width='400px'>" + Convert.ToString(row["RM"].ToString())
                            + "</td></tr><tr><td width='150px'>HOD: </td><td width='400px'>" + Convert.ToString(row["DH"].ToString())
                            + "</td></tr><tr><td width='150px'>Blood Group: </td><td width='400px'>" + Convert.ToString(row["BLOOD_GRP"].ToString())
                            + "</td></tr>");

                    }
                    else
                    {
                        strbuild.Append("<tr><td width='250px' rowspan='16'><img src='" + photoURL.ToString() + "' width='250' /></td><td width='150px'>Employee Code: </td><td>" + Convert.ToString(row["Emp_Code"].ToString())
                            + "</td></tr><tr><td width='150px'>Employee Name: </td><td width='400px'>" + Convert.ToString(row["Emp_Name"].ToString())
                            + "</td></tr><tr><td width='150px'>Employment Type: </td><td width='400px'>" + Convert.ToString(row["Particulars"].ToString())
                            + "</td></tr><tr><td width='150px'>Date of Joining: </td><td width='400px'>" + Convert.ToString(row["emp_doj"].ToString())
                            + "</td></tr><tr><td width='150px'>Email Id: </td><td width='400px'>" + Convert.ToString(row["Emp_Emailaddress"].ToString())
                            + "</td></tr><tr><td width='150px'>Mobile no.: </td><td width='400px'>" + Convert.ToString(row["mobile"].ToString())
                            + "</td></tr><tr><td width='150px'>Location: </td><td width='400px'>" + Convert.ToString(row["emp_location"].ToString())
                            + "</td></tr><tr><td width='150px'>Department: </td><td width='400px'>" + Convert.ToString(row["Department_Name"].ToString())
                            + "</td></tr><tr><td width='150px'>Designation: </td><td width='400px'>" + Convert.ToString(row["DesginationName"].ToString())
                            + "</td></tr><tr><td width='150px'>Main Module: </td><td width='400px'>" + Convert.ToString(row["ModuleDesc"].ToString())
                            + "</td></tr><tr><td width='150px'>Other Modules: </td><td width='400px'>" + Convert.ToString(row["OTHER_MODULES"].ToString())
                            + "</td></tr><tr><td width='150px'>Project Manager: </td><td width='400px'>" + Convert.ToString(row["RM"].ToString())
                            + "</td></tr><tr><td width='150px'>Delivery Manager: </td><td width='400px'>" + Convert.ToString(row["DM"].ToString())
                            + "</td></tr><tr><td width='150px'>Program Manager: </td><td width='400px'>" + Convert.ToString(row["PRM"].ToString())
                            + "</td></tr><tr><td width='150px'>Delivery Head: </td><td width='400px'>" + Convert.ToString(row["DH"].ToString())
                            + "</td></tr><tr><td width='150px'>Blood Group: </td><td width='400px'>" + Convert.ToString(row["BLOOD_GRP"].ToString())
                            + "</td></tr>");

                    }
                    emp_name = Convert.ToString(row["Emp_Name"].ToString());
                }
                strbuild.Append("</table>");
            }

        #region Create AssetAllocation Request for new joinee

            //Added for Asset allocation Request creation for IT Asset Inventory Workflow
            SqlParameter[] spars2 = new SqlParameter[2];
            spars2[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars2[0].Value = "InsertAssetAllocationReqNo";

            spars2[1] = new SqlParameter("@Emp_Emailaddress", SqlDbType.VarChar);
            spars2[1].Value = Txt_Email.Text.ToString().Trim();
            var AARNoId = adm.Insert_DataGetOutputId(spars2, "SP_Admin_AssetInventory");

            SqlParameter[] spars3 = new SqlParameter[2];
            spars3[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars3[0].Value = "GetEmpData";

            spars3[1] = new SqlParameter("@Emp_Emailaddress", SqlDbType.VarChar);
            spars3[1].Value = Txt_Email.Text.ToString().Trim();
            DataTable t1 = adm.getData_FromCode(spars3, "SP_Admin_AssetInventory");
            string AAReqNo = ""; string EmpCode = ""; string Empname = ""; string Doj = ""; string Location = ""; string Dept = "";
            string Desig = ""; string RMgr = ""; string HOD = "";
            if (t1.Rows.Count > 0)
            {
                AAReqNo = Convert.ToString(t1.Rows[0]["AARNo"]);
                EmpCode = Convert.ToString(t1.Rows[0]["Emp_Code"]);
                Empname = Convert.ToString(t1.Rows[0]["Emp_Name"]);
                Doj = Convert.ToString(t1.Rows[0]["doj"]);
                Location = Convert.ToString(t1.Rows[0]["emp_location"]);
                Dept = Convert.ToString(t1.Rows[0]["Department"]);
                Desig = Convert.ToString(t1.Rows[0]["Designation"]);
                RMgr = Convert.ToString(t1.Rows[0]["RM"]);
                HOD = Convert.ToString(t1.Rows[0]["HOD"]);
            }

            SqlParameter[] spars4 = new SqlParameter[1];
            spars4[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars4[0].Value = "GetAllCustodianDetails";

            DataTable t2 = adm.getData_FromCode(spars4, "SP_Admin_AssetInventory");
            if (t2.Rows.Count > 0)
            {
                to_email = "";

                foreach (DataRow row in t2.Rows)
                {
                    to_email = to_email + Convert.ToString(row["email"].ToString()) + ";";
                }
            }
            //Sada 14012022
            adm.SendMailToAllCustodian_NewEmployee_onBoard(Empname, AAReqNo, EmpCode, Doj, Location, Dept, Desig, RMgr, HOD, to_email, Convert.ToInt32(AARNoId));

            #endregion

            spars = new SqlParameter[2];

            spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars[0].Value = "onBoardingMail_ApproverDetails";

            spars[1] = new SqlParameter("@Emp_Emailaddress", SqlDbType.VarChar);
            spars[1].Value = Txt_Email.Text.ToString();

            DataTable tt1 = adm.getData_FromCode(spars, "SP_Admin_Employee_Join");
            //project myproject = classproject.getsingleprojects(projectid);

            if (tt1.Rows.Count > 0)
            {
                to_email = "";

                foreach (DataRow row in tt1.Rows)
                {
                    to_email = to_email + Convert.ToString(row["email"].ToString()) + ";";
                }
            }

            string cc_email = "";
            spars = new SqlParameter[2];

            spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars[0].Value = "onBoardingMail_CCDetails";

            spars[1] = new SqlParameter("@Emp_Emailaddress", SqlDbType.VarChar);
            spars[1].Value = Txt_Email.Text.ToString();

            DataTable tt2 = adm.getData_FromCode(spars, "SP_Admin_Employee_Join");
            //project myproject = classproject.getsingleprojects(projectid);

            if (tt2.Rows.Count > 0)
            {
                cc_email = "";

                foreach (DataRow row in tt2.Rows)
                {
                    cc_email = cc_email + Convert.ToString(row["email"].ToString()) + ";";
                }
            }
            //Sada 14012022
            adm.send_mail_NewEmployee_onBoarded(emp_name, to_email, emp_name + " onboarded", Convert.ToString(strbuild), "", cc_email);

            #endregion Send Onboarding mail

            //Send Welcome Email For Employee
           #region Send Welcome Email
            if (tt.Rows.Count > 0)
            {
                var DesginationName = "";
                var Department_Name = "";
                strbuild.Length = 0;
                strbuild.Clear();
                strbuild.Append("<table role='presentation' width='700' style='width: 800px;' cellpadding='1' cellspacing='1' border='0'>");
                var gender = "";
                foreach (DataRow row in tt.Rows)
                {
                    string photoURL = "";
                    if (ddlEmploymentId.Text.ToString() == "1")
                        photoURL = "https://ess.highbartech.com/hrmsadmin/images/profilephoto/" + Convert.ToDouble(row["Emp_Code"].ToString().Trim()) + ".jpg";
                    else
                        photoURL = "https://ess.highbartech.com/hrmsadmin/images/profilephoto/" + row["Emp_Code"].ToString().Trim() + ".jpg";
                    if (ddlGendertexts.Text.ToString() == "Male")
                    {
                        strbuild.Append("<tr><td width='190px' height='250px' rowspan='10'><img src='" + photoURL.ToString() + "' width='190' style='border: 5px solid #555;' /></td><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'>" + Convert.ToString(row["Emp_Name"].ToString()) + " will report to " + Convert.ToString(row["RM"].ToString()) + "."
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'>He can be reached on his mobile number <b>" + Convert.ToString(row["mobile"].ToString()) + "</b>."
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr>");

                    }
                    else
                    {
                        strbuild.Append("<tr><td width='190px' height='250px' rowspan='10'><img src='" + photoURL.ToString() + "' width='190' style='border: 5px solid #555;' /></td><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'>" + Convert.ToString(row["Emp_Name"].ToString()) + " will report to " + Convert.ToString(row["RM"].ToString()) + "."
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'>She can be reached on her mobile number <b>" + Convert.ToString(row["mobile"].ToString()) + "</b>."
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr><tr><td width='10px' height='25px'>&nbsp;&nbsp;&nbsp;&nbsp; </td><td width='500px' height='25px'> "
                            + "</td></tr>");

                    }
                    emp_name = Convert.ToString(row["Emp_Name"].ToString());
                    DesginationName = Convert.ToString(row["DesginationName"].ToString());
                    Department_Name = Convert.ToString(row["Department_Name"].ToString());
                }
                strbuild.Append("</table>");
                cc_email = to_email;
                // var t = to_email;
                if (CHK_SendWelcomeEmail.Checked == true)
                {
                    to_email = "allhighbartechnocratemployees@highbartech.com;allhighbartechnocratconsutant@highbartech.com";
                    //Sada 14012022
                    adm.send_mail_NewEmployee_onBoarded_Welcome(emp_name, to_email, "Welcome " + emp_name, Convert.ToString(strbuild), "", cc_email, DesginationName, Department_Name);
                }

            }


            #endregion

            //End  Send Welcome Email For EmployeeS



            if (FileUploadCandidate.HasFile)
            {
                string filenameCandidate = "";
                string strfileNameCandidate = "";
                filenameCandidate = FileUploadCandidate.FileName;
                if (Convert.ToString(filenameCandidate).Trim() != "")
                {
                    string CandidateAdminPath = Server.MapPath(Convert.ToString(ConfigurationManager.AppSettings["CandidateAttachment"]).Trim());
                    String InputFile = System.IO.Path.GetExtension(FileUploadCandidate.FileName);
                    strfileNameCandidate = HDEmpcodenew.Value + InputFile;
                    FileUploadCandidate.SaveAs(Path.Combine(CandidateAdminPath, strfileNameCandidate));
                }
            }

           

        }
        else
        {
            SqlParameter[] spars = new SqlParameter[3];

            spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars[0].Value = "Check_Duplicate_update";

            spars[1] = new SqlParameter("@Emp_Code", SqlDbType.VarChar);
            if (Txt_Code.Text.ToString() == "")
                spars[1].Value = DBNull.Value;
            else
                spars[1].Value = Txt_Code.Text;

            spars[2] = new SqlParameter("@Id", SqlDbType.Int);
            spars[2].Value = projectid;

            DataTable dt = adm.getDuplicate_List(spars, "SP_Admin_Employee_Join");

            if (dt.Rows.Count > 0)
            {
                msgsave.Text = "Employee with Same Code Already Exists!";
                msgsave.Visible = true;
                return;
            }


            spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars[0].Value = "Check_Duplicate_updateEmail";

            spars[1] = new SqlParameter("@Emp_Emailaddress", SqlDbType.VarChar);
            if (Txt_Email.Text.ToString() == "")
                spars[1].Value = DBNull.Value;
            else
                spars[1].Value = Txt_Email.Text;

            spars[2] = new SqlParameter("@Id", SqlDbType.Int);
            spars[2].Value = projectid;

            DataTable dt1 = adm.getDuplicate_List(spars, "SP_Admin_Employee_Join");

            if (dt1.Rows.Count > 0)
            {
                msgsave.Text = "Employee with Same E-mail ID Already Exists!";
                msgsave.Visible = true;
                return;
            }
                msgsave.Visible = false;
                //SqlParameter[] spars1 = new SqlParameter[85];
               // SqlParameter[] spars1 = new SqlParameter[88];
                SqlParameter[] spars1 = new SqlParameter[93]; 


                spars1[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
                spars1[1] = new SqlParameter("@Id", SqlDbType.Int);
                spars1[2] = new SqlParameter("@Emp_Code", SqlDbType.VarChar);
                spars1[3] = new SqlParameter("@Emp_Name", SqlDbType.VarChar);
                spars1[4] = new SqlParameter("@Desig_iD", SqlDbType.Int);
                spars1[5] = new SqlParameter("@dept_id", SqlDbType.Int);
                spars1[6] = new SqlParameter("@grade", SqlDbType.VarChar);
                spars1[7] = new SqlParameter("@Emp_Emailaddress", SqlDbType.VarChar);
                spars1[8] = new SqlParameter("@emp_status", SqlDbType.VarChar);
                spars1[9] = new SqlParameter("@Resig_Date", SqlDbType.VarChar);
                spars1[10] = new SqlParameter("@Gender", SqlDbType.VarChar);
                spars1[11] = new SqlParameter("@salutation", SqlDbType.VarChar);
                spars1[12] = new SqlParameter("@first_name", SqlDbType.VarChar);
                spars1[13] = new SqlParameter("@last_name", SqlDbType.VarChar);
                spars1[14] = new SqlParameter("@emp_dob", SqlDbType.VarChar);
                spars1[15] = new SqlParameter("@emp_doj", SqlDbType.VarChar);
                spars1[16] = new SqlParameter("@emp_location", SqlDbType.VarChar);
                spars1[17] = new SqlParameter("@emp_projectName", SqlDbType.VarChar);
                spars1[18] = new SqlParameter("@emp_office_contact_no", SqlDbType.VarChar);
                spars1[19] = new SqlParameter("@emp_photo", SqlDbType.VarChar);
                spars1[20] = new SqlParameter("@POST", SqlDbType.VarChar);
                spars1[21] = new SqlParameter("@CONTACT_DIS", SqlDbType.VarChar);
                spars1[22] = new SqlParameter("@LEAVE_ELE", SqlDbType.VarChar);
                spars1[23] = new SqlParameter("@PROJ_NAME_LONG", SqlDbType.VarChar);
                spars1[24] = new SqlParameter("@Department", SqlDbType.VarChar);
                spars1[25] = new SqlParameter("@Designation", SqlDbType.VarChar);
                spars1[26] = new SqlParameter("@emp_km_range", SqlDbType.Int);
                spars1[27] = new SqlParameter("@emp_A_Grade", SqlDbType.VarChar);
                spars1[28] = new SqlParameter("@middel_name", SqlDbType.VarChar);
                spars1[29] = new SqlParameter("@ABKRS", SqlDbType.VarChar);
                spars1[30] = new SqlParameter("@ATEXT", SqlDbType.VarChar);
                spars1[31] = new SqlParameter("@grde_KM_Avg", SqlDbType.Decimal);
                spars1[32] = new SqlParameter("@mobile", SqlDbType.VarChar);
                spars1[33] = new SqlParameter("@mobile_qty", SqlDbType.Decimal);
                spars1[34] = new SqlParameter("@fuel_qty", SqlDbType.Decimal);
                spars1[35] = new SqlParameter("@FuelType", SqlDbType.VarChar);
                spars1[36] = new SqlParameter("@MOTHER_NAME", SqlDbType.VarChar);
                spars1[37] = new SqlParameter("@ISMARRIED", SqlDbType.VarChar);
                spars1[38] = new SqlParameter("@ANNIVERSARY_DATE", SqlDbType.VarChar);
                spars1[39] = new SqlParameter("@NO_OF_KIDS", SqlDbType.Int);
                spars1[40] = new SqlParameter("@C_ADD", SqlDbType.VarChar);
                spars1[41] = new SqlParameter("@C_PIN", SqlDbType.VarChar);
                spars1[42] = new SqlParameter("@C_CITY", SqlDbType.VarChar);
                spars1[43] = new SqlParameter("@C_STATE", SqlDbType.VarChar);
                spars1[44] = new SqlParameter("@C_COUNTRY", SqlDbType.VarChar);
                spars1[45] = new SqlParameter("@P_ADD", SqlDbType.VarChar);
                spars1[46] = new SqlParameter("@P_PIN", SqlDbType.VarChar);
                spars1[47] = new SqlParameter("@P_CITY", SqlDbType.VarChar);
                spars1[48] = new SqlParameter("@P_STATE", SqlDbType.VarChar);
                spars1[49] = new SqlParameter("@P_COUNTRY", SqlDbType.VarChar);
                spars1[50] = new SqlParameter("@EMPLOYMENT_TYPE", SqlDbType.Int);
                spars1[51] = new SqlParameter("@RETIREMENT_DATE", SqlDbType.VarChar);
                spars1[52] = new SqlParameter("@RM", SqlDbType.VarChar);
                spars1[53] = new SqlParameter("@IS_SELF_APPROVER", SqlDbType.VarChar);
                spars1[54] = new SqlParameter("@BANK_NAME", SqlDbType.VarChar);
                spars1[55] = new SqlParameter("@BANK_AC", SqlDbType.VarChar);
                spars1[56] = new SqlParameter("@IFSC_CODE", SqlDbType.VarChar);
                spars1[57] = new SqlParameter("@AADHAR", SqlDbType.VarChar);
                spars1[58] = new SqlParameter("@PAN", SqlDbType.VarChar);
                spars1[59] = new SqlParameter("@PASSPORT", SqlDbType.VarChar);
                spars1[60] = new SqlParameter("@EPFO_NO", SqlDbType.VarChar);
                spars1[61] = new SqlParameter("@PENSION_AC", SqlDbType.VarChar);
                spars1[62] = new SqlParameter("@SUPER_ANNUATION", SqlDbType.VarChar);
                spars1[63] = new SqlParameter("@CREATEDBY", SqlDbType.VarChar);
                spars1[64] = new SqlParameter("@UPDATEDBY", SqlDbType.VarChar);
                spars1[65] = new SqlParameter("@CONTACT_PER_1_NAME", SqlDbType.VarChar);
                spars1[66] = new SqlParameter("@CONTACT_PER_1_NO", SqlDbType.VarChar);
                spars1[67] = new SqlParameter("@CONTACT_PER_2_NAME", SqlDbType.VarChar);
                spars1[68] = new SqlParameter("@CONTACT_PER_2_NO", SqlDbType.VarChar);
                spars1[69] = new SqlParameter("@PERSONAL_EMAIL", SqlDbType.VarChar);
                spars1[70] = new SqlParameter("@PASS_DATEOFISSUE", SqlDbType.VarChar);
                spars1[71] = new SqlParameter("@PASS_PLACEOFISSUE", SqlDbType.VarChar);
                spars1[72] = new SqlParameter("@PASS_EXPIRYDATE", SqlDbType.VarChar);
                spars1[73] = new SqlParameter("@ECR_STAMP", SqlDbType.VarChar);
                spars1[74] = new SqlParameter("@UANNO", SqlDbType.VarChar);
                spars1[75] = new SqlParameter("@BANK_AC_NAME", SqlDbType.VarChar);
                spars1[76] = new SqlParameter("@BANK_ADDRESS", SqlDbType.VarChar);
                spars1[77] = new SqlParameter("@BANK_BRANCH_NO", SqlDbType.VarChar);
                spars1[78] = new SqlParameter("@BANK_MICR", SqlDbType.VarChar);
                spars1[79] = new SqlParameter("@BLOOD_GRP", SqlDbType.VarChar);
                spars1[80] = new SqlParameter("@QUALIFICATION", SqlDbType.NVarChar);

                spars1[81] = new SqlParameter("@COMPLETE_FLAG", SqlDbType.VarChar);
                spars1[82] = new SqlParameter("@EMP_MODULE", SqlDbType.Int);
                spars1[83] = new SqlParameter("@OTHER_MODULES", SqlDbType.NVarChar);
                //Add New 18_02_2021
                spars1[84] = new SqlParameter("@SHIFT_ID", SqlDbType.Int);
                spars1[85] = new SqlParameter("@emp_WEDate", SqlDbType.VarChar);
                
                spars1[86] = new SqlParameter("@EMP_MODULE_S", SqlDbType.Int);
                spars1[87] = new SqlParameter("@EMP_MODULE_T", SqlDbType.Int);
                // Add New 28_09_2021
                spars1[88] = new SqlParameter("@Appointmentletterissuedstatus", SqlDbType.VarChar);
			//  spars1[89] = new SqlParameter("@AppointmentletterIssueddate", SqlDbType.VarChar);
				spars1[89] = new SqlParameter("@AgreedBG", SqlDbType.VarChar);
				spars1[90] = new SqlParameter("@BGAmount", SqlDbType.Decimal);
				spars1[91] = new SqlParameter("@AgreedPDC", SqlDbType.VarChar);
				spars1[92] = new SqlParameter("@PDCDetails", SqlDbType.VarChar);


			spars1[0].Value = "Update";
                spars1[1].Value = projectid;    
                spars1[2].Value = Txt_Code.Text.ToString(); //;
                spars1[3].Value = DDl_Salutationtexts.Text.ToString() + " " + Txt_NameF.Text.ToString() + " " + Txt_NameM.Text.ToString() + " " + Txt_NameL.Text.ToString();
                spars1[4].Value = Convert.ToInt32(ddl_DesignationId.Text.ToString());
                spars1[5].Value = Convert.ToInt32(ddl_DepartmentId.Text.ToString());
                spars1[6].Value = ddl_Bandtexts.Text.ToString();
                spars1[7].Value = Txt_Email.Text.ToString();
                spars1[8].Value = "Onboard";
                spars1[9].Value = DBNull.Value;
                spars1[10].Value = ddlGendertexts.Text.ToString();
                spars1[11].Value = DDl_Salutationtexts.Text.ToString();
                spars1[12].Value = Txt_NameF.Text.ToString();
                spars1[13].Value = Txt_NameL.Text.ToString();
                spars1[14].Value = Birthdate.ToString();
                spars1[15].Value = JoiningDate.ToString();
                spars1[16].Value = ddl_LocationId.Text.ToString();
                spars1[17].Value = ddl_Locationtexts.Text.ToString();
                spars1[18].Value = Txt_Telephone.Text.ToString();
                spars1[19].Value = ".jpg";
                spars1[20].Value = ddl_Bandtexts.Text.ToString();
                spars1[21].Value = chk_C.ToString();
                spars1[22].Value = chk_L.ToString();
                spars1[23].Value = ddl_Locationtexts.Text.ToString();
                spars1[24].Value = ddl_Departmenttexts.Text.ToString();
                spars1[25].Value = ddl_Designationtexts.Text.ToString();
                spars1[26].Value = DBNull.Value;
                spars1[27].Value = ddl_Bandtexts.Text.ToString();
                spars1[28].Value = Txt_NameM.Text.ToString();
                spars1[29].Value = DBNull.Value;
                spars1[30].Value = DBNull.Value;
                spars1[31].Value = Convert.ToDecimal(Car_AVG.ToString());
                spars1[32].Value = Txt_Mobile.Text.ToString();
                spars1[33].Value = DBNull.Value;
                spars1[34].Value = DBNull.Value;
                spars1[35].Value = DBNull.Value;
                spars1[36].Value = Txt_Mother.Text.ToString();
                spars1[37].Value = DDl_Mar_Stattexts.Text.ToString();
                spars1[38].Value = Anniversarydate.ToString();
                spars1[39].Value = Convert.ToInt32(Txt_kids.Text);
                spars1[40].Value = txt_Address.Text.ToString();
                spars1[41].Value = txt_Pin.Text.ToString();
                spars1[42].Value = txt_City.Text.ToString();
                spars1[43].Value = txt_State.Text.ToString();
                spars1[44].Value = txt_Country.Text.ToString();
                spars1[45].Value = txt_Address_P.Text.ToString();
                spars1[46].Value = txt_Pin_P.Text.ToString();
                spars1[47].Value = txt_City_P.Text.ToString();
                spars1[48].Value = txt_State_P.Text.ToString();
                spars1[49].Value = txt_Country_P.Text.ToString();
                spars1[50].Value = Convert.ToInt32(ddlEmploymentId.Text.ToString());
                spars1[51].Value = RetirementDate.ToString();
                spars1[52].Value = ddl_EmployeeId.Text.ToString();
                spars1[53].Value = chk_S.ToString();
                spars1[54].Value = Txt_BankName.Text.ToString();
                spars1[55].Value = Txt_BankAC.Text.ToString();
                spars1[56].Value = Txt_IFSC.Text.ToString();
                spars1[57].Value = Txt_Aadhar.Text.ToString();
                spars1[58].Value = Txt_PAN.Text.ToString();
                spars1[59].Value = Txt_Passport.Text.ToString();
                spars1[60].Value = Txt_EPF.Text.ToString();
                spars1[61].Value = Txt_Pension.Text.ToString();
                spars1[62].Value = Txt_Super.Text.ToString();
                spars1[63].Value = str;
                spars1[64].Value = str;
                spars1[65].Value = txt_Emg_contact_pers_1.Text.ToString();
                spars1[66].Value = txt_Emg_contact_1.Text.ToString();
                spars1[67].Value = txt_Emg_contact_pers_2.Text.ToString();
                spars1[68].Value = txt_Emg_contact_2.Text.ToString();
                spars1[69].Value = txt_PersonalEmail.Text.ToString();
                if (PassIssueDate.ToString() == "")
                    spars1[70].Value = DBNull.Value;
                else
                    spars1[70].Value = PassIssueDate.ToString();
                spars1[71].Value = Txt_PassIssue.Text.ToString();
                if (PassExpiryDate.ToString() == "")
                    spars1[72].Value = DBNull.Value;
                else
                    spars1[72].Value = PassExpiryDate.ToString();
                spars1[73].Value = chk_ecr.ToString();
                spars1[74].Value = Txt_UAN.Text.ToString();
                spars1[75].Value = Txt_BankAC_Name.Text.ToString();
                spars1[76].Value = Txt_BankAddress.Text.ToString();
                spars1[77].Value = Txt_BankbranchNo.Text.ToString();
                spars1[78].Value = Txt_MICR.Text.ToString();
                spars1[79].Value = txt_Bloodgroup.Text.ToString();
                spars1[80].Value = "";

                spars1[81].Value = ddl_completetexts.Text.ToString();
                spars1[82].Value = Convert.ToInt32(ddl_ModuleId.Text);
                spars1[83].Value = Txt_OthModules.Text.ToString();
            //Add 
                spars1[84].Value = Convert.ToInt32(ddl_ShiftId.Text);
            spars1[85].Value = withEffectivDate.ToString();

            if (Convert.ToString(ddl_Module1Id.Text) != "")
                spars1[86].Value = Convert.ToInt32(ddl_Module1Id.Text);
            else
                spars1[86].Value = DBNull.Value;

            if (Convert.ToString(ddl_Module2Id.Text) != "")
                spars1[87].Value = Convert.ToInt32(ddl_Module2Id.Text);
            else
                spars1[87].Value = DBNull.Value;

            spars1[88].Value = "No";
			// spars1[89].Value = AppletterissueDate.ToString();

			if (Convert.ToInt32(ddl_DepartmentId.Text.ToString()) == 14)
			{
				if (chkAgreedBG.Checked == true)
				{
					spars1[89].Value = 1;
					spars1[90].Value = Convert.ToDecimal(txtAgreedBG.Text.Trim());
				}
				else
				{
					spars1[89].Value = 0;
					spars1[90].Value = DBNull.Value;
				}
				
				if (chkAgreedPDC.Checked == true)
				{
					spars1[91].Value = 1;
					spars1[92].Value = txtAgreedPDC.Text.Trim();
				}
				else
				{
					spars1[91].Value = 0;
					spars1[92].Value = DBNull.Value;
				}
				
			}
			else
			{
				spars1[89].Value = DBNull.Value;
				spars1[90].Value = DBNull.Value;
				spars1[91].Value = DBNull.Value;
				spars1[92].Value = DBNull.Value;
			}


			adm.Insert_Data(spars1, "SP_Admin_Employee_Join");

                //AddUser("hrms@2020", 0, Txt_Code.Text.ToString(), DDl_Salutationtexts.Text.ToString() + " " + Txt_NameF.Text.ToString() + " " + Txt_NameM.Text.ToString() + " " + Txt_NameL.Text.ToString(), Txt_Email.Text.ToString()); 

        }
        #region insert or upload multiple files
        string filename = "";
        string strfileName = "";
        if (Txt_Code.Text.ToString() == "")
        Get_Emp_Code();
        if (uploadfile.HasFile)
        {

            
                filename = uploadfile.FileName;
                if (Convert.ToString(filename).Trim() != "")
                {
                    string AdminPath = Server.MapPath(Convert.ToString(ConfigurationManager.AppSettings["ProfileAdminPath"]).Trim());
                    Boolean blnfile = false;
                    HttpFileCollection fileCollection = Request.Files;
                    for (int i = 0; i < fileCollection.Count; i++)
                    {
                        strfileName = "";
                        HttpPostedFile uploadfileName = fileCollection[i];
                        string fileName = Path.GetFileName(uploadfileName.FileName);
                        if (uploadfileName.ContentLength > 0)
                        {
                            String InputFile = System.IO.Path.GetExtension(uploadfileName.FileName);
                            if (ddlEmploymentId.Text.ToString() == "1")
                                strfileName = Convert.ToDouble(Txt_Code.Text.Trim()) + InputFile;
                            else
                                strfileName = Txt_Code.Text.Trim() + InputFile;
                            filename = strfileName;
                            uploadfileName.SaveAs(Path.Combine(AdminPath, strfileName));
                            blnfile = true;
                        }
                    }
                }
           
        }


        //else
        //{
        //    if (projectid == 0)
        //    {
        //        string targetCopy = @"D:\HRMS\hrms\themes\creative1.0\images\profile55x55";
        //        string targetCopy1 = @"D:\HRMS\hrms\themes\creative1.0\images\profile110x110";
        //        string Source = @"D:\HRMS\hrmsadmin\images\profilephoto";
        //        string SourceN = @"D:\HRMS\hrmsadmin\images\profilephoto";
        //        if (Directory.Exists(Source))
        //        {
        //            foreach (string fName in Directory.GetFiles(Source))
        //            {
        //                String InputFile = "";
        //                if (File.Exists(fName))
        //                {
        //                    if (fName.Contains("noimage"))
        //                    {
        //                        InputFile = System.IO.Path.GetExtension(fName);
        //                        if (ddlEmploymentId.Text.ToString() == "1")
        //                            strfileName = Convert.ToDouble(Txt_Code.Text.Trim()) + InputFile;
        //                        else
        //                            strfileName = Txt_Code.Text.Trim() + InputFile;
        //                        File.Copy(fName, SourceN + "\\" + strfileName, true);
        //                        //File.Copy(fName, targetCopy + "\\" + strfileName, true);
        //                        //File.Copy(fName, targetCopy1 + "\\" + strfileName, true);
        //                    }
        //                }
        //            }
        //        }
        //    }
        //}
        #endregion
        if (projectid == 0)
            Response.Redirect(String.Format(ConfigurationManager.AppSettings["sitepathadmin"] + "EmployeeJoin.aspx?faqs={0}&flag=Y", projectid.ToString()));
        else
            Response.Redirect(String.Format(ConfigurationManager.AppSettings["sitepathadmin"] + "EmployeeJoin.aspx?faqs={0}&flag=U", projectid.ToString()));

       


    }

    public static string HashSHA1(string value)
    {
        var sha1 = System.Security.Cryptography.SHA1.Create();
        var inputBytes = Encoding.ASCII.GetBytes(value);
        var hash = sha1.ComputeHash(inputBytes);

        var sb = new StringBuilder();
        for (var i = 0; i < hash.Length; i++)
        {
            sb.Append(hash[i].ToString("X2"));
        }
        return sb.ToString();
    }

    public void AddUser(string password, int uid, string empcode, string empname, string empmail)
    {
        // This function will add a user to our database

        // First create a new Guid for the user. This will be unique for each user
        Guid userGuid = System.Guid.NewGuid();

        // Hash the password together with our unique userGuid
        string hashedPassword = HashSHA1(password + userGuid.ToString());

        SqlParameter[] spars1 = new SqlParameter[8];

        spars1[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars1[1] = new SqlParameter("@Id", SqlDbType.Int);
        spars1[2] = new SqlParameter("@Emp_Code", SqlDbType.VarChar);
        spars1[3] = new SqlParameter("@Emp_Name", SqlDbType.VarChar);
        spars1[4] = new SqlParameter("@Emp_Emailaddress", SqlDbType.VarChar);
        spars1[5] = new SqlParameter("@pwd", SqlDbType.NVarChar);
        spars1[6] = new SqlParameter("@Guid", SqlDbType.UniqueIdentifier);
        spars1[7] = new SqlParameter("@emp_status", SqlDbType.VarChar);
        spars1[0].Value = "Insert_PortalUser";
        spars1[1].Value = uid;
        spars1[2].Value = empcode;
        spars1[3].Value = empname;
        spars1[4].Value = empmail;
        spars1[5].Value = hashedPassword;
        spars1[6].Value = userGuid;
        spars1[7].Value = "Onboard";
        adm.Insert_Data(spars1, "SP_Admin_Employee_Join");

        
    }

    //private void project()
    //{
    //    throw new NotImplementedException();
    //}
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect(ConfigurationManager.AppSettings["sitepathadmin"] + "EmployeeJoin.aspx");
    }

    private void filedelete(string path, string filename)
    {
        string[] st;
        st = Directory.GetFiles(path);
        path += "\\" + filename;
        int i;
        if (filename != "noimage2.gif")
        {
            for (i = 0; i < st.Length; i++)
            {
                try
                {
                    if (st.GetValue(i).ToString() == path)
                    {
                        File.Delete(st.GetValue(i).ToString());
                    }
                }
                catch { }
            }
        }
    }

    public void loaddata(int projectid)
    {
        if (projectid == 0)
        {
            return;
        }
        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "Record";

        spars[1] = new SqlParameter("@Id", SqlDbType.Int);
        spars[1].Value = projectid;

        DataTable tt = adm.getData_FromCode(spars, "SP_Admin_Employee_Join");
        //project myproject = classproject.getsingleprojects(projectid);
        if (tt.Rows.Count > 0)
        {
            DDl_SalutationId.Text = Convert.ToString(tt.Rows[0]["salutation"]);
            DDl_Salutationtexts.Text = Convert.ToString(tt.Rows[0]["salutation"]);
            DDl_Salutation.SelectedValue = DDl_SalutationId.Text;
            DDl_Salutation.SelectedItem.Value = DDl_SalutationId.Text;

            Txt_Code.Text = Convert.ToString(tt.Rows[0]["Emp_Code"]);
            Txt_NameF.Text = Convert.ToString(tt.Rows[0]["first_name"]);
            Txt_NameM.Text = Convert.ToString(tt.Rows[0]["middel_name"]);
            Txt_NameL.Text = Convert.ToString(tt.Rows[0]["last_name"]);
            Txt_Mother.Text = Convert.ToString(tt.Rows[0]["MOTHER_NAME"]);
            Txt_Email.Text = Convert.ToString(tt.Rows[0]["Emp_Emailaddress"]);
            Txt_Mobile.Text = Convert.ToString(tt.Rows[0]["mobile"]);
            Txt_Birthdate.Text = Convert.ToString(tt.Rows[0]["emp_dobF"]);
            Txt_Telephone.Text = Convert.ToString(tt.Rows[0]["emp_office_contact_no"]);

            DDl_Mar_StatId.Text = Convert.ToString(tt.Rows[0]["ISMARRIED"]);
            DDl_Mar_Stattexts.Text = Convert.ToString(tt.Rows[0]["ISMARRIED"]);
            DDl_Mar_Stat.SelectedValue = DDl_Mar_StatId.Text;
            DDl_Mar_Stat.SelectedItem.Value = DDl_Mar_StatId.Text;
            Txt_Anniversary.Text = Convert.ToString(tt.Rows[0]["ANNIVERSARY_DATEF"]);
            ddlGenderId.Text = Convert.ToString(tt.Rows[0]["Gender"]);
            ddlGendertexts.Text = Convert.ToString(tt.Rows[0]["Gender"]);
            ddlGender.SelectedValue = ddlGenderId.Text;
            ddlGender.SelectedItem.Value = ddlGenderId.Text;
            Txt_kids.Text = Convert.ToString(tt.Rows[0]["NO_OF_KIDS"]);

            txt_Address.Text = Convert.ToString(tt.Rows[0]["C_ADD"]);
            txt_Address_P.Text = Convert.ToString(tt.Rows[0]["P_ADD"]);

            txt_Pin.Text = Convert.ToString(tt.Rows[0]["C_PIN"]);
            txt_City.Text = Convert.ToString(tt.Rows[0]["C_CITY"]);
            txt_State.Text = Convert.ToString(tt.Rows[0]["C_STATE"]);
            txt_Country.Text = Convert.ToString(tt.Rows[0]["C_COUNTRY"]);
            txt_Pin_P.Text = Convert.ToString(tt.Rows[0]["P_PIN"]);
            txt_City_P.Text = Convert.ToString(tt.Rows[0]["P_CITY"]);
            txt_State_P.Text = Convert.ToString(tt.Rows[0]["P_STATE"]);
            txt_Country_P.Text = Convert.ToString(tt.Rows[0]["P_COUNTRY"]);

            ddlEmploymentId.Text = Convert.ToString(tt.Rows[0]["EMPLOYMENT_TYPE"]);
            ddlEmploymenttexts.Text = Convert.ToString(tt.Rows[0]["EMPLOYMENT_TYPE_DESCR"]);
            ddlEmployment.SelectedValue = ddlEmploymentId.Text;
            ddlEmployment.SelectedItem.Value = ddlEmploymentId.Text;

            Txt_DOJ.Text = Convert.ToString(tt.Rows[0]["emp_dojF"]);
            Txt_Retirement.Text = Convert.ToString(tt.Rows[0]["RETIREMENT_DATEF"]);

            ddl_LocationId.Text = Convert.ToString(tt.Rows[0]["emp_location"]);
            ddl_Locationtexts.Text = Convert.ToString(tt.Rows[0]["Location_name"]);
            ddl_Location.SelectedValue = ddl_LocationId.Text;
            ddl_Location.SelectedItem.Value = ddl_LocationId.Text;

            ddl_DepartmentId.Text = Convert.ToString(tt.Rows[0]["dept_id"]);
            ddl_Departmenttexts.Text = Convert.ToString(tt.Rows[0]["Department_Name"]);
            ddl_Department.SelectedValue = ddl_DepartmentId.Text;
            ddl_Department.SelectedItem.Value = ddl_DepartmentId.Text;

            ddl_DesignationId.Text = Convert.ToString(tt.Rows[0]["Desig_iD"]);
            ddl_Designationtexts.Text = Convert.ToString(tt.Rows[0]["DesginationName"]);
            ddl_Designation.SelectedValue = ddl_DesignationId.Text;
            ddl_Designation.SelectedItem.Value = ddl_DesignationId.Text;

            ddl_BandId.Text = Convert.ToString(tt.Rows[0]["BAND"]);
            ddl_Bandtexts.Text = Convert.ToString(tt.Rows[0]["BAND"]);
            ddl_Band.SelectedValue = ddl_BandId.Text;
            ddl_Band.SelectedItem.Value = ddl_BandId.Text;

            ddl_EmployeeId.Text = Convert.ToString(tt.Rows[0]["RM"]);
            ddl_Employeetexts.Text = Convert.ToString(tt.Rows[0]["RM_Name"]);
            ddl_Employee.SelectedValue = ddl_EmployeeId.Text;
            ddl_Employee.SelectedItem.Value = ddl_EmployeeId.Text;

            Txt_BankName.Text = Convert.ToString(tt.Rows[0]["BANK_NAME"]);
            Txt_BankAC.Text = Convert.ToString(tt.Rows[0]["BANK_AC"]);
            Txt_IFSC.Text = Convert.ToString(tt.Rows[0]["IFSC_CODE"]);
            Txt_Aadhar.Text = Convert.ToString(tt.Rows[0]["AADHAR"]);

            Txt_PAN.Text = Convert.ToString(tt.Rows[0]["PAN"]);
            Txt_Passport.Text = Convert.ToString(tt.Rows[0]["PASSPORT"]);
            Txt_EPF.Text = Convert.ToString(tt.Rows[0]["EPFO_NO"]);
            Txt_Pension.Text = Convert.ToString(tt.Rows[0]["PENSION_AC"]);
            Txt_Super.Text = Convert.ToString(tt.Rows[0]["SUPER_ANNUATION"]);

            txt_Emg_contact_pers_1.Text = Convert.ToString(tt.Rows[0]["CONTACT_PER_1_NAME"]);
            txt_Emg_contact_1.Text = Convert.ToString(tt.Rows[0]["CONTACT_PER_1_NO"]);
            txt_Emg_contact_pers_2.Text = Convert.ToString(tt.Rows[0]["CONTACT_PER_2_NAME"]);
            txt_Emg_contact_2.Text = Convert.ToString(tt.Rows[0]["CONTACT_PER_2_NO"]);
            txt_PersonalEmail.Text = Convert.ToString(tt.Rows[0]["PERSONAL_EMAIL"]);
            Txt_DateofIssue.Text = Convert.ToString(tt.Rows[0]["PASS_DATEOFISSUE"]);
            Txt_PassIssue.Text = Convert.ToString(tt.Rows[0]["PASS_PLACEOFISSUE"]);
            Txt_DateofExpiry.Text = Convert.ToString(tt.Rows[0]["PASS_EXPIRYDATE"]);
            Txt_UAN.Text = Convert.ToString(tt.Rows[0]["UANNO"]);
            Txt_BankAC_Name.Text = Convert.ToString(tt.Rows[0]["BANK_AC_NAME"]);
            Txt_BankAddress.Text = Convert.ToString(tt.Rows[0]["BANK_ADDRESS"]);
            Txt_BankbranchNo.Text = Convert.ToString(tt.Rows[0]["BANK_BRANCH_NO"]);
            Txt_MICR.Text = Convert.ToString(tt.Rows[0]["BANK_MICR"]);
            txt_Bloodgroup.Text = Convert.ToString(tt.Rows[0]["BLOOD_GRP"]);

            ddl_completeId.Text = Convert.ToString(tt.Rows[0]["COMPLETE_FLAG"]);
            ddl_completetexts.Text = Convert.ToString(tt.Rows[0]["COMPLETE_FLAG"]);
            ddl_complete.SelectedValue = ddl_completeId.Text;
            ddl_complete.SelectedItem.Value = ddl_completeId.Text;

            ddl_ModuleId.Text = Convert.ToString(tt.Rows[0]["EMP_MODULE"]);
            ddl_Moduletexts.Text = Convert.ToString(tt.Rows[0]["ModuleDesc"]);
            ddl_Module.SelectedValue = ddl_ModuleId.Text;
            ddl_Module.SelectedItem.Value = ddl_ModuleId.Text;

            ddl_Module1Id.Text = Convert.ToString(tt.Rows[0]["EMP_MODULE_S"]);
            ddl_Module1texts.Text = Convert.ToString(tt.Rows[0]["ModuleDesc_S"]);
            ddl_Module1.SelectedValue = ddl_Module1Id.Text;
            ddl_Module1.SelectedItem.Value = ddl_Module1Id.Text;

            ddl_Module2Id.Text = Convert.ToString(tt.Rows[0]["EMP_MODULE_T"]);
            ddl_Module2texts.Text = Convert.ToString(tt.Rows[0]["ModuleDesc_T"]);
            ddl_Module2.SelectedValue = ddl_Module2Id.Text;
            ddl_Module2.SelectedItem.Value = ddl_Module2Id.Text;

            Txt_OthModules.Text = Convert.ToString(tt.Rows[0]["OTHER_MODULES"]);

            if (Convert.ToString(tt.Rows[0]["LEAVE_ELE"]) == "Y")
                chk_leave.Checked = true;
            if (Convert.ToString(tt.Rows[0]["IS_SELF_APPROVER"]) == "Y")
                chk_Self.Checked = true;
            if (Convert.ToString(tt.Rows[0]["CONTACT_DIS"]) == "Y")
                chk_Contact.Checked = true;
            if (Convert.ToString(tt.Rows[0]["ECR_STAMP"]) == "Y")
                Chk_ECR.Checked = true;

            if (tt.Rows[0]["ChkedWelcomeMail"].ToString() == "")
            {
                CHK_SendWelcomeEmail.Checked = false;
            }
            else
            {
                CHK_SendWelcomeEmail.Checked = Convert.ToBoolean(tt.Rows[0]["ChkedWelcomeMail"]);
            }
            ddl_ShiftId.Text = Convert.ToString(tt.Rows[0]["SHIFT_ID"]);
            ddl_Shifttext.Text = Convert.ToString(tt.Rows[0]["Shift_Name"]);
            ddl_Shift.SelectedValue = ddl_ShiftId.Text;
            ddl_Shift.SelectedItem.Value = ddl_Shifttext.Text;
            //
            Txt_Resignation.Text = Convert.ToString(tt.Rows[0]["WithEDate"]);
            Txt_Contract_Start_date.Text = Convert.ToString(tt.Rows[0]["ContractStartDate"]);
            txt_Contract_End_date.Text = Convert.ToString(tt.Rows[0]["ContractEndDate"]);

            // Add Code 25-09-2021 
            DDLCandidateName.Enabled = false;
            RequiredFieldValidator22.Enabled = false;
            DDLCandidateName.SelectedValue = Convert.ToString(tt.Rows[0]["Candidate_ID"]);
            DDLCandidatetext.Text = DDLCandidateName.SelectedItem.Text;
            DDLCandiadateID.Text = Convert.ToString(tt.Rows[0]["Candidate_ID"]);

            RequiredFieldValidator23.Enabled = false;
            Txt_RequisitionNumber.Text = Convert.ToString(tt.Rows[0]["RequisitionNumber"]);
            hdRecruitment_ReqID.Value = Convert.ToString(tt.Rows[0]["Recruitment_ReqID"]);

            DDLApplettreissuedstatus.SelectedValue = Convert.ToString(tt.Rows[0]["Appointmentletterissuedstatus"]);
            DDl_Appletter_Stattexts.Text = DDLApplettreissuedstatus.SelectedItem.Text;
            DDl_Appletter_Stat.Text = Convert.ToString(tt.Rows[0]["Appointmentletterissuedstatus"]);
            Txt_AppletterissueDate.Text = Convert.ToString(tt.Rows[0]["AppointmentletterIssueddatee"]);

            if (Convert.ToString(tt.Rows[0]["OldRefEmpCode"]) == "")
            {
                TRPayRollchange.Visible = false;
                RequiredFieldValidator25.Enabled = false;
            }
            else
            {
                DDLOldEmpCodeRefID.SelectedValue = Convert.ToString(tt.Rows[0]["OldRefEmpCode"]);
                CHKPayRollChange.Checked = true;
                CHKPayRollChange.Enabled = false;
                DDLOldEmpCodeRefID.Enabled = false;
                TRPayRollchange.Visible = true;
                TDOldEmpCode.Visible = true;
                TDOldEmpCode1.Visible = true;
                RequiredFieldValidator25.Enabled = false;
            }
			//09-11-21
			if (Convert.ToString(tt.Rows[0]["dept_id"]) == "14")
			{
				ShowAgreed.Visible = true;
				ShowAgreedPDC.Visible = true;
                bool CKAgreedBG = false;
                bool CKAgreedPDC = false;
                if (Convert.ToString(tt.Rows[0]["AgreedBG"]) != "")
                {
                    CKAgreedBG = Convert.ToBoolean(tt.Rows[0]["AgreedBG"]);
                }
                if (Convert.ToString(tt.Rows[0]["AgreedPDC"]) != "")
                {
                    CKAgreedPDC = Convert.ToBoolean(tt.Rows[0]["AgreedPDC"]);
                }

                if (CKAgreedBG == true)
				{
					
					chkAgreedBG.Checked = true;
					ShowAgreed1.Visible = true;
					txtAgreedBG.Visible = true;
					txtAgreedBG.Text = Convert.ToString(tt.Rows[0]["BGAmount"]);
					RequiredFieldValidator26.Enabled = true;
				}
				else
				{
					chkAgreedBG.Checked = false;
					ShowAgreed1.Visible = false;
					txtAgreedBG.Visible = false;
					RequiredFieldValidator26.Enabled = false;
				}
				if (CKAgreedPDC == true)
				{
					chkAgreedPDC.Checked = true;
					ShowAgreed2.Visible = true;
					txtAgreedPDC.Visible = true;
					txtAgreedPDC.Text = Convert.ToString(tt.Rows[0]["PDCDetails"]);
					RequiredFieldValidator27.Enabled = true;
				}
				else
				{
					chkAgreedPDC.Checked = false;
					ShowAgreed2.Visible = false;
					txtAgreedPDC.Visible = false;
					RequiredFieldValidator27.Enabled = false;
				}
			}
            ddl_Band.Enabled = false;
            //ddl_Shift.Enabled = false;
            ddl_Department.Enabled = false;
            ddl_Designation.Enabled = false;
	        ddl_Shift.Enabled = false;
            ddl_Employee.Enabled = false;
            ddl_Location.Enabled = false;
            btnDOJ.Enabled = false;
           
           // btnSearchPM.Enabled = false;
            Txt_DOJ.Enabled = false;

            FileUploadCandidate.Visible = false;
            hdfilefath.Value = Server.MapPath(Convert.ToString(ConfigurationManager.AppSettings["CandidateAttachment"]).Trim());
            if (Convert.ToString(tt.Rows[0]["Candidate_letter"]) == "")
            {
                lnkuplodedfile.Visible = false;
            }
            else
            {
                lnkuplodedfile.Visible = true;
                lnkuplodedfile.Text = Convert.ToString(tt.Rows[0]["Candidate_letter"]);
                hdfilename.Value = Convert.ToString(tt.Rows[0]["Candidate_letter"]);
            }
            

            if (ddlEmploymentId.Text.ToString() == "1")
            {
                Profile_Photo.ImageUrl = "~/images/profilephoto/" + Convert.ToDouble(Txt_Code.Text.Trim()) + ".jpg";
            }
            else
            {
                Profile_Photo.ImageUrl = "~/images/profilephoto/" + Txt_Code.Text.Trim() + ".jpg";
            }

            Txt_Resignation.Enabled = false;
            btnResignationdate.Enabled = false;
            
             ddlEmployment.Enabled = false;
            showContractDiv.Visible = true;
           // txt_Contract_End_date.Visible = true;
            txt_Contract_End_date.Enabled = false;
            ImageButton12.Enabled = false;
            //Txt_Contract_Start_date.Visible = false;
        }
    }

    public void project()
    {
        DataTable dt = classxml.gettopprojectslist();
        if (dt.Rows.Count > 0)
        {
            DataSet ds = new DataSet();
            ds.Tables.Add(dt);
            saveXml(ds, "projectadd.xml");
        }
    }

    public void Fill_Project_Manager()
    {
        string search_str = "";
        //if (txt_PM.Text.ToString() == "")
        //    search_str = "";
        //else
        //    search_str = txt_PM.Text.ToString();

        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "Employee";

        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        if (search_str.ToString() == "")
            spars[1].Value = DBNull.Value;
        else
            spars[1].Value = search_str.ToString();

        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");
        ddl_Employee.DataSource = dt;

        ddl_Employee.DataTextField = "empname";
        ddl_Employee.DataValueField = "Emp_Code";
        ddl_Employee.DataBind();
        ListItem item = new ListItem("Select Reporting Manager", "0");
        ddl_Employee.Items.Insert(0, item);
    }

    public void Fill_Location()
    {
        string search_str = "";

        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "Location";

        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        if (search_str.ToString() == "")
            spars[1].Value = DBNull.Value;
        else
            spars[1].Value = search_str.ToString();

        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");
        ddl_Location.DataSource = dt;

        ddl_Location.DataTextField = "t_Name";
        ddl_Location.DataValueField = "t_ID";
        ddl_Location.DataBind();
        ListItem item = new ListItem("Select Location", "0");
        ddl_Location.Items.Insert(0, item);
    }

    public void Fill_Employment()
    {
        string search_str = "";

        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "Employment";

        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        if (search_str.ToString() == "")
            spars[1].Value = DBNull.Value;
        else
            spars[1].Value = search_str.ToString();

        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");

        ddlEmployment.DataSource = dt;

        ddlEmployment.DataTextField = "t_Name";
        ddlEmployment.DataValueField = "t_ID";
        ddlEmployment.DataBind();
        ListItem item = new ListItem("Select Employment Type", "0");
        ddlEmployment.Items.Insert(0, item);
    }

    public void Fill_Department()
    {
        string search_str = "";

        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "Department";

        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        if (search_str.ToString() == "")
            spars[1].Value = DBNull.Value;
        else
            spars[1].Value = search_str.ToString();

        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");

        ddl_Department.DataSource = dt;

        ddl_Department.DataTextField = "t_Name";
        ddl_Department.DataValueField = "t_ID";
        ddl_Department.DataBind();
        ListItem item = new ListItem("Select Department", "0");
        ddl_Department.Items.Insert(0, item);
    }

    public void Fill_Designation()
    {
        string search_str = "";

        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "Designation";

        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        if (search_str.ToString() == "")
            spars[1].Value = DBNull.Value;
        else
            spars[1].Value = search_str.ToString();

        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");

        ddl_Designation.DataSource = dt;

        ddl_Designation.DataTextField = "t_Name";
        ddl_Designation.DataValueField = "t_ID";
        ddl_Designation.DataBind();
        ListItem item = new ListItem("Select Designation", "0");
        ddl_Designation.Items.Insert(0, item);
    }

    public void Fill_Module()
    {
        string search_str = "";

        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "Module";

        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        if (search_str.ToString() == "")
            spars[1].Value = DBNull.Value;
        else
            spars[1].Value = search_str.ToString();

        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");

        ddl_Module.DataSource = dt;

        ddl_Module.DataTextField = "t_Name";
        ddl_Module.DataValueField = "t_ID";
        ddl_Module.DataBind();
        ListItem item = new ListItem("Select Module", "0");
        ddl_Module.Items.Insert(0, item);

        ddl_Module1.DataSource = dt;

        ddl_Module1.DataTextField = "t_Name";
        ddl_Module1.DataValueField = "t_ID";
        ddl_Module1.DataBind();
        ListItem item1 = new ListItem("Select Module", "0");
        ddl_Module1.Items.Insert(0, item1);

        ddl_Module2.DataSource = dt;

        ddl_Module2.DataTextField = "t_Name";
        ddl_Module2.DataValueField = "t_ID";
        ddl_Module2.DataBind();
        ListItem item2 = new ListItem("Select Module", "0");
        ddl_Module2.Items.Insert(0, item2);
    }

    public void Fill_Band()
    {
        string search_str = "";

        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "Band";

        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        if (search_str.ToString() == "")
            spars[1].Value = DBNull.Value;
        else
            spars[1].Value = search_str.ToString();

        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");

        ddl_Band.DataSource = dt;

        ddl_Band.DataTextField = "t_Name";
        ddl_Band.DataValueField = "t_ID";
        ddl_Band.DataBind();
        ListItem item = new ListItem("Select Band", "0");
        ddl_Band.Items.Insert(0, item);
    }

    public void Get_Emp_Code()
    {
        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "getCode";

        spars[1] = new SqlParameter("@EMPLOYMENT_TYPE", SqlDbType.Int);
        spars[1].Value = Convert.ToInt32(ddlEmploymentId.Text.ToString()); 

        DataTable dt = adm.getDropdownList(spars, "SP_Admin_Employee_Join");

        if (dt.Rows.Count > 0)
        {
            Txt_Code.Text = Convert.ToString(dt.Rows[0]["empcode"]);
        }
    }


    public void saveXml(DataSet ds, string filename)
    {
        string fpath = Server.MapPath("xml") + "\\" + filename;
        StreamWriter myStreamWriter = new StreamWriter(@"" + fpath);
        ds.WriteXml(myStreamWriter);
        myStreamWriter.Close();
    }


    //protected void btnSearchPM_Click(object sender, ImageClickEventArgs e)
    //{
    //    Fill_Project_Manager();
    //}
    protected void Txt_Birthdate_TextChanged(object sender, EventArgs e)
    {
        DateTime tt;
        if (Txt_Birthdate.Text.ToString() != "")
        {
            tt = DateTime.ParseExact(Txt_Birthdate.Text, @"dd/MM/yyyy",
     System.Globalization.CultureInfo.InvariantCulture);
            tt = tt.AddYears(60);
            Txt_Retirement.Text = tt.ToString("dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
        }
    }
    //Chnage on 18-03-2021
    public void Fill_Shift()
    {
        string search_str = "";

        SqlParameter[] spars = new SqlParameter[2];

        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "ddl_Shift";

        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        if (search_str.ToString() == "")
            spars[1].Value = DBNull.Value;
        else
            spars[1].Value = search_str.ToString();

        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");

        ddl_Shift.DataSource = dt;

        ddl_Shift.DataTextField = "Shift_Name";
        ddl_Shift.DataValueField = "Shift_Id";
        ddl_Shift.DataBind();
        ListItem item = new ListItem("Select Shift", "0");
        ddl_Shift.Items.Insert(0, item);
    }

    protected void Txt_DOJ_TextChanged(object sender, EventArgs e)
    {
        msgsave.Text = "";
        msgsave.Visible = false;
        DateTime tt;
        if (Txt_DOJ.Text.ToString() != "")
        {
            tt = DateTime.ParseExact(Txt_DOJ.Text, @"dd/MM/yyyy",System.Globalization.CultureInfo.InvariantCulture);
            tt = tt.AddDays(7);
            Txt_Resignation.Text = tt.ToString("dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
            Txt_Contract_Start_date.Text = Txt_DOJ.Text;
        }
    }

    protected void Txt_Resignation_TextChanged(object sender, EventArgs e)
    {
        try
        {
            msgsave.Text = "";
            msgsave.Visible = false;
            DateTime tt;
            DateTime tt1;
            if (Txt_DOJ.Text.ToString() == "")
            {
                Txt_Resignation.Text = "";
                msgsave.Text = "Please select employee joining date first!";
                msgsave.Visible = true;
                return;
            }
            if (Txt_Resignation.Text.ToString() != "")
            {
                tt = DateTime.ParseExact(Txt_DOJ.Text, @"dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                tt1 = DateTime.ParseExact(Txt_Resignation.Text, @"dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                if(tt>= tt1)
                {
                    Txt_Resignation.Text = "";
                    msgsave.Text = "Please select date greater than joining date.";
                    msgsave.Visible = true;
                    return;
                }
               
            }
            if (Txt_Resignation.Text.ToString() != "")
            {
                tt = DateTime.Now;
                tt1 = DateTime.ParseExact(Txt_Resignation.Text, @"dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                if (tt >= tt1)
                {
                    Txt_Resignation.Text = "";
                    msgsave.Text = "Please select date greater than today's date.";
                    msgsave.Visible = true;
                    return;
                }

            }

        }
        catch (Exception)
        {

            throw;
        }
        
    }

    protected void txt_Contract_End_date_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (txt_Contract_End_date.Text.ToString() != "")
            {
               var tt = DateTime.ParseExact(Txt_Contract_Start_date.Text, @"dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                var tt1 = DateTime.ParseExact(txt_Contract_End_date.Text, @"dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                if (tt >= tt1)
                {
                    txt_Contract_End_date.Text = "";
                    msgsave.Text = "Please select date greater than today's date.";
                    msgsave.Visible = true;
                    return;
                }

            }
        }
        catch (Exception)
        {

            throw;
        }
    }

    protected void ddlEmployment_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            var typeId = ddlEmployment.SelectedValue.ToString();
            if(typeId!="0")
            {
                var id = Convert.ToInt32(typeId);
                if(id==2||id==4)
                {
                    showContractDiv.Visible = true;
                }
                else
                {
                    showContractDiv.Visible = false;
                }
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    #region  harshad Code Start for Requisition Closed

    public void Fill_CandidateName()
    {
        string search_str = "";
        SqlParameter[] spars = new SqlParameter[3];
        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "GetCandidate";
        spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
        if (search_str.ToString() == "")
            spars[1].Value = DBNull.Value;
        else
            spars[1].Value = search_str.ToString();
        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetCandidateRequisition");
        DDLCandidateName.DataSource = dt;
        DDLCandidateName.DataTextField = "CandidateName";
        DDLCandidateName.DataValueField = "Candidate_ID";
        DDLCandidateName.DataBind();
        ListItem item = new ListItem("Select Candidate", "0");
        DDLCandidateName.Items.Insert(0, item);
    }

    public void Fill_CandidateNameClosed()
    {

        SqlParameter[] spars = new SqlParameter[3];
        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "GetCandidateClosed";
        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetCandidateRequisition");
        DDLCandidateName.DataSource = dt;
        DDLCandidateName.DataTextField = "CandidateName";
        DDLCandidateName.DataValueField = "Candidate_ID";
        DDLCandidateName.DataBind();
        ListItem item = new ListItem("Select Candidate", "0");
        DDLCandidateName.Items.Insert(0, item);
    }

    public void RequisitionNoDependingonCandidate()
    {
        string search_str = DDLCandidateName.SelectedValue;
        if (search_str == "0")
        {
            Txt_RequisitionNumber.Text = "";
            hdRecruitment_ReqID.Value = "";
        }
        else
        {
            SqlParameter[] spars = new SqlParameter[3];
            spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars[0].Value = "GetCandidate";
            spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
            spars[1].Value = search_str.ToString();
            DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetCandidateRequisition");
            if (dt.Rows.Count > 0)
            {
                Txt_RequisitionNumber.Text = Convert.ToString(dt.Rows[0]["RequisitionNumber"]);
                hdRecruitment_ReqID.Value = Convert.ToString(dt.Rows[0]["Recruitment_ReqID"]);
                HDCandidateEmail.Value = Convert.ToString(dt.Rows[0]["CandidateEmail"]);
            }
        }
    }

    protected void DDLCandidateName_SelectedIndexChanged(object sender, EventArgs e)
    {
        RequisitionNoDependingonCandidate();
        Txt_DOJ.Focus();
    }

    public void ClosedRequisition(string Username)
    {
        try
        {
            DateTime? CandidatejoiningDate = null;
            if (Txt_DOJ.Text != "")
            {
                string[] strdate1;
                string strtoDate = "";
                strdate1 = Convert.ToString(Txt_DOJ.Text).Trim().Split('/');
                strtoDate = Convert.ToString(strdate1[2]) + "-" + Convert.ToString(strdate1[1]) + "-" + Convert.ToString(strdate1[0]);
                CandidatejoiningDate = DateTime.ParseExact(strtoDate, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
            }

            SqlParameter[] spars = new SqlParameter[6];
            spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars[0].Value = "InterviewFinalupdateClosedfromRecruiter";
            spars[1] = new SqlParameter("@Recruitment_ReqID", SqlDbType.Int);
            spars[1].Value = Convert.ToInt32(hdRecruitment_ReqID.Value);
            spars[2] = new SqlParameter("@Emp_Code", SqlDbType.VarChar);
            spars[2].Value = Username;
            spars[3] = new SqlParameter("@empcodenew", SqlDbType.VarChar);
            spars[3].Value = HDEmpcodenew.Value;
            spars[4] = new SqlParameter("@Candidate_ID", SqlDbType.Int);
            spars[4].Value = DDLCandidateName.SelectedValue;
            spars[5] = new SqlParameter("@CandJoiningDate", SqlDbType.DateTime);
            spars[5].Value = CandidatejoiningDate;
            DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetCandidateRequisition");

            string mailsubject = "";
            string mailcontain1 = "";
            mailsubject = "Recruitment - Candidate  " + Txt_NameF.Text + ' ' + Txt_NameL.Text + " joined for requisition  " + dt.Rows[0]["RequisitionNumber"].ToString() + " Of " + dt.Rows[0]["ReqName"].ToString();
            mailcontain1 = "This is to inform you that the requisition " + dt.Rows[0]["RequisitionNumber"].ToString() + " is closed as the following candidate has joined against this requisition;";

            string strtomail = dt.Rows[0]["Emp_Emailaddress"].ToString();
            string strrecmail = Username;

            string strempnameddlCandidate = Txt_NameF.Text + ' ' + Txt_NameL.Text.Trim();
            string strDepartmentCandidate = ddl_Department.SelectedItem.Text.Trim();
            string strLocationCandidate = ddl_Location.SelectedItem.Text.Trim();
            string strDesignationCandidate = ddl_Designation.SelectedItem.Text.Trim();
            string strBandCandidate = ddl_Band.SelectedItem.Text.Trim();

            string strrDate = dt.Rows[0]["date"].ToString();
            string strrecruitername = dt.Rows[0]["RecruiterName"].ToString();
            string lstPositionDeptMain = dt.Rows[0]["Department_Name"].ToString();
            string lstPositionLocaMain = dt.Rows[0]["comp_code"].ToString();
            string lstSkillsetMain = dt.Rows[0]["ModuleDesc"].ToString();
            string lstPositionNameMain = dt.Rows[0]["PositionTitle"].ToString();
            string lstPositionBandMain = dt.Rows[0]["BAND"].ToString();
            string txtNoofPositionmain = dt.Rows[0]["NoOfPosition"].ToString();

            string StrRequisitionDate = dt.Rows[0]["RequisitionDate"].ToString();
            string StrFillInDays = dt.Rows[0]["ToBeFilledIn_Days"].ToString();

            string RequiredByDate = "";
            RequiredByDate = GetRequiredByDate(StrRequisitionDate, StrFillInDays);

            adm.send_mailto_closerequisition_Mail(strrecmail, strtomail, mailsubject, mailcontain1, strempnameddlCandidate, HDEmpcodenew.Value, strDepartmentCandidate, strLocationCandidate, strDesignationCandidate, strBandCandidate, dt.Rows[0]["ReqName"].ToString().Trim(), dt.Rows[0]["RequisitionNumber"].ToString().Trim(), strrDate, RequiredByDate, lstPositionLocaMain, lstSkillsetMain,
            lstPositionNameMain, lstPositionDeptMain, lstPositionBandMain, txtNoofPositionmain, strrecruitername);

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            //throw;
        }
    }

    private string GetRequiredByDate(string Date, string fillin)
    {
        string[] strdate;
        string strtoDate = "", RequiredByDate = "";
        DateTime RequiredDate;
        int Days;
        try
        {
            Days = Convert.ToInt32(fillin);
            strdate = Convert.ToString(Date).Trim().Split('-');

            strtoDate = Convert.ToString(strdate[2].Substring(0, 4)) + "-" + Convert.ToString(strdate[1]) + "-" + Convert.ToString(strdate[0]);
            DateTime ddt = DateTime.ParseExact(strtoDate, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
            RequiredDate = ddt.AddDays(Days);
            RequiredByDate = RequiredDate.ToString("dd-MM-yyyy");
        }
        catch (Exception ex)
        {
            return RequiredByDate;
            //Response.Write(ex.Message.ToString());
        }
        return RequiredByDate;
    }

    #endregion


    protected void CHKPayRollChange_CheckedChanged(object sender, EventArgs e)
    {
        if (CHKPayRollChange.Checked == true)
        {
            TDOldEmpCode.Visible = true;
            TDOldEmpCode1.Visible = true;
            RequiredFieldValidator22.Enabled = false;
            RequiredFieldValidator23.Enabled = false;
            RequiredFieldValidator25.Enabled = true;
            DDLCandidateName.Enabled = false;
        }
        else
        {
            RequiredFieldValidator22.Enabled = true;
            RequiredFieldValidator23.Enabled = true;
            RequiredFieldValidator25.Enabled = false;
            TDOldEmpCode.Visible = false;
            TDOldEmpCode1.Visible = false;
            DDLCandidateName.Enabled = false;
        }
    }

    public void GetOldEmpCodeReference()
    {

        SqlParameter[] spars = new SqlParameter[2];
        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "OldEmpCodeReference";
        DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");
        DDLOldEmpCodeRefID.DataSource = dt;

        DDLOldEmpCodeRefID.DataTextField = "Emp_Name";
        DDLOldEmpCodeRefID.DataValueField = "Emp_Code";
        DDLOldEmpCodeRefID.DataBind();
        ListItem item = new ListItem("Select Old EmpCode Reference", "0");
        DDLOldEmpCodeRefID.Items.Insert(0, item);
    }


    protected void DDLOldEmpCodeRefID_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlParameter[] spars = new SqlParameter[2];
        spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
        spars[0].Value = "GetOldReferenceEmpcodeCandidate";
        spars[1] = new SqlParameter("@Emp_Code", SqlDbType.VarChar);
        spars[1].Value = DDLOldEmpCodeRefID.SelectedValue;
        DataTable dt = adm.getDuplicate_List(spars, "SP_Admin_Employee_Join");
        if (dt.Rows.Count > 0)
        {
            HFCandidateIDOld.Value = dt.Rows[0]["Candidate_ID"].ToString();
            hdRecruitment_ReqID.Value = dt.Rows[0]["Recruitment_ReqID"].ToString();
            if (HFCandidateIDOld.Value == "")
            {
                HFCandidateIDOld.Value = "0";
                hdRecruitment_ReqID.Value = "0";
            }

        }
        else
        {
            HFCandidateIDOld.Value = "";
            hdRecruitment_ReqID.Value = "";
        }
    }


	protected void chkAgreedBG_CheckedChanged(object sender, EventArgs e)
	{
		if (chkAgreedBG.Checked == true)
		{
			txtAgreedBG.Visible = true;
			ShowAgreed1.Visible = true;
			RequiredFieldValidator26.Enabled = true;
		}
		else
		{
			txtAgreedBG.Visible = false;
			txtAgreedBG.Text = "";
			RequiredFieldValidator26.Enabled = false;
			ShowAgreed1.Visible = false;
		}

	}

	protected void chkAgreedPDC_CheckedChanged(object sender, EventArgs e)
	{
		if (chkAgreedPDC.Checked == true)
		{
			txtAgreedPDC.Visible = true;
			ShowAgreed2.Visible = true;
			RequiredFieldValidator27.Enabled = true;
		}
		else
		{
			txtAgreedPDC.Visible = false;
			RequiredFieldValidator27.Enabled = false;
			txtAgreedPDC.Text = "";
			ShowAgreed2.Visible = false;
		}
		
	}

	protected void ddl_Department_SelectedIndexChanged(object sender, EventArgs e)
	{
		if (ddl_Department.SelectedIndex > 0)
		{
			if (ddl_Department.SelectedValue.ToString() == "14")
			{
				ShowAgreed.Visible = true;
				ShowAgreedPDC.Visible = true;
			}
			else
			{
				ShowAgreed.Visible = false;
				ShowAgreedPDC.Visible = false;
				ShowAgreed1.Visible = false;
				ShowAgreed2.Visible = false;
				txtAgreedPDC.Visible = false;
				txtAgreedBG.Visible = false;
				chkAgreedBG.Checked = false;
				chkAgreedPDC.Checked = false;
				txtAgreedPDC.Text = "";
				txtAgreedBG.Text = "";
			}
		}
	}

    private void CheckReferral_Candidated(string Emailaddress)
    {
        DataTable dtReferral = new DataTable();
        try
        {
            int StatusID = 11; string Result = "Joined";
            //if (Selected == "1")
            //{
            //	StatusID = 8;
            //	Result = "Rejected";
            //}
            string CandidatedID = DDLCandidateName.SelectedValue;
            string EmployeeEmailID = "";//Convert.ToString(Session["Empcode"]).Trim()
            string EmpFlag = "SuperAdmin";
            //string Emailaddress = Emailaddress;
            dtReferral = adm.SearchCandidatedForReferral(CandidatedID, EmployeeEmailID, StatusID, EmpFlag, Emailaddress);
            if (dtReferral.Rows.Count > 0)
            {
                var EmployeeName = dtReferral.Rows[0]["Emp_Name"].ToString();
                var EmployeeEmail = dtReferral.Rows[0]["Emp_Emailaddress"].ToString();
                var Ref_CandidateName = dtReferral.Rows[0]["Ref_CandidateName"].ToString();
                var Ref_CandidateEmail = dtReferral.Rows[0]["Ref_CandidateEmail"].ToString();
                var Gender = dtReferral.Rows[0]["Gender"].ToString();
                var Ref_CandidateMobile = dtReferral.Rows[0]["Ref_CandidateMobile"].ToString();
                var Maritalstatus = dtReferral.Rows[0]["Maritalstatus"].ToString();
                var Ref_CandidateTotalExperience = dtReferral.Rows[0]["Ref_CandidateTotalExperience"].ToString();
                var Ref_CandidateRelevantExperience = dtReferral.Rows[0]["Ref_CandidateRelevantExperience"].ToString();
                var AdditionalSkillset = dtReferral.Rows[0]["AdditionalSkillset"].ToString();
                var CREATEDON = dtReferral.Rows[0]["CREATEDON"].ToString();
                var Comments = dtReferral.Rows[0]["Comments"].ToString();
                var ModuleDesc = dtReferral.Rows[0]["ModuleDesc"].ToString();
                var Subject = "Candidate referral  “" + Ref_CandidateName + "” is “" + Result + "”";
                var Body = "This is to inform you that the candidate referred by you is “" + Result + "”.Refer following details.";
                adm.Ref_Candidated_send_mailto_recruitmentModule(Ref_CandidateName, Subject, Body, EmployeeEmail, EmployeeName, CREATEDON,
                Ref_CandidateEmail, "", Ref_CandidateMobile, Gender, Maritalstatus, ModuleDesc, Ref_CandidateTotalExperience, Ref_CandidateRelevantExperience, AdditionalSkillset, Comments);

            }
        }
        catch (Exception)
        {

            throw;
        }

    }


    protected void ddl_Location_SelectedIndexChanged(object sender, EventArgs e)
    {
        // ddl_Employee

        if (ddl_Location.SelectedValue == "HO-NaviMum")
        {
            ddl_Employee.Enabled = true;
            ddl_Employee.SelectedValue = "0";
            ddl_EmployeeId.Text = "";
            ddl_Employeetexts.Text = "";
        }
        else
        {
            string search_str = ddl_Location.SelectedValue;
            SqlParameter[] spars = new SqlParameter[2];

            spars[0] = new SqlParameter("@qtype", SqlDbType.VarChar);
            spars[0].Value = "LocationSearchonselect";
            spars[1] = new SqlParameter("@SearchString", SqlDbType.VarChar);
            spars[1].Value = search_str.ToString();
            DataTable dt = adm.getDropdownList(spars, "SP_Admin_GetDropdown");

            if (dt.Rows.Count > 0)
            {
               

                ddl_EmployeeId.Text = Convert.ToString(dt.Rows[0]["PM"]);
                ddl_Employeetexts.Text = Convert.ToString(dt.Rows[0]["PM"]);
                ddl_Employee.SelectedValue = ddl_EmployeeId.Text;
                ddl_Employee.SelectedItem.Value = ddl_EmployeeId.Text;

                ddl_Employee.SelectedValue = dt.Rows[0]["PM"].ToString();

            }

            ddl_Employee.Enabled = false;
        }
    }
}
